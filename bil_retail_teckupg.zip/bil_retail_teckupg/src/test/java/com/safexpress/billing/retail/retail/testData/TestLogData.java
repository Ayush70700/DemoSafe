package com.safexpress.billing.retail.retail.testData;

import com.safexpress.billing.retail.model.LogUpdateRetryCountRequest;
import com.safexpress.billing.retail.model.LogUpdateRetryCountResponse;
import com.safexpress.billing.retail.model.PiBilRetailLogRequest;

public class TestLogData {

	public PiBilRetailLogRequest getRetailLogData() {
			
		PiBilRetailLogRequest req = new PiBilRetailLogRequest();
	
		req.setNumberOfDays("more_than_30");
		req.setProjectName("RETAIL");
		req.setRetryCount("5");
			
		return req;
	}
	
	public LogUpdateRetryCountRequest getRetailRetryCountData() {
		
		LogUpdateRetryCountRequest req = new LogUpdateRetryCountRequest();
	
		req.setIntegrationId(Long.valueOf(1111));
		req.setProjectName("RECEIPT");
		req.setRetryCount("5");
		
		return req;
	}
	
	public LogUpdateRetryCountResponse getRetailRetryCountResponse() {
		
		LogUpdateRetryCountResponse  resp = new LogUpdateRetryCountResponse();
		
		resp.setIntegrationId(Long.valueOf(1111));
		resp.setMessage("Retry Count Reset Successfully");
		resp.setProjectName("RECEIPT");
		resp.setStatus("SUCCESS");
		
		return resp;
		
	}

}
