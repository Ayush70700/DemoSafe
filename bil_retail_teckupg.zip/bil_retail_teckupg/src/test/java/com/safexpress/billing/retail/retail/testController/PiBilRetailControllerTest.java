package com.safexpress.billing.retail.retail.testController;

import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.safexpress.billing.retail.model.LogUpdateRetryCountRequest;
import com.safexpress.billing.retail.model.PiBilRetailLogRequest;
import com.safexpress.billing.retail.model.PiBilRetailLogResponse;
import com.safexpress.billing.retail.retail.testData.TestHeaderData;
import com.safexpress.billing.retail.retail.testData.TestLogData;
import com.safexpress.billing.retail.retail.testUtil.TestMockUtils;
import com.safexpress.billing.retail.service.PiBilRetailLogService;

@AutoConfigureMockMvc
//@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@SpringBootTest
public class PiBilRetailControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	PiBilRetailLogService retailService;
	
	private HttpHeaders billingHeader;
	private TestLogData data = new TestLogData();
	private List<PiBilRetailLogResponse> retailList = new ArrayList<PiBilRetailLogResponse>();
	
	@BeforeEach
	public void initialSetUp() {
		
		billingHeader = TestHeaderData.buildHeader();
		
	}
	
	@Test
	public void testPiBilRetailController_DisplayLogs() throws Exception {
		
		when(retailService.getRetailApiLogsInfo(Mockito.any(PiBilRetailLogRequest.class))).thenReturn(retailList);

		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/logs")
				.content(TestMockUtils.asJsonString(data.getRetailLogData()))
				.headers(billingHeader)
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)).andReturn();

//		assertEquals("Response Status", HttpStatus.OK.value(), result.getResponse().getStatus());
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus(),"Response Status");
		
	}
	
	@Test
	public void testPiBilRetailController_UpdateRetryCount() throws Exception {
		
		when(retailService.updateLogRetryCount(Mockito.any(LogUpdateRetryCountRequest.class)))
				.thenReturn(data.getRetailRetryCountResponse());
		
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/update/retryCount")
				.content(TestMockUtils.asJsonString(data.getRetailRetryCountData()))
				.headers(billingHeader)
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)).andReturn();
//		assertEquals("Response Status", HttpStatus.OK.value(), result.getResponse().getStatus());
		assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus(),"Response Status");

	}
	
}
