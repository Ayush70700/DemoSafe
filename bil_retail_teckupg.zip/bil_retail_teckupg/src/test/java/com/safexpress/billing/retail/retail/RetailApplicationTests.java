package com.safexpress.billing.retail.retail;

//import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.safexpress.billing.retail.service.IRetailService;

@SpringBootTest
class RetailApplicationTests {

	@Autowired
	private IRetailService retailService;
		
//	@Test
//	void testSubModule() {
//		assertEquals(true,true);
//	}
}
