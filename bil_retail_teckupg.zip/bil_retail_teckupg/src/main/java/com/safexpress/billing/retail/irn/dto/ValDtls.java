package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValDtls {

	@JsonProperty("AssVal") 
    public double assVal;
    @JsonProperty("CgstVal") 
    public double cgstVal;
    @JsonProperty("SgstVal") 
    public double sgstVal;
    @JsonProperty("IgstVal") 
    public double igstVal;
    @JsonProperty("CesVal") 
    public double cesVal;
    @JsonProperty("StCesVal") 
    public double stCesVal;
    @JsonProperty("Discount") 
    public double discount;
    @JsonProperty("OthChrg") 
    public double othChrg;
    @JsonProperty("RndOffAmt") 
    public Object rndOffAmt;
    @JsonProperty("TotInvVal") 
    public double totInvVal;
    @JsonProperty("TotInvValFc") 
    public double totInvValFc;
	public double getAssVal() {
		return assVal;
	}
	public double getCgstVal() {
		return cgstVal;
	}
	public double getSgstVal() {
		return sgstVal;
	}
	public double getIgstVal() {
		return igstVal;
	}
	public double getCesVal() {
		return cesVal;
	}
	public double getStCesVal() {
		return stCesVal;
	}
	public double getDiscount() {
		return discount;
	}
	public double getOthChrg() {
		return othChrg;
	}
	public Object getRndOffAmt() {
		return rndOffAmt;
	}
	public double getTotInvVal() {
		return totInvVal;
	}
	public double getTotInvValFc() {
		return totInvValFc;
	}
	public void setAssVal(double assVal) {
		this.assVal = assVal;
	}
	public void setCgstVal(double cgstVal) {
		this.cgstVal = cgstVal;
	}
	public void setSgstVal(double sgstVal) {
		this.sgstVal = sgstVal;
	}
	public void setIgstVal(double igstVal) {
		this.igstVal = igstVal;
	}
	public void setCesVal(double cesVal) {
		this.cesVal = cesVal;
	}
	public void setStCesVal(double stCesVal) {
		this.stCesVal = stCesVal;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public void setOthChrg(double othChrg) {
		this.othChrg = othChrg;
	}
	public void setRndOffAmt(Object rndOffAmt) {
		this.rndOffAmt = rndOffAmt;
	}
	public void setTotInvVal(double totInvVal) {
		this.totInvVal = totInvVal;
	}
	public void setTotInvValFc(double totInvValFc) {
		this.totInvValFc = totInvValFc;
	}
    
    
}
