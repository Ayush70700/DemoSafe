package com.safexpress.billing.retail.service;
/**
 * <h1>IRetailService</h1>
 * <P>
 * The IRetailService contains all the service methods required for Retail Billing.
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */


import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.safexpress.billing.retail.dto.BillAdditionalInfoDTO;
import com.safexpress.billing.retail.dto.BillInformationDTO;
import com.safexpress.billing.retail.dto.BillResponseDTO;
import com.safexpress.billing.retail.dto.BillSourceDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceBulkSearchDTO;
import com.safexpress.billing.retail.dto.EInvoiceSearchResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceUpdateRequestDTO;
import com.safexpress.billing.retail.dto.RetailBillDetailsDTO;
import com.safexpress.billing.retail.dto.RetailBillOsDTO;
import com.safexpress.billing.retail.dto.RetailBillsDetailsforReceiptDTO;
import com.safexpress.billing.retail.dto.RetailWayBillWriteOffDTO;
import com.safexpress.billing.retail.dto.RetailWaybillResponseDTO;
import com.safexpress.billing.retail.dto.SelfServiceRequestDTO;
import com.safexpress.billing.retail.dto.SelfServiceResponseDTO;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;
import com.safexpress.billing.retail.model.RetailBillBatchDetails;
import com.safexpress.billing.retail.model.RetailBillBatches;
public interface IRetailService { 

	/**
	 * method to Initiate B2B Retail Invoice Creation
	 * @return Nothing
	 * @param Nothing
	 * @throws CustomException 
	 */
	public List<RetailBillBatchDetails> initateB2BBatchCreation() throws URISyntaxException, CustomException;
	
	/**
	 * Method to Initiate B2C Retail Invoice Creation
	 * @return Nothing
	 * @param Nothing
	 * @throws CustomException 
	 */
	public List<RetailBillBatchDetails> initateB2CBatchCreation() throws URISyntaxException, CustomException;
	
	/**
	 * Method to Initiate Self Service Bill Creation
	 * @return Nothing
	 * @param Nothing
	 * @throws CustomException 
	 */
	public SelfServiceResponseDTO initateSSPBillCreation(SelfServiceRequestDTO sspRequestDto) throws URISyntaxException, CustomException;
    /**
     * Get SSP Retail Bills Detail by Bill Number
     * @param documentNumber
     * @return
     * @throws CustomException 
     */
	public List<RetailBillDetailsDTO> getBillDetailsByDocNum(String documentNumber, String documentWise,String sameBilingLevel) throws CustomException;

	/**
	 * Method to update Outstanding
	 * @param reqData
	 */
	public String updateBillOutstanding(List<RetailBillOsDTO> reqData);

	/**
	 * Method to get Retail Bill as Search params for collection app
	 * @param documentType
	 * @param documentNumber
	 * @param custId
	 * @param fromDate
	 * @param toDate
	 * @param branchId
	 * @return
	 * @throws CustomException 
	 */
	public List<RetailBillsDetailsforReceiptDTO> getRetailBillDetails(String documentType, String documentNumber,
			Long custId, String fromDate, String toDate, String branchId) throws CustomException;

	/**
	 * Method to get All applied retail bills by Id 
	 * @param documentIds
	 * @return
	 */
	public List<RetailBillsDetailsforReceiptDTO> getAppliedBills(String documentIds);

	/**
	 * Method to updated waybill write off to Oracle
	 * @param retailBill
	 * @return String
	 * @throws CustomException
	 */
	public String retailBillWriteOff(List<RetailWayBillWriteOffDTO> retailBill) throws CustomException;

	/**
	 * Method to updated Invoice Outstanding as per CMDM
	 * @param retailBill
	 * @return String
	 * @throws CustomException
	 */
	public List<CMDMInvoiceUpdateResponseDTO> updateCMDMInvoiceDetails(List<CMDMInvoiceUpdateDTO> requestDataList);
   
	/**
    * method to get Bill for IRN
    * @param errorFlag
    * @return
    */
	public List<IrnHeaderDTO> getB2bBills(String errorFlag);
	/**
	 * Method to save Irn info
	 * @param additionalInfo
	 * @return
	 */
	public String saveAdditionalDetails(List<BillAdditionalInfoDTO> additionalInfo);
	/**
	 * Method to get Waybills for Bill BatchDetails
	 * @param rbDetailList
	 * @throws URISyntaxException
	 * @throws CustomException
	 */
	public void fetchWaybillsForBatchDetails(List<RetailBillBatchDetails> rbDetailList)
			throws URISyntaxException, CustomException;
   /**
    * Method to group waybill into Bills
    * @param retWBResp
    * @param rbDetail
    * @param retailBillBatches
    * @return
    * @throws CustomException
    */
	public String processWaybillResponse(RetailWaybillResponseDTO retWBResp, RetailBillBatchDetails rbDetail,
			RetailBillBatches retailBillBatches) throws CustomException;

    /**
     * Method to validate Invoice number and GSTIN
     * @param invNum
     * @param gstIn
     */
	public Map<String, String> validateInvoice(String invNum, String gstIn);
    /**
     * Method to process each BatchDetails
     * @param rbDetailList
     * @throws CustomException 
     * @throws URISyntaxException 
     */
	public void processBatchDetail(List<RetailBillBatchDetails> rbDetailList) throws URISyntaxException, CustomException;
	
	/**
	 * Method to get Retail Bills for EInvoice
	 * 
	 * @param documentNumber
	 * @param billFromDt
	 * @param billToDt
	 * @param gstNumber
	 * @param irnFlag
	 * @param batchNumber
	 * @return
	 * @throws CustomException
	 */
	public List<EInvoiceSearchResponseDTO> getEInvoiceBills(String documentNumber, String billFromDt, String billToDt,
			String gstNumber, String irnFlag) throws CustomException;
	
	/**
	 * @Description Get Retail Bills for Einvoice
	 * @return
	 * @throws CustomException
	 */
	public List<EInvoiceSearchResponseDTO> getEInvoiceBills(List<EInvoiceBulkSearchDTO> bulkSearch) throws CustomException;
	
	/**
	 * Method to update Selected Bill and set IRN flag Null
	 * 
	 * @param updateDetails
	 * @return
	 * @throws CustomException
	 */
	public String updateEinvBulkBills(List<EInvoiceUpdateRequestDTO> updateDetails) throws CustomException;
	
	/**
	 * Method to update data to Oracle GL
	 * 
	 * @return
	 */
	public CompletableFuture<Void> asyncUpdateToOracleGL();
	
	public void sendNotificationForFailedGL();
	
	public CompletableFuture<Void> resendRetailMails();
	public String updateRetailBillsEmailDetails(List<BillAdditionalInfoDTO> additionalInfo);
	public CompletableFuture<Void> reprocessEReportGeneration();
	public String updateRetailBillsReportGen(List<BillAdditionalInfoDTO> additionalInfo);	
	

	public List<BillResponseDTO> getBillSourceDetails(BillInformationDTO billInfoDTO) throws CustomException;
}
