package com.safexpress.billing.retail.dto;

public class WaybilDetailRequestDTO {

	private String retailBillNum;

	public String getRetailBillNum() {
		return retailBillNum;
	}

	public void setRetailBillNum(String retailBillNum) {
		this.retailBillNum = retailBillNum;
	}

}
