package com.safexpress.billing.retail.dto;

public class JwtAuthenticationResponseDTO {

	private String accessToken;
    private String tokenType = "Bearer";
    private String billingUserName;
    private String branchId;
    private String branchCode;
	public String getAccessToken() {
		return accessToken;
	}
	public String getTokenType() {
		return tokenType;
	}
	public String getBillingUserName() {
		return billingUserName;
	}
	public String getBranchId() {
		return branchId;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}
	public void setBillingUserName(String billingUserName) {
		this.billingUserName = billingUserName;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}    
    
}
