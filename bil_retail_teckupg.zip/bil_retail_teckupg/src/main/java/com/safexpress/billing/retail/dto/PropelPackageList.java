package com.safexpress.billing.retail.dto;

import java.util.Date;

public class PropelPackageList {
	private int actualWeight;
    private int bookingReqId;
    private Date createdDate;
    private String customerPackageId;
    private int lbhUomLookupId;
    private int numOfPackage;
    private int numOfPieces;
    private int packTypeLookupId;
    private int packageDetailsId;
    private int pkgBreadth;
    private int pkgHeight;
    private int pkgLength;
    private int productCategoryId;
    private int productId;
    private String userId;
    private String userType;
    private int volumeWeight;
	public int getActualWeight() {
		return actualWeight;
	}
	public void setActualWeight(int actualWeight) {
		this.actualWeight = actualWeight;
	}
	public int getBookingReqId() {
		return bookingReqId;
	}
	public void setBookingReqId(int bookingReqId) {
		this.bookingReqId = bookingReqId;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getCustomerPackageId() {
		return customerPackageId;
	}
	public void setCustomerPackageId(String customerPackageId) {
		this.customerPackageId = customerPackageId;
	}
	public int getLbhUomLookupId() {
		return lbhUomLookupId;
	}
	public void setLbhUomLookupId(int lbhUomLookupId) {
		this.lbhUomLookupId = lbhUomLookupId;
	}
	public int getNumOfPackage() {
		return numOfPackage;
	}
	public void setNumOfPackage(int numOfPackage) {
		this.numOfPackage = numOfPackage;
	}
	public int getNumOfPieces() {
		return numOfPieces;
	}
	public void setNumOfPieces(int numOfPieces) {
		this.numOfPieces = numOfPieces;
	}
	public int getPackTypeLookupId() {
		return packTypeLookupId;
	}
	public void setPackTypeLookupId(int packTypeLookupId) {
		this.packTypeLookupId = packTypeLookupId;
	}
	public int getPackageDetailsId() {
		return packageDetailsId;
	}
	public void setPackageDetailsId(int packageDetailsId) {
		this.packageDetailsId = packageDetailsId;
	}
	public int getPkgBreadth() {
		return pkgBreadth;
	}
	public void setPkgBreadth(int pkgBreadth) {
		this.pkgBreadth = pkgBreadth;
	}
	public int getPkgHeight() {
		return pkgHeight;
	}
	public void setPkgHeight(int pkgHeight) {
		this.pkgHeight = pkgHeight;
	}
	public int getPkgLength() {
		return pkgLength;
	}
	public void setPkgLength(int pkgLength) {
		this.pkgLength = pkgLength;
	}
	public int getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public int getVolumeWeight() {
		return volumeWeight;
	}
	public void setVolumeWeight(int volumeWeight) {
		this.volumeWeight = volumeWeight;
	} 
}
