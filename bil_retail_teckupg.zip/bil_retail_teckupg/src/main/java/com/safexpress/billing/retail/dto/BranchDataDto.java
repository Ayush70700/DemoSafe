package com.safexpress.billing.retail.dto;

public class BranchDataDto {
	private String branchId;
	private String branchCode;
	private String branchName;
	private String email;
	private String branchGstNum;
	
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBranchGstNum() {
		return branchGstNum;
	}
	public void setBranchGstNum(String branchGstNum) {
		this.branchGstNum = branchGstNum;
	}
}
