package com.safexpress.billing.retail.dto;

import java.util.List;

public class TestDTO {


	private List<String> billNum;

	public List<String> getBillNum() {
		return billNum;
	}

	public void setBillNum(List<String> billNum) {
		this.billNum = billNum;
	}
}
