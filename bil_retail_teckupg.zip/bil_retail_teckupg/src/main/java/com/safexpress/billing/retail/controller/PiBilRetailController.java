package com.safexpress.billing.retail.controller;

import java.text.ParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.safexpress.billing.retail.model.LogUpdateRetryCountRequest;
import com.safexpress.billing.retail.model.LogUpdateRetryCountResponse;
import com.safexpress.billing.retail.model.PiBilRetailLogRequest;
import com.safexpress.billing.retail.model.PiBilRetailLogResponse;
import com.safexpress.billing.retail.service.PiBilRetailLogService;

import io.swagger.v3.oas.annotations.Operation;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/")
public class PiBilRetailController {
	
	private static final Logger logger = LoggerFactory.getLogger(PiBilRetailController.class);
		
	@Autowired
	PiBilRetailLogService pbrls;
	
	@Operation(summary =  "Method to get Retail Logs")
	@PostMapping(path = "/logs", produces = "application/json")
	public ResponseEntity<List<PiBilRetailLogResponse>> getRetailLogs(@RequestBody PiBilRetailLogRequest rlr) throws ParseException {
		
		logger.info("---- PiBilRetailController ---- getRetailLogs ----");
		
		List<PiBilRetailLogResponse> response = pbrls.getRetailApiLogsInfo(rlr);
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@Operation(summary = "Method to update Retry Count 5 to 0")
	@PostMapping(path = "/update/retryCount", produces = "application/json")
	public ResponseEntity<LogUpdateRetryCountResponse> updateLogRetryCountValue(@RequestBody LogUpdateRetryCountRequest req) {
		
		logger.info("---- PiBilRetailController ---- updateLogRetryCountValue ----");
		
		LogUpdateRetryCountResponse response = pbrls.updateLogRetryCount(req);
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
		
	}
	
}
