package com.safexpress.billing.retail.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.safexpress.billing.retail.dto.CustomEmailPayloadDTO;
import com.safexpress.billing.retail.dto.GLInterfaceLine;
import com.safexpress.billing.retail.model.RetailBillIntegrations;
import com.safexpress.billing.retail.model.RetailBills;
import com.safexpress.billing.retail.model.RetailDocDeviationHistory;
import com.safexpress.billing.retail.model.RetailGLEvents;
import com.safexpress.billing.retail.repository.IRetailBillIntegrationsRepository;
import com.safexpress.billing.retail.repository.IRetailBillsRepository;
import com.safexpress.billing.retail.repository.IRetailDocDeviationHistoryRepository;
import com.safexpress.billing.retail.repository.IRetailGLEventsRepository;
import com.safexpress.billing.retail.util.Constants;
import com.safexpress.billing.retail.util.NotificationUtility;
import com.safexpress.billing.retail.util.OracleJournelUtil;

@Service
@Transactional
public class ReatilOracleFusionServiceImpl implements IReatilOracleFusionService {

	@Autowired
	IRetailGLEventsRepository iRetailGLEventsRepository;

	@Autowired
	IRetailBillIntegrationsRepository iRetailBillIntegrationsRepository;

	@Autowired
	IRetailDocDeviationHistoryRepository iRetailDocDeviationHistoryRepository;

	@Autowired
	private IRetailBillsRepository retailBillsRepository;
	
	@Autowired
	OracleJournelUtil oracleJournelUtil;

	@Autowired
	NotificationUtility notificationUtility;
	
	@Value("${integration.retry.count}")
	private Integer retryCountValue;

	private static final Logger log = LoggerFactory.getLogger(ReatilOracleFusionServiceImpl.class);

	// @Scheduled(fixedRate = 300000)
	public void oracleIntegration() {
		// logger
		setLogHeaderInfo(Constants.getUserName());

		// way Bill write off
		fusionRetailWriteOffGlIntg();

		// send notifications if any error
		sendFailureNotification();
	}

	@Retryable
	@Override
	@Async
	public void fusionRetailWriteOffGlIntg() {
		log.info("Entering: fusionRetailWriteOffGlIntg()");
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		String batchName = "RetailWriteOff-SFX-" + new Date();
		// extract Allied Retail Bill write-off records
		List<RetailBillIntegrations> unprocessedRecords = iRetailBillIntegrationsRepository
				.findUnprocessedGLRecords(Constants.RETAIL_WRITEOFF_STATUS, retryCountValue);
		for (RetailBillIntegrations record : unprocessedRecords) {
			List<RetailDocDeviationHistory> retailDocDeviationHistoryList = iRetailDocDeviationHistoryRepository
					.findBySourceRefId(record.getSourceRefId());
			for (RetailDocDeviationHistory historyRecord : retailDocDeviationHistoryList) {
				List<RetailGLEvents> glEvents = iRetailGLEventsRepository
						.findGLSegments(Constants.RETAIL_WRITEOFF_STATUS, historyRecord.getDocType());
//				interfaceLines = oracleJournelUtil.createJournalLinesforWriteoff(glEvents, historyRecord.getDocNum(),
//						BigDecimal.valueOf(historyRecord.getAmount()), historyRecord.getWriteOffDate());
				interfaceLines.addAll(oracleJournelUtil.createJournalLinesforWriteoff(glEvents, historyRecord.getDocNum(),
						BigDecimal.valueOf(historyRecord.getAmount()), historyRecord.getWriteOffDate()));

			}

		}
		try {
			if (!interfaceLines.isEmpty()) {
				oracleJournelUtil.createJournal(batchName, batchName, interfaceLines);
				updateSuccessStatus(unprocessedRecords);
			}
		} catch (Exception ex) {
			log.error("Error in fusionRetailWriteOffGlIntg: {} ", ex.getMessage());
			updateFailureStatus(unprocessedRecords, ex);
		}
		log.info("Exiting: fusionRetailWriteOffGlIntg()");

		// send notification if any error found
		sendFailureNotification();
	}
	/**
	 * Method to integrate all retail bills to GL
	 */
	@Override
	@Async
	public void fusionRetailBillGlIntg() {
		log.info("Entering: fusionRetailBillGlIntg()");
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		String batchName = "RetailBillCreation-SFX-" + new Date();
		List<RetailBillIntegrations> unprocessedRecords = iRetailBillIntegrationsRepository
				.findUnprocessedGLRecords(Constants.RETAIL_BILL_CREATION, retryCountValue);
		List<RetailBillIntegrations> processedRec= new ArrayList<>();
		log.info("fusionRetailBillGlIntg: unprocessedRecords count {} ",unprocessedRecords.size());
		for (RetailBillIntegrations record : unprocessedRecords) {
			RetailBills retailBills = retailBillsRepository.getOne(record.getSourceRefId());
			if("B2C".equals(retailBills.getBillCtgy()) || retailBills.getIrn()!=null) {
				processedRec.add(record);
				List<RetailGLEvents> glEvents = iRetailGLEventsRepository
							.findGLSegments(Constants.RETAIL_BILL_CREATION, retailBills.getBillType());
//				interfaceLines = oracleJournelUtil.createJournalLines(glEvents, retailBills);
				interfaceLines.addAll(oracleJournelUtil.createJournalLines(glEvents, retailBills));
			}
		}
		
		try {
			if (!interfaceLines.isEmpty()) {
				log.error("Before: createJournal:batchName: {} ", batchName);
				oracleJournelUtil.createJournal(batchName, batchName, interfaceLines);
				log.error("After: createJournal:batchName: {} ", batchName);
				updateSuccessStatus(processedRec);
			}
		} catch (Exception ex) {
			log.error("Error in fusionRetailBillGlIntg: {} ", ex.getMessage());
			log.info("Error in fusionRetailBillGlIntg: {} ", ex.getMessage());
			updateFailureStatus(processedRec, ex);
		}
		log.info("Exiting: fusionRetailBillGlIntg()");

		// send notification if any error found
//		sendFailureNotification();
	}

	/**
	 * This method is to update success status post integration.
	 * 
	 * @param List<AlliedBillsIntegrations>
	 */
	private void updateSuccessStatus(List<RetailBillIntegrations> unprocessedRecords) {
		for (RetailBillIntegrations row : unprocessedRecords) {
			log.info("updateStatus-integration Id: {}", row.getIntegrationId());
			row.setStatus(Constants.INTEGRATION_SUCCESS_STATUS);
			row.setMessage(null);
			row.setUpdBy(Constants.getUserName());
			iRetailBillIntegrationsRepository.save(row);
		}
	}

	/**
	 * This method is to update error status post integration.
	 * 
	 * @param List<AlliedBillsIntegrations>
	 */
	private void updateFailureStatus(List<RetailBillIntegrations> unprocessedRecords, Exception ex) {
		for (RetailBillIntegrations row : unprocessedRecords) {
			row.setStatus(Constants.ERROR_STATUS);
			row.setRetryCount(row.getRetryCount() + 1);
			row.setUpdBy(Constants.getUserName());
			if (ex.getMessage() != null && ex.getMessage().length() <= 253) {
				row.setMessage(ex.getMessage());
			} else {
				row.setMessage(ex.getMessage() != null ? ex.getMessage().substring(1, 253) : null);
			}
			iRetailBillIntegrationsRepository.save(row);
		}
	}

	/**
	 * This method is to set the log HeaderInfo
	 * 
	 * @param userName
	 * @param contextPath
	 * @param private
	 * @return Nothing
	 */
	private void setLogHeaderInfo(String userName) {
		// get correlation ID
		String sessionId = generateUniqueCorrelationId();
		String headerInfo = "<" + sessionId + "|/|" + userName + ">:";
		MDC.put("headerInfo", headerInfo);
	}

	/**
	 * This method is to generate random CorrelationId
	 * 
	 * @param Nothing
	 * @return String
	 */
	private String generateUniqueCorrelationId() {
		return UUID.randomUUID().toString();
	}

	/**
	 * This method is to send failure Notification
	 */
	private void sendFailureNotification() {
		// Retail Way Bill notification write-off
		CustomEmailPayloadDTO customEmailPayloadDTO = notificationUtility.sendWaybillWriteOffFailureNtfy();
		if (customEmailPayloadDTO.getErrCount() > 0) {
			notificationUtility.sendMailNotification(customEmailPayloadDTO);
		}

	}
	
	
	@Override
	@Async
	public void fusionRetailBillGlIntegration(List<String> status) {
		log.info("Entering: fusionRetailBillGlIntegration()");
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		String batchName = "RetailBillCreation-SFX-" + new Date();
		List<RetailBillIntegrations> unprocessedRecords = iRetailBillIntegrationsRepository
				.findUnprocessedGLRecordsByStatus(status, Constants.RETAIL_BILL_CREATION, retryCountValue);
		List<RetailBillIntegrations> processedRec= new ArrayList<>();
		for (RetailBillIntegrations record : unprocessedRecords) {
			log.info("Unprocessed Record "+record.getSourceRefId());
			RetailBills retailBills = retailBillsRepository.getOne(record.getSourceRefId());
			if("B2C".equals(retailBills.getBillCtgy()) || retailBills.getIrn()!=null) {
				processedRec.add(record);
				List<RetailGLEvents> glEvents = iRetailGLEventsRepository
							.findGLSegments(Constants.RETAIL_BILL_CREATION, retailBills.getBillType());
				interfaceLines.addAll(oracleJournelUtil.createJournalLines(glEvents, retailBills));
			}
		}
		
		try {
			if (!interfaceLines.isEmpty()) {
				Gson g = new Gson();
				log.info("interfaceLines "+g.toJson(interfaceLines));
				oracleJournelUtil.createJournal(batchName, batchName, interfaceLines);
				updateSuccessStatus(processedRec);
			}
		} catch (Exception ex) {
			log.error("Error in fusionRetailBillGlIntg: {} ", ex.getMessage());
			updateFailureStatus(processedRec, ex);
		}
		log.info("Exiting: fusionRetailBillGlIntegration()");
	}
	
	
	@Retryable
	@Override
	@Async
	public void fusionRetailWriteOffGlIntegration(List<String> status) {
		log.info("Entering: fusionRetailWriteOffGlIntegration()");
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		String batchName = "RetailWriteOff-SFX-" + new Date();
		// extract Allied Retail Bill write-off records
		List<RetailBillIntegrations> unprocessedRecords = iRetailBillIntegrationsRepository
				.findUnprocessedGLRecordsByStatus(status, Constants.RETAIL_WRITEOFF_STATUS, retryCountValue);
		
		for (RetailBillIntegrations record : unprocessedRecords) {
			List<RetailDocDeviationHistory> retailDocDeviationHistoryList = iRetailDocDeviationHistoryRepository
					.findBySourceRefId(record.getSourceRefId());
			for (RetailDocDeviationHistory historyRecord : retailDocDeviationHistoryList) {
				List<RetailGLEvents> glEvents = iRetailGLEventsRepository
						.findGLSegments(Constants.RETAIL_WRITEOFF_STATUS, historyRecord.getDocType());
				interfaceLines.addAll(oracleJournelUtil.createJournalLinesforWriteoff(glEvents, historyRecord.getDocNum(),
						BigDecimal.valueOf(historyRecord.getAmount()), historyRecord.getWriteOffDate()));

			}

		}
		try {
			if (!interfaceLines.isEmpty()) {
				oracleJournelUtil.createJournal(batchName, batchName, interfaceLines);
				updateSuccessStatus(unprocessedRecords);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error("Error in fusionRetailWriteOffGlIntg: {} ", ex.getMessage());
			updateFailureStatus(unprocessedRecords, ex);
		}
		
		log.info("Exiting: fusionRetailWriteOffGlIntegration()");

		// send notification if any error found
		sendFailureNotification();
	}
}
