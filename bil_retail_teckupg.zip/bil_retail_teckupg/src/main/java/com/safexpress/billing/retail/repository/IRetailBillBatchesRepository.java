package com.safexpress.billing.retail.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.safexpress.billing.retail.model.RetailBillBatches;

public interface IRetailBillBatchesRepository extends JpaRepository<RetailBillBatches, Long>{

}
