package com.safexpress.billing.retail.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UntagRetailBillWaybillRequest {
	
	@JsonProperty("waybillIdList")
	private List<Long> waybillIdList;
	
	@JsonProperty("billNumber")
	private String billNumber;

	/**
	 * @return the waybillIdList
	 */
	public List<Long> getWaybillIdList() {
		return waybillIdList;
	}

	/**
	 * @param waybillIdList the waybillIdList to set
	 */
	public void setWaybillIdList(List<Long> waybillIdList) {
		this.waybillIdList = waybillIdList;
	}

	/**
	 * @return the billNumber
	 */
	public String getBillNumber() {
		return billNumber;
	}

	/**
	 * @param billNumber the billNumber to set
	 */
	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}
	
	
	
	

}
