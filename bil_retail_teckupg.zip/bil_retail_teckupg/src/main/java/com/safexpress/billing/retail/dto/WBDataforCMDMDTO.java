package com.safexpress.billing.retail.dto;

public class WBDataforCMDMDTO {
	private Long waybillId;
	private String waybillNum;
	private String billType;
	private Double amount;
	private Double outstandingAmount;
	private Double ttlTaxAmt;
	private Double cgstAmt;
	private Double igstAmt;
	private Double sgstAmt;
	
	public Long getWaybillId() {
		return waybillId;
	}
	public void setWaybillId(Long waybillId) {
		this.waybillId = waybillId;
	}
	public String getWaybillNum() {
		return waybillNum;
	}
	public void setWaybillNum(String waybillNum) {
		this.waybillNum = waybillNum;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getTtlTaxAmt() {
		return ttlTaxAmt;
	}
	public void setTtlTaxAmt(Double ttlTaxAmt) {
		this.ttlTaxAmt = ttlTaxAmt;
	}
	public Double getCgstAmt() {
		return cgstAmt;
	}
	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public Double getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}
	public Double getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public Double getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	
	
}
