package com.safexpress.billing.retail.config;
/******************************************************************
* <h1>DBConfiguration</h1>
* This is the configuration file. 
* The data from the application.properties will be loaded onto application. 
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.safexpress.billing.retail.util.Constants;

@Configuration
@PropertySource(value = { "classpath:application.properties" })
public class DBConfiguration {
	@Value("${spring.datasource.driver-class-name}")
	private String driverClass;
	@Value("${spring.datasource.url}")
	private String url;
	@Value("${spring.datasource.username}")
	private String username;
	@Value("${spring.datasource.password}")
	private String password;
	@Value("${spring.jpa.properties.hibernate.dialect}")
	private String dialect;
	
	@Value("${retail.waybill.api}")
	private String retailWaybillApiVal;
	@Value("${retail.billCtgy.b2b}")
	private String retailBillB2BCtgyVal;
	@Value("${retail.billCtgy.b2c}")
	private String retailBillB2CCtgyVal;
	@Value("${retail.billbatch.type}")
	private String retailBatchTypeVal;
	@Value("${retail.source.ssp}")
	private String retailSelfServiceSourcesVal;
	@Value("${retail.source.app}")
	private String retailBillingSourcesVal;
	@Value("${retail.timeLaps.days}")
	private String retailTimeLapseinDaysVal;
	@Value("${propel.branch.api}")
	private String propelBranchApi;	
	@Value("${billing.admin.user}")
	private String billingAdminUser;
	/**
	 * setting up of username and password
	 * 
	 * @return dataSource
	 */
	@Bean
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource(url, username, password);
		dataSource.setDriverClassName(driverClass);
		return dataSource;
	}

	/**
	 * setting session factory and setPackagesToScan for all entities
	 * 
	 * @return factory
	 */
	@Bean(name="entityManagerFactory")
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean factory = new LocalSessionFactoryBean();
		factory.setDataSource(getDataSource());
		factory.setHibernateProperties(hibernateProperties());
		factory.setPackagesToScan("com.safexpress.billing.retail.model");
		return factory;
	}
    /**
     * Setting hibernateProperties
     * 
     * @return properties
     */
	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", dialect);
		properties.put("hibernate.hbm2ddl.auto", "update");
		return properties;
	}

	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory factory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(factory);
		return transactionManager;
	}
	
	/**
	* To load the other system configuration into respective constants.
	* @param Nothing.
	* @return Nothing.
	* @exception Nothing
	*/
	@Bean  
    public String setOtherApplication(){
		Constants.setRetailBatchType(this.retailBatchTypeVal);
		Constants.setRetailBillB2BCtgy(this.retailBillB2BCtgyVal);
		Constants.setRetailBillB2CCtgy(this.retailBillB2CCtgyVal);
		Constants.setRetailWaybillApi(this.retailWaybillApiVal);
		Constants.setRetailBillingSources(this.retailBillingSourcesVal);
		Constants.setRetailSelfServiceSources(this.retailSelfServiceSourcesVal);
		Constants.setRetailTimeLapseinDays(this.retailTimeLapseinDaysVal);
		Constants.setPropelBranchApi(this.propelBranchApi);
		Constants.setBillingAdminUser(this.billingAdminUser);
		return "set other application successfully";
    }
	
}
