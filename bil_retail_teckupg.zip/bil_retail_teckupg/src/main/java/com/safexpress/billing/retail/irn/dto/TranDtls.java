package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TranDtls {

	@JsonProperty("TaxSch") 
    public String taxSch;
    @JsonProperty("SupTyp") 
    public String supTyp;
    @JsonProperty("RegRev") 
    public String regRev;
    @JsonProperty("EcmGstin") 
    public Object ecmGstin;
    @JsonProperty("IgstOnIntra") 
    public Object igstOnIntra;
	public String getTaxSch() {
		return taxSch;
	}
	public String getSupTyp() {
		return supTyp;
	}
	public String getRegRev() {
		return regRev;
	}
	public Object getEcmGstin() {
		return ecmGstin;
	}
	public Object getIgstOnIntra() {
		return igstOnIntra;
	}
	public void setTaxSch(String taxSch) {
		this.taxSch = taxSch;
	}
	public void setSupTyp(String supTyp) {
		this.supTyp = supTyp;
	}
	public void setRegRev(String regRev) {
		this.regRev = regRev;
	}
	public void setEcmGstin(Object ecmGstin) {
		this.ecmGstin = ecmGstin;
	}
	public void setIgstOnIntra(Object igstOnIntra) {
		this.igstOnIntra = igstOnIntra;
	}   
    
}
