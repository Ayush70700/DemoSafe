package com.safexpress.billing.retail.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.ws.client.core.WebServiceTemplate;

/**
 * The Class SoapClientConfig.
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-08-05
 */
@Configuration
@EnableRetry
@PropertySource(value = { "classpath:application.properties" })
public class SoapClientConfig {

	/** The user name. */
	@Value("${cloud.oracle.username}")
	private String userName;

	/** The user password. */
	@Value("${cloud.oracle.password}")
	private String userPassword;

	/** The default URI journal service. */
	@Value("${soapClient.defaultUriJournalService}")
	private String defaultUriJournalService;

	/** The WSDL path location. */
	@Value("${soapClient.wsdlPath.journal.import}")
	private String wsdlPathJournal;

	/**
	 * Web service template receipts service.
	 *
	 * @return the web service template
	 */
	@Bean(name = "webServiceTemplateJournalService")
	public WebServiceTemplate webServiceTemplateJournalService() {
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(jaxb2MarshallerJournalService());
		webServiceTemplate.setUnmarshaller(jaxb2MarshallerJournalService());
		webServiceTemplate.setDefaultUri(defaultUriJournalService);
		return webServiceTemplate;
	}

	/**
	 * Jaxb 2 marshaller Journal import service.
	 *
	 * @return the jaxb 2 marshaller
	 */
	@Bean
	Jaxb2Marshaller jaxb2MarshallerJournalService() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPath(wsdlPathJournal);
		return jaxb2Marshaller;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserPassword() {
		return userPassword;
	}
}