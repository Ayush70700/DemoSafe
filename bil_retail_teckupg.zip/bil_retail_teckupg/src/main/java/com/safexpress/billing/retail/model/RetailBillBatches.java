package com.safexpress.billing.retail.model;
/**
 * <h1>RetailBillBatches</h1>
 * <P>
 * The RetailBillBatches is model class for retail_bill_batches table.
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="retail_bill_batches", schema = "bil_retail")
public class RetailBillBatches extends BaseModel{
	
	private Long billBatchId;
	private Long batchNum;
	private Date requestDt;
	private String batchType;
	private String source;
	private String status;
	private String phase;
	private String message;
	private List<RetailBillBatchDetails> retailBillBatchDetails = new ArrayList<>();
	private List<RetailBills> retailBills = new ArrayList<>();
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bill_batch_id")
	public Long getBillBatchId() {
		return billBatchId;
	}

	public void setBillBatchId(Long billBatchId) {
		this.billBatchId = billBatchId;
	}

	@Column(name = "batch_num")
	public Long getBatchNum() {
		return batchNum;
	}

	public void setBatchNum(Long batchNum) {
		this.batchNum = batchNum;
	}

	@Column(name = "request_dt")
	public Date getRequestDt() {
		return requestDt;
	}

	public void setRequestDt(Date requestDt) {
		this.requestDt = requestDt;
	}

	@Column(name = "batch_type")
	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	@Column(name = "source")
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Column(name = "status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "phase")
	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	@Column(name = "message")
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "retailBillBatches")
	public List<RetailBillBatchDetails> getRetailBillBatchDetails() {
		return retailBillBatchDetails;
	}

	public void setRetailBillBatchDetails(List<RetailBillBatchDetails> retailBillBatchDetails) {
		this.retailBillBatchDetails = retailBillBatchDetails;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "retailBillBatches")
	public List<RetailBills> getRetailBills() {
		return retailBills;
	}

	public void setRetailBills(List<RetailBills> retailBills) {
		this.retailBills = retailBills;
	}

	
}
