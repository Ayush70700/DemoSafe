package com.safexpress.billing.retail.dto;

public class WbDataDTO {
	private Double baseAmount;
	private Double cgstAmount;
	private String createdDate;
	private String deliveryDate;
	private String destinationCode;
	private long destinationId;
    private String billinLevelCode;
    private long billinLevelId;
    private Double igstAmount;
    private String originCode;
    private Double outstandingAmount;
    private String pickupDate;
    private long pkg;
    private String sfxCode;
    private Double sgstAmount;
    private Double ttlTaxAmount;
    private long documentid;
    private String documentNumber;
    private String documentType;
    private Double weight;
    private long  originId;
	public Double getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(Double baseAmount) {
		this.baseAmount = baseAmount;
	}
	public Double getCgstAmount() {
		return cgstAmount;
	}
	public void setCgstAmount(Double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getDestinationCode() {
		return destinationCode;
	}
	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}
	public long getDestinationId() {
		return destinationId;
	}
	public void setDestinationId(long destinationId) {
		this.destinationId = destinationId;
	}
	public String getBillinLevelCode() {
		return billinLevelCode;
	}
	public void setBillinLevelCode(String billinLevelCode) {
		this.billinLevelCode = billinLevelCode;
	}
	public long getBillinLevelId() {
		return billinLevelId;
	}
	public void setBillinLevelId(long billinLevelId) {
		this.billinLevelId = billinLevelId;
	}
	public Double getIgstAmount() {
		return igstAmount;
	}
	public void setIgstAmount(Double igstAmount) {
		this.igstAmount = igstAmount;
	}
	public String getOriginCode() {
		return originCode;
	}
	public void setOriginCode(String originCode) {
		this.originCode = originCode;
	}
	public Double getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	public String getPickupDate() {
		return pickupDate;
	}
	public void setPickupDate(String pickupDate) {
		this.pickupDate = pickupDate;
	}
	public long getPkg() {
		return pkg;
	}
	public void setPkg(long pkg) {
		this.pkg = pkg;
	}
	public String getSfxCode() {
		return sfxCode;
	}
	public void setSfxCode(String sfxCode) {
		this.sfxCode = sfxCode;
	}
	public Double getSgstAmount() {
		return sgstAmount;
	}
	public void setSgstAmount(Double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}
	public Double getTtlTaxAmount() {
		return ttlTaxAmount;
	}
	public void setTtlTaxAmount(Double ttlTaxAmount) {
		this.ttlTaxAmount = ttlTaxAmount;
	}
	public long getDocumentid() {
		return documentid;
	}
	public void setDocumentid(long documentid) {
		this.documentid = documentid;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	public long getOriginId() {
		return originId;
	}
	public void setOriginId(long originId) {
		this.originId = originId;
	}
	
	
}
