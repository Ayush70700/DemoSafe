package com.safexpress.billing.retail.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PiBilRetailLogResponse {
	
	private Long integrationId;
	private String sourceRefId;
	private String event;
	private String source;
	private String dest;
	private String billType;
	private String sourceDocAmt;
	private String paymentScheduleId;
	private String destRefId;
	private String status;
	private String message;
	private String ver;
	private Integer retryCount; 
	
	@JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
	private Date crDt;

	private String crBy;

	@JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
	private Date updDt;
	
	private String updBy;
	private String attr1;
	private String attr2;
	private String attr3;
	private String attr4;
	private String attr5;
	/**
	 * @return the integrationId
	 */
	public Long getIntegrationId() {
		return integrationId;
	}
	/**
	 * @param integrationId the integrationId to set
	 */
	public void setIntegrationId(Long integrationId) {
		this.integrationId = integrationId;
	}
	/**
	 * @return the sourceRefId
	 */
	public String getSourceRefId() {
		return sourceRefId;
	}
	/**
	 * @param sourceRefId the sourceRefId to set
	 */
	public void setSourceRefId(String sourceRefId) {
		this.sourceRefId = sourceRefId;
	}
	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}
	/**
	 * @param event the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}
	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}
	/**
	 * @return the dest
	 */
	public String getDest() {
		return dest;
	}
	/**
	 * @param dest the dest to set
	 */
	public void setDest(String dest) {
		this.dest = dest;
	}
	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}
	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}
	/**
	 * @return the sourceDocAmt
	 */
	public String getSourceDocAmt() {
		return sourceDocAmt;
	}
	/**
	 * @param sourceDocAmt the sourceDocAmt to set
	 */
	public void setSourceDocAmt(String sourceDocAmt) {
		this.sourceDocAmt = sourceDocAmt;
	}
	/**
	 * @return the paymentScheduleId
	 */
	public String getPaymentScheduleId() {
		return paymentScheduleId;
	}
	/**
	 * @param paymentScheduleId the paymentScheduleId to set
	 */
	public void setPaymentScheduleId(String paymentScheduleId) {
		this.paymentScheduleId = paymentScheduleId;
	}
	/**
	 * @return the destRefId
	 */
	public String getDestRefId() {
		return destRefId;
	}
	/**
	 * @param destRefId the destRefId to set
	 */
	public void setDestRefId(String destRefId) {
		this.destRefId = destRefId;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the ver
	 */
	public String getVer() {
		return ver;
	}
	/**
	 * @param ver the ver to set
	 */
	public void setVer(String ver) {
		this.ver = ver;
	}
	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}
	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}
	/**
	 * @return the crDt
	 */
	public Date getCrDt() {
		return crDt;
	}
	/**
	 * @param crDt the crDt to set
	 */
	public void setCrDt(Date crDt) {
		this.crDt = crDt;
	}
	/**
	 * @return the crBy
	 */
	public String getCrBy() {
		return crBy;
	}
	/**
	 * @param crBy the crBy to set
	 */
	public void setCrBy(String crBy) {
		this.crBy = crBy;
	}
	/**
	 * @return the updDt
	 */
	public Date getUpdDt() {
		return updDt;
	}
	/**
	 * @param updDt the updDt to set
	 */
	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}
	/**
	 * @return the updBy
	 */
	public String getUpdBy() {
		return updBy;
	}
	/**
	 * @param updBy the updBy to set
	 */
	public void setUpdBy(String updBy) {
		this.updBy = updBy;
	}
	/**
	 * @return the attr1
	 */
	public String getAttr1() {
		return attr1;
	}
	/**
	 * @param attr1 the attr1 to set
	 */
	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}
	/**
	 * @return the attr2
	 */
	public String getAttr2() {
		return attr2;
	}
	/**
	 * @param attr2 the attr2 to set
	 */
	public void setAttr2(String attr2) {
		this.attr2 = attr2;
	}
	/**
	 * @return the attr3
	 */
	public String getAttr3() {
		return attr3;
	}
	/**
	 * @param attr3 the attr3 to set
	 */
	public void setAttr3(String attr3) {
		this.attr3 = attr3;
	}
	/**
	 * @return the attr4
	 */
	public String getAttr4() {
		return attr4;
	}
	/**
	 * @param attr4 the attr4 to set
	 */
	public void setAttr4(String attr4) {
		this.attr4 = attr4;
	}
	/**
	 * @return the attr5
	 */
	public String getAttr5() {
		return attr5;
	}
	/**
	 * @param attr5 the attr5 to set
	 */
	public void setAttr5(String attr5) {
		this.attr5 = attr5;
	}
	
}
