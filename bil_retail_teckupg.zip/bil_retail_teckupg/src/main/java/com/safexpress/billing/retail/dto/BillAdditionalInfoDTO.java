package com.safexpress.billing.retail.dto;
/******************************************************************
* <h1>Bill Additional Info</h1>
* DTO for additional Bill information
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
public class BillAdditionalInfoDTO {
	Long billId;
	String irn;
	String ackNo;
	String ackDt;
	String signedQrCode;
	boolean emailSent;
	boolean acknowledged;
	boolean sendingFailed;
	String s3DocumentKey;
	String s3BucketName;
	String status;
	String errorDetails;
	String source; // IRN , REPORTING
	String buyerLoc;
	public Long getBillId() {
		return billId;
	}
	public String getIrn() {
		return irn;
	}
	public String getAckNo() {
		return ackNo;
	}
	public String getAckDt() {
		return ackDt;
	}	
	
	public String getS3DocumentKey() {
		return s3DocumentKey;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	public void setIrn(String irn) {
		this.irn = irn;
	}
	public void setAckNo(String ackNo) {
		this.ackNo = ackNo;
	}
	public void setAckDt(String ackDt) {
		this.ackDt = ackDt;
	}
	
	public void setS3DocumentKey(String s3DocumentKey) {
		this.s3DocumentKey = s3DocumentKey;
	}
	public String getSignedQrCode() {
		return signedQrCode;
	}
	public void setSignedQrCode(String signedQrCode) {
		this.signedQrCode = signedQrCode;
	}
	public String getStatus() {
		return status;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public boolean isEmailSent() {
		return emailSent;
	}
	public boolean isAcknowledged() {
		return acknowledged;
	}
	public boolean isSendingFailed() {
		return sendingFailed;
	}
	public void setEmailSent(boolean emailSent) {
		this.emailSent = emailSent;
	}
	public void setAcknowledged(boolean acknowledged) {
		this.acknowledged = acknowledged;
	}
	public void setSendingFailed(boolean sendingFailed) {
		this.sendingFailed = sendingFailed;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getS3BucketName() {
		return s3BucketName;
	}
	public void setS3BucketName(String s3BucketName) {
		this.s3BucketName = s3BucketName;
	}
	public String getBuyerLoc() {
		return buyerLoc;
	}
	public void setBuyerLoc(String buyerLoc) {
		this.buyerLoc = buyerLoc;
	}
}
