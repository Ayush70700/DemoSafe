package com.safexpress.billing.retail.dto;

public class RespData {
	private String message;
	private RetailWaybillResponseDTO retBillWayblResp;
	private String status;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public RetailWaybillResponseDTO getRetBillWayblResp() {
		return retBillWayblResp;
	}
	public void setRetBillWayblResp(RetailWaybillResponseDTO retBillWayblResp) {
		this.retBillWayblResp = retBillWayblResp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
