package com.safexpress.billing.retail.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.safexpress.billing.retail.model.RetailBillIntegrations;

@Transactional 
public interface IPiBilRetailLogRepository extends JpaRepository<RetailBillIntegrations, Long> {
	
	/** RETAIL LOG -- CASE 1 -- Search By -- Days */
	
//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.retryCount != 0 order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getRetailLogInfo30All();
	
	@Query(value = "select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "where rbi.retry_count != 0\r\n"
			+ "order by rbi.upd_dt desc",nativeQuery = true)
	List<RetailBillIntegrations> getRetailLogInfo30All();

	
//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.retryCount in (:retryCount) order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getRetailLogInfo30(@Param("retryCount") Integer retryCount);
	
	@Query(value = "select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "	where rbi.retry_count in (:retryCount)\r\n"
			+ "	order by rbi.upd_dt desc\r\n",nativeQuery = true)
	List<RetailBillIntegrations> getRetailLogInfo30(@Param("retryCount") Integer retryCount);

//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.updDt > current_date - :numOfDays and retailIntg.retryCount != 0 order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getRetailLogInfoAll(@Param("numOfDays") Integer numOfDays);

	@Query(value = "	select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "	where rbi.upd_dt > current_date - :numOfDays\r\n"
			+ "	and rbi.retry_count != 0\r\n"
			+ "	order by rbi.upd_dt desc\r\n",nativeQuery = true)
	List<RetailBillIntegrations> getRetailLogInfoAll(@Param("numOfDays") Integer numOfDays);

//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.updDt > current_date - :numOfDays and retailIntg.retryCount in (:retryCount) order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getRetailLogInfo(@Param("numOfDays") Integer numOfDays, @Param("retryCount") Integer retryCount);
	
	@Query(value = "select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "where rbi.upd_dt > current_date - :numOfDays\r\n"
			+ "and rbi.retry_count in (:retryCount)\r\n"
			+ "order by rbi.upd_dt desc",nativeQuery = true)
	List<RetailBillIntegrations> getRetailLogInfo(@Param("numOfDays") Integer numOfDays, @Param("retryCount") Integer retryCount);
	
	/** RETAIL LOG -- CASE 2 -- Search By -- Date */
	
//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.updDt >= :fromDate and retailIntg.updDt <= to_date(:toDate, 'yyyy-mm-dd') + 1 and retailIntg.retryCount != 0 order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getDateRetailLogInfoAll(@Param("fromDate") LocalDateTime fromDate, @Param("toDate") LocalDateTime toDate);
	

	@Query(value = "select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "	where rbi.upd_dt >= :fromDate\r\n"
			+ "	and rbi.upd_dt <= to_date(:toDate, 'yyyy-mm-dd') + 1\r\n"
			+ "	and rbi.retry_count != 0\r\n"
			+ "	order by rbi.upd_dt desc",nativeQuery = true)
	List<RetailBillIntegrations> getDateRetailLogInfoAll(@Param("fromDate") LocalDateTime fromDate, @Param("toDate") LocalDateTime toDate);

//	@Query(value = "select retailIntg from RetailBillIntegrations retailIntg where retailIntg.updDt >= :fromDate and retailIntg.updDt <= to_date(:toDate, 'yyyy-mm-dd') + 1 and retailIntg.retryCount in (:retryCount) order by retailIntg.updDt desc")
//	List<RetailBillIntegrations> getDateRetailLogInfo(@Param("fromDate") LocalDateTime fromDate, @Param("toDate") LocalDateTime toDate, @Param("retryCount") Integer retryCount);
	

	@Query(value = "select * from bil_retail.retail_bill_integrations rbi \r\n"
			+ "where rbi.upd_dt  >= :fromDate\r\n"
			+ "and rbi.upd_dt  <= to_date(:toDate, 'yyyy-mm-dd') + 1\r\n"
			+ "and rbi.retry_count  in (:retryCount)\r\n"
			+ "order by rbi.upd_dt desc",nativeQuery = true)
	List<RetailBillIntegrations> getDateRetailLogInfo(@Param("fromDate") LocalDateTime fromDate, @Param("toDate") LocalDateTime toDate, @Param("retryCount") Integer retryCount);

	/** UPDATE RETRY COUNT */
	
	@Modifying
	@Query(value = "update\r\n"
			+ "bil_retail.retail_bill_integrations \r\n"
			+ "set\r\n"
			+ "retry_count = 0\r\n"
			+ "where\r\n"
			+ "integration_id = :integrationId\r\n"
			+ "and retry_count = :maxRetryCount",nativeQuery = true)
	Integer updateRetryCountLogValue(@Param("integrationId") Long integrationId, @Param("maxRetryCount") Integer maxRetryCount);
	
	
}
