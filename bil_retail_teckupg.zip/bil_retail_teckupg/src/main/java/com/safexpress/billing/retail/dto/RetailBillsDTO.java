package com.safexpress.billing.retail.dto;

import java.util.Date;

public class RetailBillsDTO {
	
	private Long billId;
	private Date billDt;
	private Long billBatchDetailId;
	private Long billCtgyId;
	private String billCtgy;
	private Long prcId;
	private String billToCustName;
	private String billToAddr;
	private Long billToAddrId;
	private String billToAddrLine1;
	private String billToAddrLine2;
	private String billToAddrLine3;
	private String billToLocation;
	private String billToPincode;
	private String placeOfSupply;
	private String stateCode;
	private String gstNum;
	private Long consignerId;
	private String blngCycle;
	private Long blngBrId;
	private String billNum;
	private String billPeriod;
	private Date billFromDt;
	private Date billToDt;
	private String billToEmail;
	private String billType;
	private String pymtTerm;
	private Double baseAmt;
	private Long consigneeId;
	private String consigneeName;
	private String prcCode;
	private Long oraclePartyId;	
	private Long oraclePartyCustId;
	private Long oracleCustSiteId;
	private Long sfdcAccId;
	private String state;
	private String consignerName;
	private String blngBr;
	private Long collBrId;
	private String collBr;
	private Long altCollBrId;
	private String altCollBr;
	private Long submsnBrId;
	private String submsnBr;
	private Date lastDevDt;
	private Double outstandingAmt;
	private Double actualOutstandingAmt;
	private Double ttlTaxAmt;
	private Double cgstAmt;
	private Double igstAmt;
	private Double sgstAmt;
	private String status;
	private String message;
	private String oracleTaxRate;
	private String oracleTaxRateCode;
	private Integer emailSentCount;
	private Integer acknowledgeCount;
	private Integer sendingFailedCount;
	private String s3DocumentKey;
	private String irn;
	private String ackNo;
	private String ackDt;
	private String signedQrCode;
	private String irnFlag;
	private String billToCity;
	private String billToState;
	private String billingBrGstNum;
	private String billingBrAddress;
	private String billingBrLocation;
	private String billingBrCity;
	private String billingBrState;
	private String billingBrPincode;
	private String attr1;
	/**
	 * @return the billId
	 */
	public Long getBillId() {
		return billId;
	}
	/**
	 * @param billId the billId to set
	 */
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	/**
	 * @return the billDt
	 */
	public Date getBillDt() {
		return billDt;
	}
	/**
	 * @param billDt the billDt to set
	 */
	public void setBillDt(Date billDt) {
		this.billDt = billDt;
	}
	/**
	 * @return the billBatchDetailId
	 */
	public Long getBillBatchDetailId() {
		return billBatchDetailId;
	}
	/**
	 * @param billBatchDetailId the billBatchDetailId to set
	 */
	public void setBillBatchDetailId(Long billBatchDetailId) {
		this.billBatchDetailId = billBatchDetailId;
	}
	/**
	 * @return the billCtgyId
	 */
	public Long getBillCtgyId() {
		return billCtgyId;
	}
	/**
	 * @param billCtgyId the billCtgyId to set
	 */
	public void setBillCtgyId(Long billCtgyId) {
		this.billCtgyId = billCtgyId;
	}
	/**
	 * @return the billCtgy
	 */
	public String getBillCtgy() {
		return billCtgy;
	}
	/**
	 * @param billCtgy the billCtgy to set
	 */
	public void setBillCtgy(String billCtgy) {
		this.billCtgy = billCtgy;
	}
	/**
	 * @return the prcId
	 */
	public Long getPrcId() {
		return prcId;
	}
	/**
	 * @param prcId the prcId to set
	 */
	public void setPrcId(Long prcId) {
		this.prcId = prcId;
	}
	/**
	 * @return the billToCustName
	 */
	public String getBillToCustName() {
		return billToCustName;
	}
	/**
	 * @param billToCustName the billToCustName to set
	 */
	public void setBillToCustName(String billToCustName) {
		this.billToCustName = billToCustName;
	}
	/**
	 * @return the billToAddr
	 */
	public String getBillToAddr() {
		return billToAddr;
	}
	/**
	 * @param billToAddr the billToAddr to set
	 */
	public void setBillToAddr(String billToAddr) {
		this.billToAddr = billToAddr;
	}
	/**
	 * @return the billToAddrId
	 */
	public Long getBillToAddrId() {
		return billToAddrId;
	}
	/**
	 * @param billToAddrId the billToAddrId to set
	 */
	public void setBillToAddrId(Long billToAddrId) {
		this.billToAddrId = billToAddrId;
	}
	/**
	 * @return the billToAddrLine1
	 */
	public String getBillToAddrLine1() {
		return billToAddrLine1;
	}
	/**
	 * @param billToAddrLine1 the billToAddrLine1 to set
	 */
	public void setBillToAddrLine1(String billToAddrLine1) {
		this.billToAddrLine1 = billToAddrLine1;
	}
	/**
	 * @return the billToAddrLine2
	 */
	public String getBillToAddrLine2() {
		return billToAddrLine2;
	}
	/**
	 * @param billToAddrLine2 the billToAddrLine2 to set
	 */
	public void setBillToAddrLine2(String billToAddrLine2) {
		this.billToAddrLine2 = billToAddrLine2;
	}
	/**
	 * @return the billToAddrLine3
	 */
	public String getBillToAddrLine3() {
		return billToAddrLine3;
	}
	/**
	 * @param billToAddrLine3 the billToAddrLine3 to set
	 */
	public void setBillToAddrLine3(String billToAddrLine3) {
		this.billToAddrLine3 = billToAddrLine3;
	}
	/**
	 * @return the billToLocation
	 */
	public String getBillToLocation() {
		return billToLocation;
	}
	/**
	 * @param billToLocation the billToLocation to set
	 */
	public void setBillToLocation(String billToLocation) {
		this.billToLocation = billToLocation;
	}
	/**
	 * @return the billToPincode
	 */
	public String getBillToPincode() {
		return billToPincode;
	}
	/**
	 * @param billToPincode the billToPincode to set
	 */
	public void setBillToPincode(String billToPincode) {
		this.billToPincode = billToPincode;
	}
	/**
	 * @return the placeOfSupply
	 */
	public String getPlaceOfSupply() {
		return placeOfSupply;
	}
	/**
	 * @param placeOfSupply the placeOfSupply to set
	 */
	public void setPlaceOfSupply(String placeOfSupply) {
		this.placeOfSupply = placeOfSupply;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the gstNum
	 */
	public String getGstNum() {
		return gstNum;
	}
	/**
	 * @param gstNum the gstNum to set
	 */
	public void setGstNum(String gstNum) {
		this.gstNum = gstNum;
	}
	/**
	 * @return the consignerId
	 */
	public Long getConsignerId() {
		return consignerId;
	}
	/**
	 * @param consignerId the consignerId to set
	 */
	public void setConsignerId(Long consignerId) {
		this.consignerId = consignerId;
	}
	/**
	 * @return the blngCycle
	 */
	public String getBlngCycle() {
		return blngCycle;
	}
	/**
	 * @param blngCycle the blngCycle to set
	 */
	public void setBlngCycle(String blngCycle) {
		this.blngCycle = blngCycle;
	}
	/**
	 * @return the blngBrId
	 */
	public Long getBlngBrId() {
		return blngBrId;
	}
	/**
	 * @param blngBrId the blngBrId to set
	 */
	public void setBlngBrId(Long blngBrId) {
		this.blngBrId = blngBrId;
	}
	/**
	 * @return the billNum
	 */
	public String getBillNum() {
		return billNum;
	}
	/**
	 * @param billNum the billNum to set
	 */
	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}
	/**
	 * @return the billPeriod
	 */
	public String getBillPeriod() {
		return billPeriod;
	}
	/**
	 * @param billPeriod the billPeriod to set
	 */
	public void setBillPeriod(String billPeriod) {
		this.billPeriod = billPeriod;
	}
	/**
	 * @return the billFromDt
	 */
	public Date getBillFromDt() {
		return billFromDt;
	}
	/**
	 * @param billFromDt the billFromDt to set
	 */
	public void setBillFromDt(Date billFromDt) {
		this.billFromDt = billFromDt;
	}
	/**
	 * @return the billToDt
	 */
	public Date getBillToDt() {
		return billToDt;
	}
	/**
	 * @param billToDt the billToDt to set
	 */
	public void setBillToDt(Date billToDt) {
		this.billToDt = billToDt;
	}
	/**
	 * @return the billToEmail
	 */
	public String getBillToEmail() {
		return billToEmail;
	}
	/**
	 * @param billToEmail the billToEmail to set
	 */
	public void setBillToEmail(String billToEmail) {
		this.billToEmail = billToEmail;
	}
	/**
	 * @return the billType
	 */
	public String getBillType() {
		return billType;
	}
	/**
	 * @param billType the billType to set
	 */
	public void setBillType(String billType) {
		this.billType = billType;
	}
	/**
	 * @return the pymtTerm
	 */
	public String getPymtTerm() {
		return pymtTerm;
	}
	/**
	 * @param pymtTerm the pymtTerm to set
	 */
	public void setPymtTerm(String pymtTerm) {
		this.pymtTerm = pymtTerm;
	}
	/**
	 * @return the baseAmt
	 */
	public Double getBaseAmt() {
		return baseAmt;
	}
	/**
	 * @param baseAmt the baseAmt to set
	 */
	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}
	/**
	 * @return the consigneeId
	 */
	public Long getConsigneeId() {
		return consigneeId;
	}
	/**
	 * @param consigneeId the consigneeId to set
	 */
	public void setConsigneeId(Long consigneeId) {
		this.consigneeId = consigneeId;
	}
	/**
	 * @return the consigneeName
	 */
	public String getConsigneeName() {
		return consigneeName;
	}
	/**
	 * @param consigneeName the consigneeName to set
	 */
	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}
	/**
	 * @return the prcCode
	 */
	public String getPrcCode() {
		return prcCode;
	}
	/**
	 * @param prcCode the prcCode to set
	 */
	public void setPrcCode(String prcCode) {
		this.prcCode = prcCode;
	}
	/**
	 * @return the oraclePartyId
	 */
	public Long getOraclePartyId() {
		return oraclePartyId;
	}
	/**
	 * @param oraclePartyId the oraclePartyId to set
	 */
	public void setOraclePartyId(Long oraclePartyId) {
		this.oraclePartyId = oraclePartyId;
	}
	/**
	 * @return the oraclePartyCustId
	 */
	public Long getOraclePartyCustId() {
		return oraclePartyCustId;
	}
	/**
	 * @param oraclePartyCustId the oraclePartyCustId to set
	 */
	public void setOraclePartyCustId(Long oraclePartyCustId) {
		this.oraclePartyCustId = oraclePartyCustId;
	}
	/**
	 * @return the oracleCustSiteId
	 */
	public Long getOracleCustSiteId() {
		return oracleCustSiteId;
	}
	/**
	 * @param oracleCustSiteId the oracleCustSiteId to set
	 */
	public void setOracleCustSiteId(Long oracleCustSiteId) {
		this.oracleCustSiteId = oracleCustSiteId;
	}
	/**
	 * @return the sfdcAccId
	 */
	public Long getSfdcAccId() {
		return sfdcAccId;
	}
	/**
	 * @param sfdcAccId the sfdcAccId to set
	 */
	public void setSfdcAccId(Long sfdcAccId) {
		this.sfdcAccId = sfdcAccId;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the consignerName
	 */
	public String getConsignerName() {
		return consignerName;
	}
	/**
	 * @param consignerName the consignerName to set
	 */
	public void setConsignerName(String consignerName) {
		this.consignerName = consignerName;
	}
	/**
	 * @return the blngBr
	 */
	public String getBlngBr() {
		return blngBr;
	}
	/**
	 * @param blngBr the blngBr to set
	 */
	public void setBlngBr(String blngBr) {
		this.blngBr = blngBr;
	}
	/**
	 * @return the collBrId
	 */
	public Long getCollBrId() {
		return collBrId;
	}
	/**
	 * @param collBrId the collBrId to set
	 */
	public void setCollBrId(Long collBrId) {
		this.collBrId = collBrId;
	}
	/**
	 * @return the collBr
	 */
	public String getCollBr() {
		return collBr;
	}
	/**
	 * @param collBr the collBr to set
	 */
	public void setCollBr(String collBr) {
		this.collBr = collBr;
	}
	/**
	 * @return the altCollBrId
	 */
	public Long getAltCollBrId() {
		return altCollBrId;
	}
	/**
	 * @param altCollBrId the altCollBrId to set
	 */
	public void setAltCollBrId(Long altCollBrId) {
		this.altCollBrId = altCollBrId;
	}
	/**
	 * @return the altCollBr
	 */
	public String getAltCollBr() {
		return altCollBr;
	}
	/**
	 * @param altCollBr the altCollBr to set
	 */
	public void setAltCollBr(String altCollBr) {
		this.altCollBr = altCollBr;
	}
	/**
	 * @return the submsnBrId
	 */
	public Long getSubmsnBrId() {
		return submsnBrId;
	}
	/**
	 * @param submsnBrId the submsnBrId to set
	 */
	public void setSubmsnBrId(Long submsnBrId) {
		this.submsnBrId = submsnBrId;
	}
	/**
	 * @return the submsnBr
	 */
	public String getSubmsnBr() {
		return submsnBr;
	}
	/**
	 * @param submsnBr the submsnBr to set
	 */
	public void setSubmsnBr(String submsnBr) {
		this.submsnBr = submsnBr;
	}
	/**
	 * @return the lastDevDt
	 */
	public Date getLastDevDt() {
		return lastDevDt;
	}
	/**
	 * @param lastDevDt the lastDevDt to set
	 */
	public void setLastDevDt(Date lastDevDt) {
		this.lastDevDt = lastDevDt;
	}
	/**
	 * @return the outstandingAmt
	 */
	public Double getOutstandingAmt() {
		return outstandingAmt;
	}
	/**
	 * @param outstandingAmt the outstandingAmt to set
	 */
	public void setOutstandingAmt(Double outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}
	/**
	 * @return the actualOutstandingAmt
	 */
	public Double getActualOutstandingAmt() {
		return actualOutstandingAmt;
	}
	/**
	 * @param actualOutstandingAmt the actualOutstandingAmt to set
	 */
	public void setActualOutstandingAmt(Double actualOutstandingAmt) {
		this.actualOutstandingAmt = actualOutstandingAmt;
	}
	/**
	 * @return the ttlTaxAmt
	 */
	public Double getTtlTaxAmt() {
		return ttlTaxAmt;
	}
	/**
	 * @param ttlTaxAmt the ttlTaxAmt to set
	 */
	public void setTtlTaxAmt(Double ttlTaxAmt) {
		this.ttlTaxAmt = ttlTaxAmt;
	}
	/**
	 * @return the cgstAmt
	 */
	public Double getCgstAmt() {
		return cgstAmt;
	}
	/**
	 * @param cgstAmt the cgstAmt to set
	 */
	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	/**
	 * @return the igstAmt
	 */
	public Double getIgstAmt() {
		return igstAmt;
	}
	/**
	 * @param igstAmt the igstAmt to set
	 */
	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}
	/**
	 * @return the sgstAmt
	 */
	public Double getSgstAmt() {
		return sgstAmt;
	}
	/**
	 * @param sgstAmt the sgstAmt to set
	 */
	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the oracleTaxRate
	 */
	public String getOracleTaxRate() {
		return oracleTaxRate;
	}
	/**
	 * @param oracleTaxRate the oracleTaxRate to set
	 */
	public void setOracleTaxRate(String oracleTaxRate) {
		this.oracleTaxRate = oracleTaxRate;
	}
	/**
	 * @return the oracleTaxRateCode
	 */
	public String getOracleTaxRateCode() {
		return oracleTaxRateCode;
	}
	/**
	 * @param oracleTaxRateCode the oracleTaxRateCode to set
	 */
	public void setOracleTaxRateCode(String oracleTaxRateCode) {
		this.oracleTaxRateCode = oracleTaxRateCode;
	}
	/**
	 * @return the emailSentCount
	 */
	public Integer getEmailSentCount() {
		return emailSentCount;
	}
	/**
	 * @param emailSentCount the emailSentCount to set
	 */
	public void setEmailSentCount(Integer emailSentCount) {
		this.emailSentCount = emailSentCount;
	}
	/**
	 * @return the acknowledgeCount
	 */
	public Integer getAcknowledgeCount() {
		return acknowledgeCount;
	}
	/**
	 * @param acknowledgeCount the acknowledgeCount to set
	 */
	public void setAcknowledgeCount(Integer acknowledgeCount) {
		this.acknowledgeCount = acknowledgeCount;
	}
	/**
	 * @return the sendingFailedCount
	 */
	public Integer getSendingFailedCount() {
		return sendingFailedCount;
	}
	/**
	 * @param sendingFailedCount the sendingFailedCount to set
	 */
	public void setSendingFailedCount(Integer sendingFailedCount) {
		this.sendingFailedCount = sendingFailedCount;
	}
	/**
	 * @return the s3DocumentKey
	 */
	public String getS3DocumentKey() {
		return s3DocumentKey;
	}
	/**
	 * @param s3DocumentKey the s3DocumentKey to set
	 */
	public void setS3DocumentKey(String s3DocumentKey) {
		this.s3DocumentKey = s3DocumentKey;
	}
	/**
	 * @return the irn
	 */
	public String getIrn() {
		return irn;
	}
	/**
	 * @param irn the irn to set
	 */
	public void setIrn(String irn) {
		this.irn = irn;
	}
	/**
	 * @return the ackNo
	 */
	public String getAckNo() {
		return ackNo;
	}
	/**
	 * @param ackNo the ackNo to set
	 */
	public void setAckNo(String ackNo) {
		this.ackNo = ackNo;
	}
	/**
	 * @return the ackDt
	 */
	public String getAckDt() {
		return ackDt;
	}
	/**
	 * @param ackDt the ackDt to set
	 */
	public void setAckDt(String ackDt) {
		this.ackDt = ackDt;
	}
	/**
	 * @return the signedQrCode
	 */
	public String getSignedQrCode() {
		return signedQrCode;
	}
	/**
	 * @param signedQrCode the signedQrCode to set
	 */
	public void setSignedQrCode(String signedQrCode) {
		this.signedQrCode = signedQrCode;
	}
	/**
	 * @return the irnFlag
	 */
	public String getIrnFlag() {
		return irnFlag;
	}
	/**
	 * @param irnFlag the irnFlag to set
	 */
	public void setIrnFlag(String irnFlag) {
		this.irnFlag = irnFlag;
	}
	/**
	 * @return the billToCity
	 */
	public String getBillToCity() {
		return billToCity;
	}
	/**
	 * @param billToCity the billToCity to set
	 */
	public void setBillToCity(String billToCity) {
		this.billToCity = billToCity;
	}
	/**
	 * @return the billToState
	 */
	public String getBillToState() {
		return billToState;
	}
	/**
	 * @param billToState the billToState to set
	 */
	public void setBillToState(String billToState) {
		this.billToState = billToState;
	}
	/**
	 * @return the billingBrGstNum
	 */
	public String getBillingBrGstNum() {
		return billingBrGstNum;
	}
	/**
	 * @param billingBrGstNum the billingBrGstNum to set
	 */
	public void setBillingBrGstNum(String billingBrGstNum) {
		this.billingBrGstNum = billingBrGstNum;
	}
	/**
	 * @return the billingBrAddress
	 */
	public String getBillingBrAddress() {
		return billingBrAddress;
	}
	/**
	 * @param billingBrAddress the billingBrAddress to set
	 */
	public void setBillingBrAddress(String billingBrAddress) {
		this.billingBrAddress = billingBrAddress;
	}
	/**
	 * @return the billingBrLocation
	 */
	public String getBillingBrLocation() {
		return billingBrLocation;
	}
	/**
	 * @param billingBrLocation the billingBrLocation to set
	 */
	public void setBillingBrLocation(String billingBrLocation) {
		this.billingBrLocation = billingBrLocation;
	}
	/**
	 * @return the billingBrCity
	 */
	public String getBillingBrCity() {
		return billingBrCity;
	}
	/**
	 * @param billingBrCity the billingBrCity to set
	 */
	public void setBillingBrCity(String billingBrCity) {
		this.billingBrCity = billingBrCity;
	}
	/**
	 * @return the billingBrState
	 */
	public String getBillingBrState() {
		return billingBrState;
	}
	/**
	 * @param billingBrState the billingBrState to set
	 */
	public void setBillingBrState(String billingBrState) {
		this.billingBrState = billingBrState;
	}
	/**
	 * @return the billingBrPincode
	 */
	public String getBillingBrPincode() {
		return billingBrPincode;
	}
	/**
	 * @param billingBrPincode the billingBrPincode to set
	 */
	public void setBillingBrPincode(String billingBrPincode) {
		this.billingBrPincode = billingBrPincode;
	}
	/**
	 * @return the attr1
	 */
	public String getAttr1() {
		return attr1;
	}
	/**
	 * @param attr1 the attr1 to set
	 */
	public void setAttr1(String attr1) {
		this.attr1 = attr1;
	}
	
}
