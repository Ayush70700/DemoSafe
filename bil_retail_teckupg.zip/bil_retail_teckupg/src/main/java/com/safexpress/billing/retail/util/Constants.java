package com.safexpress.billing.retail.util;

/**
 * <h1>Constants</h1> The constants used in this application will be defined in
 * this java class.
 * <p>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-22
 */
public class Constants {
	private Constants() {
	}

	private static String retailWaybillApi;
	private static String retailBillB2BCtgy;
	private static String retailBillB2CCtgy;
	private static String retailBatchType;
	private static String retailBillingSources;
	private static String retailSelfServiceSources;
	private static String retailTimeLapseinDays;
	private static String propelBranchApi;
	
	private static String jwtToken;
	public static final String INV_FILE_NAME = "cmdm_excel_template.xlsx";
	public static final String RETAIL_WRITEOFF_STATUS = "WRITEOFF";
	public static final String RETAIL_BILL_CREATION = "RETAIL_BILL_CREATION";
	public static final String ERROR_STATUS = "ERROR";
	public static final String INTEGRATION_SUCCESS_STATUS = "PROCESSED";
	// Journal Integration constants.
	public static final String USER_CATEGORY_NAME = "Invoice";
	public static final String USER_SOURCE_NAME = "Manual";
	public static final String USER_JE_SOURCE_NAME = "Manual";
	public static final String USER_JE_CATEGORY_NAME = "Manual";
	public static final String RETAIL_BILLING_SRC_FOR_WB ="Billing";
	public static final String RETAIL_BILL_EMAIL_TYPE = "RETAIL_WAY_BILL_INTEGRATION_FAIL_NOTIFY";
	public static final String TOPAY_VALUE = "TO-PAY";
	public static final String PAID_VALUE = "PAID";
	
	public static final String EINV_INV_TYPE = "INV";
	public static final String EINV_TAXSCH_GST = "GST";
	public static final String EINV_SUPTYP_B2B = "B2B";
	
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String ERROR = "ERROR";

	private static String userName;
	private static String correlationId;
	
	private static String billingAdminUser;

	public static String getUserName() {
		return userName;
	}

	public static void setUserName(String userName) {
		Constants.userName = userName;
	}

	public static String getCorrelationId() {
		return correlationId;
	}

	public static void setCorrelationId(String correlationId) {
		Constants.correlationId = correlationId;
	}

	public static String getJwtToken() {
		return jwtToken;
	}

	public static void setJwtToken(String jwtToken) {
		Constants.jwtToken = jwtToken;
	}

	public static String getRetailWaybillApi() {
		return retailWaybillApi;
	}

	public static void setRetailWaybillApi(String retailWaybillApi) {
		Constants.retailWaybillApi = retailWaybillApi;
	}

	public static String getRetailBillB2BCtgy() {
		return retailBillB2BCtgy;
	}

	public static void setRetailBillB2BCtgy(String retailBillB2BCtgy) {
		Constants.retailBillB2BCtgy = retailBillB2BCtgy;
	}

	public static String getRetailBillB2CCtgy() {
		return retailBillB2CCtgy;
	}

	public static void setRetailBillB2CCtgy(String retailBillB2CCtgy) {
		Constants.retailBillB2CCtgy = retailBillB2CCtgy;
	}

	public static String getRetailBatchType() {
		return retailBatchType;
	}

	public static void setRetailBatchType(String retailBatchType) {
		Constants.retailBatchType = retailBatchType;
	}

	public static String getRetailBillingSources() {
		return retailBillingSources;
	}

	public static void setRetailBillingSources(String retailBillingSources) {
		Constants.retailBillingSources = retailBillingSources;
	}

	public static String getRetailSelfServiceSources() {
		return retailSelfServiceSources;
	}

	public static void setRetailSelfServiceSources(String retailSelfServiceSources) {
		Constants.retailSelfServiceSources = retailSelfServiceSources;
	}

	public static String getRetailTimeLapseinDays() {
		return retailTimeLapseinDays;
	}

	public static void setRetailTimeLapseinDays(String retailTimeLapseinDays) {
		Constants.retailTimeLapseinDays = retailTimeLapseinDays;
	}

	public static String getPropelBranchApi() {
		return propelBranchApi;
	}

	public static void setPropelBranchApi(String propelBranchApi) {
		Constants.propelBranchApi = propelBranchApi;
	}

	/**
	 * @return the billingAdminUser
	 */
	public static String getBillingAdminUser() {
		return billingAdminUser;
	}

	/**
	 * @param billingAdminUser the billingAdminUser to set
	 */
	public static void setBillingAdminUser(String billingAdminUser) {
		Constants.billingAdminUser = billingAdminUser;
	}


}
