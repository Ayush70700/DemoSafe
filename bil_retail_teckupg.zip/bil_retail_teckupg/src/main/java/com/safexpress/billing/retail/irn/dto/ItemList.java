package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ItemList {

	@JsonProperty("SlNo") 
    public String slNo;
    @JsonProperty("PrdDesc") 
    public String prdDesc;
    @JsonProperty("IsServc") 
    public String isServc;
    @JsonProperty("HsnCd") 
    public String hsnCd;
    @JsonProperty("Barcde") 
    public Object barcde;
    @JsonProperty("Qty") 
    public int qty;
    @JsonProperty("FreeQty") 
    public int freeQty;
    @JsonProperty("Unit") 
    public Object unit;
    @JsonProperty("UnitPrice") 
    public double unitPrice;
    @JsonProperty("TotAmt") 
    public double totAmt;
    @JsonProperty("Discount") 
    public int discount;
    @JsonProperty("PreTaxVal") 
    public int preTaxVal;
    @JsonProperty("AssAmt") 
    public double assAmt;
    @JsonProperty("GstRt") 
    public int gstRt;
    @JsonProperty("IgstAmt") 
    public double igstAmt;
    @JsonProperty("CgstAmt") 
    public double cgstAmt;
    @JsonProperty("SgstAmt") 
    public double sgstAmt;
    @JsonProperty("CesRt") 
    public int cesRt;
    @JsonProperty("CesAmt") 
    public int cesAmt;
    @JsonProperty("CesNonAdvlAmt") 
    public int cesNonAdvlAmt;
    @JsonProperty("StateCesRt") 
    public int stateCesRt;
    @JsonProperty("StateCesAmt") 
    public int stateCesAmt;
    @JsonProperty("StateCesNonAdvlAmt") 
    public int stateCesNonAdvlAmt;
    @JsonProperty("OthChrg") 
    public int othChrg;
    @JsonProperty("TotItemVal") 
    public double totItemVal;
    @JsonProperty("OrdLineRef") 
    public Object ordLineRef;
    @JsonProperty("OrgCntry") 
    public Object orgCntry;
    @JsonProperty("PrdSlNo") 
    public Object prdSlNo;
	public String getSlNo() {
		return slNo;
	}
	public String getPrdDesc() {
		return prdDesc;
	}
	public String getIsServc() {
		return isServc;
	}
	public String getHsnCd() {
		return hsnCd;
	}
	public Object getBarcde() {
		return barcde;
	}
	public int getQty() {
		return qty;
	}
	public int getFreeQty() {
		return freeQty;
	}
	public Object getUnit() {
		return unit;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public double getTotAmt() {
		return totAmt;
	}
	public int getDiscount() {
		return discount;
	}
	public int getPreTaxVal() {
		return preTaxVal;
	}
	public double getAssAmt() {
		return assAmt;
	}
	public int getGstRt() {
		return gstRt;
	}
	public double getIgstAmt() {
		return igstAmt;
	}
	public double getCgstAmt() {
		return cgstAmt;
	}
	public double getSgstAmt() {
		return sgstAmt;
	}
	public int getCesRt() {
		return cesRt;
	}
	public int getCesAmt() {
		return cesAmt;
	}
	public int getCesNonAdvlAmt() {
		return cesNonAdvlAmt;
	}
	public int getStateCesRt() {
		return stateCesRt;
	}
	public int getStateCesAmt() {
		return stateCesAmt;
	}
	public int getStateCesNonAdvlAmt() {
		return stateCesNonAdvlAmt;
	}
	public int getOthChrg() {
		return othChrg;
	}
	public double getTotItemVal() {
		return totItemVal;
	}
	public Object getOrdLineRef() {
		return ordLineRef;
	}
	public Object getOrgCntry() {
		return orgCntry;
	}
	public Object getPrdSlNo() {
		return prdSlNo;
	}
	public void setSlNo(String slNo) {
		this.slNo = slNo;
	}
	public void setPrdDesc(String prdDesc) {
		this.prdDesc = prdDesc;
	}
	public void setIsServc(String isServc) {
		this.isServc = isServc;
	}
	public void setHsnCd(String hsnCd) {
		this.hsnCd = hsnCd;
	}
	public void setBarcde(Object barcde) {
		this.barcde = barcde;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public void setFreeQty(int freeQty) {
		this.freeQty = freeQty;
	}
	public void setUnit(Object unit) {
		this.unit = unit;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public void setTotAmt(double totAmt) {
		this.totAmt = totAmt;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public void setPreTaxVal(int preTaxVal) {
		this.preTaxVal = preTaxVal;
	}
	public void setAssAmt(double assAmt) {
		this.assAmt = assAmt;
	}
	public void setGstRt(int gstRt) {
		this.gstRt = gstRt;
	}
	public void setIgstAmt(double igstAmt) {
		this.igstAmt = igstAmt;
	}
	public void setCgstAmt(double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public void setSgstAmt(double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public void setCesRt(int cesRt) {
		this.cesRt = cesRt;
	}
	public void setCesAmt(int cesAmt) {
		this.cesAmt = cesAmt;
	}
	public void setCesNonAdvlAmt(int cesNonAdvlAmt) {
		this.cesNonAdvlAmt = cesNonAdvlAmt;
	}
	public void setStateCesRt(int stateCesRt) {
		this.stateCesRt = stateCesRt;
	}
	public void setStateCesAmt(int stateCesAmt) {
		this.stateCesAmt = stateCesAmt;
	}
	public void setStateCesNonAdvlAmt(int stateCesNonAdvlAmt) {
		this.stateCesNonAdvlAmt = stateCesNonAdvlAmt;
	}
	public void setOthChrg(int othChrg) {
		this.othChrg = othChrg;
	}
	public void setTotItemVal(double totItemVal) {
		this.totItemVal = totItemVal;
	}
	public void setOrdLineRef(Object ordLineRef) {
		this.ordLineRef = ordLineRef;
	}
	public void setOrgCntry(Object orgCntry) {
		this.orgCntry = orgCntry;
	}
	public void setPrdSlNo(Object prdSlNo) {
		this.prdSlNo = prdSlNo;
	}
    
}
