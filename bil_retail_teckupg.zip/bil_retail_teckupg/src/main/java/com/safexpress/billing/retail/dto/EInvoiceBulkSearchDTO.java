package com.safexpress.billing.retail.dto;

public class EInvoiceBulkSearchDTO {
	
	String documentNumber;
	String documentDt;
	String buyerGstin;
	String buyerName;
	String buyerAddressLine1;
	String buyerAddressLine2;
	String buyerAddressLine3;
	String buyerLocation;
	String buyerPin;
	String buyerStateCode;
	String buyerPlaceOfSupply;
	String markAsB2C;
	public String getDocumentNumber() {
		return documentNumber;
	}
	public String getDocumentDt() {
		return documentDt;
	}
	public String getBuyerGstin() {
		return buyerGstin;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public String getBuyerAddressLine1() {
		return buyerAddressLine1;
	}
	public String getBuyerAddressLine2() {
		return buyerAddressLine2;
	}
	public String getBuyerAddressLine3() {
		return buyerAddressLine3;
	}
	public String getBuyerLocation() {
		return buyerLocation;
	}
	public String getBuyerPin() {
		return buyerPin;
	}
	public String getBuyerStateCode() {
		return buyerStateCode;
	}
	public String getBuyerPlaceOfSupply() {
		return buyerPlaceOfSupply;
	}
	public String getMarkAsB2C() {
		return markAsB2C;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public void setDocumentDt(String documentDt) {
		this.documentDt = documentDt;
	}
	public void setBuyerGstin(String buyerGstin) {
		this.buyerGstin = buyerGstin;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public void setBuyerAddressLine1(String buyerAddressLine1) {
		this.buyerAddressLine1 = buyerAddressLine1;
	}
	public void setBuyerAddressLine2(String buyerAddressLine2) {
		this.buyerAddressLine2 = buyerAddressLine2;
	}
	public void setBuyerAddressLine3(String buyerAddressLine3) {
		this.buyerAddressLine3 = buyerAddressLine3;
	}
	public void setBuyerLocation(String buyerLocation) {
		this.buyerLocation = buyerLocation;
	}
	public void setBuyerPin(String buyerPin) {
		this.buyerPin = buyerPin;
	}
	public void setBuyerStateCode(String buyerStateCode) {
		this.buyerStateCode = buyerStateCode;
	}
	public void setBuyerPlaceOfSupply(String buyerPlaceOfSupply) {
		this.buyerPlaceOfSupply = buyerPlaceOfSupply;
	}
	public void setMarkAsB2C(String markAsB2C) {
		this.markAsB2C = markAsB2C;
	}	
}
