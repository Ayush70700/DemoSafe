package com.safexpress.billing.retail.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.safexpress.billing.retail.dto.TestDTO;
import com.safexpress.billing.retail.irn.dto.BuyerDtls;
import com.safexpress.billing.retail.irn.dto.DocDtls;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;
import com.safexpress.billing.retail.irn.dto.ItemList;
import com.safexpress.billing.retail.irn.dto.SellerDtls;
import com.safexpress.billing.retail.irn.dto.TranDtls;
import com.safexpress.billing.retail.irn.dto.ValDtls;
import com.safexpress.billing.retail.model.RetailBills;
import com.safexpress.billing.retail.repository.IRetailBillsRepository;
import com.safexpress.billing.retail.util.Constants;
import com.safexpress.billing.retail.util.RetailBillingUtil;

@Service
public class TestIrnServiceImpl implements TestIrnService {

	public static final Logger logger = LoggerFactory.getLogger(RetailServiceImpl.class);

	@Autowired
	private RetailBillingUtil retailBillingUtil;

	@Autowired
	private IRetailBillsRepository retailBillsRepository;

	@Value("${einvoice.seller.gstin}")
	private String sellerGstin;
	@Value("${einvoice.seller.legalName}")
	private String sellerLegalName;
	@Value("${einvoice.seller.tradeName}")
	private String sellerTradeName;
	@Value("${einvoice.seller.addr1}")
	private String sellerAddr1;
	@Value("${einvoice.seller.addr2}")
	private String sellerAddr2;
	@Value("${einvoice.seller.addr3}")
	private String sellerAddr3;
	@Value("${einvoice.seller.location}")
	private String sellerLocation;
	@Value("${einvoice.seller.pincode}")
	private Integer sellerPincode;
	@Value("${einvoice.seller.stateCode}")
	private String sellerStateCode;
	@Value("${einvoice.product.desc}")
	private String productDesc;
	@Value("${einvoice.isService}")
	private String productIsService;
	@Value("${einvoice.hsnCode}")
	private String productHsnCode;
	@Value("${einvoice.seller.phone}")
	private String sellerPhone;
	@Value("${einvoice.seller.email}")
	private String sellerEmail;

	
	@Override
	public List<IrnHeaderDTO> getB2bTestBills(TestDTO tesDTO, String errorFlag) {

		logger.info("=== RetailServiceImpl:: getB2bBills === {} ", errorFlag);
		List<IrnHeaderDTO> irnHeader = new ArrayList<>();

		// fetch the retail B2B bills without IRN number
		List<RetailBills> retailBillsList = null;
			retailBillsList = retailBillsRepository.getB2BTestRetailBills(tesDTO.getBillNum());
		for (RetailBills retailBill : retailBillsList) {
			logger.info("RetailServiceImpl:: Retail Bill Eligible for einvoice : {} ", retailBill.getBillNum());
			try {
				// create object
				DocDtls docDtls = new DocDtls();
				docDtls.setNo(retailBill.getBillNum());
				docDtls.setTyp(Constants.EINV_INV_TYPE);
				docDtls.setDt(retailBillingUtil.formatDateToString(retailBill.getBillDt()));

				// TranDtls
				TranDtls tranDtls = new TranDtls();
				tranDtls.setTaxSch(Constants.EINV_TAXSCH_GST);
				tranDtls.setSupTyp(Constants.EINV_SUPTYP_B2B);
				tranDtls.setRegRev("N");

				// seller details
				SellerDtls sellerDtls = new SellerDtls();
				sellerDtls.setGstin(this.sellerGstin);
				sellerDtls.setLglNm(this.sellerLegalName);
				sellerDtls.setTrdNm(this.sellerTradeName);
				sellerDtls.setAddr1(this.sellerAddr1);
				sellerDtls.setAddr2(this.sellerAddr2);
				sellerDtls.setLoc(this.sellerLocation);
				sellerDtls.setPin(this.sellerPincode);
				sellerDtls.setStcd(this.sellerStateCode);

				// buyer details
				BuyerDtls buyerDtls = new BuyerDtls();
				buyerDtls.setGstin(retailBill.getGstNum());
				buyerDtls.setLglNm(retailBill.getBillToCustName());
				buyerDtls.setTrdNm(retailBill.getBillToCustName());
				buyerDtls.setAddr1(retailBill.getBillToAddrLine1());
				buyerDtls.setAddr2(retailBill.getBillToAddrLine2());
				buyerDtls.setLoc(retailBill.getBillToLocation());
				buyerDtls.setPin(retailBill.getBillToPincode() != null && !"".equals(retailBill.getBillToPincode())
						? Integer.valueOf(retailBill.getBillToPincode().replace(" ", ""))
						: 0);
				buyerDtls.setStcd(retailBill.getGstNum().substring(0, 2));
				buyerDtls.setPos(retailBill.getGstNum().substring(0, 2));

				// Line items
				List<ItemList> itemList = new ArrayList<>();
				ItemList item = new ItemList();
				item.setSlNo("1");
				item.setPrdDesc(this.productDesc);
				item.setIsServc(this.productIsService);
				item.setHsnCd(this.productHsnCode);
				item.setQty(1);
				item.setUnitPrice(retailBill.getBaseAmt());
				item.setTotAmt(retailBill.getBaseAmt());
				item.setDiscount(0);
				item.setPreTaxVal(0);
				item.setAssAmt(retailBill.getBaseAmt());
				if ((retailBill.getIgstAmt() != null && retailBill.getIgstAmt() > 0)) {
					item.setGstRt(retailBill.getOracleTaxRate() != null ? Integer.valueOf(retailBill.getOracleTaxRate())
							: 18);
				} else if ((retailBill.getCgstAmt() != null && retailBill.getCgstAmt() > 0)) {
					item.setGstRt(
							retailBill.getOracleTaxRate() != null ? Integer.valueOf(retailBill.getOracleTaxRate()) * 2
									: 18);
				} else {
					item.setGstRt(0);
				}

				item.setIgstAmt(retailBill.getIgstAmt() != null ? (retailBill.getIgstAmt()) : 0);
				item.setCgstAmt(retailBill.getCgstAmt() != null ? (retailBill.getCgstAmt()) : 0);
				item.setSgstAmt(retailBill.getSgstAmt() != null ? (retailBill.getSgstAmt()) : 0);
				item.setTotItemVal((retailBill.getActualOutstandingAmt()));
				itemList.add(item);
				// set summary
				ValDtls valDtls = new ValDtls();
				valDtls.setAssVal((retailBill.getBaseAmt()));
				valDtls.setCgstVal(retailBill.getCgstAmt() != null ? (retailBill.getCgstAmt()) : 0);
				valDtls.setSgstVal(retailBill.getSgstAmt() != null ? (retailBill.getSgstAmt()) : 0);
				valDtls.setIgstVal(retailBill.getIgstAmt() != null ? (retailBill.getIgstAmt()) : 0);
				valDtls.setTotInvVal((retailBill.getActualOutstandingAmt()));
				valDtls.setTotInvValFc((retailBill.getActualOutstandingAmt()));

				// create invoice object
				IrnHeaderDTO invoice = new IrnHeaderDTO();
				invoice.setBuyerDtls(buyerDtls);
				invoice.setSellerDtls(sellerDtls);
				invoice.setDocDtls(docDtls);
				invoice.setItemList(itemList);
				invoice.setTranDtls(tranDtls);
				invoice.setValDtls(valDtls);
				invoice.setBillType(retailBill.getBillType());
				invoice.setBillId(retailBill.getBillId());
				irnHeader.add(invoice);
			} catch (Exception ex) {
				ex.printStackTrace();
				logger.info("Retail Bill:: " + retailBill.getBillNum() + " exception: " + ex.getMessage());
			}

		}
		return irnHeader;

	}

}
