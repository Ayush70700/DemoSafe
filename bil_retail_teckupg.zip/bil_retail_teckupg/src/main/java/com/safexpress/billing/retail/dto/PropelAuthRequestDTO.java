package com.safexpress.billing.retail.dto;

public class PropelAuthRequestDTO {

	Long channelId;
	String password;
	String username;

	public Long getChannelId() {
		return channelId;
	}

	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return username;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
