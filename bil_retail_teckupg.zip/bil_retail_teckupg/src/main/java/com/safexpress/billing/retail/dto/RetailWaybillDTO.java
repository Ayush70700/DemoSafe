package com.safexpress.billing.retail.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RetailWaybillDTO {
	Long waybillId;
	String waybillNumber;
	Long prcId;
	String prcCode;
	String billToCustomer;
	String billToAddr;
	String billToEmail;
	String billToPincode;
	String billToLocation;
	//String placeOfSupply;
	String stateCode;
	String gstNum;
	Long consignerId;
	Long consigneeId;
	String consignerName;
	//String consignerEmail;
	//String consignerPincode;
	//String consignerLocation;
	//String consigneeEmail;
	//String consigneePincode;
	//String consigneeLocation;
	String consigneeName;
	String blngCycle;
	Long deliveryBrId;
	String deliveryBr;
    String documentType;
	Long bkgBrId;
	String bkgBr;
	//Long collBrId;
	//String collBr;
	//Long altCollBrId;
	//String altCollBr;
	//Long submsnBrId;
	//String submsnBr;
	String state;
	String pymtTerm;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	Date pickupDate;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	Date delieveryDate;
	//String origin;
	//String destination;
	double baseAmount;
	double igstAmount;
	double cgstAmount;
	double sgstAmount;
	double ttlTaxAmount;
	double outstandingAmount;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	Date creationDate;
	public Long getWaybillId() {
		return waybillId;
	}
	public void setWaybillId(Long waybillId) {
		this.waybillId = waybillId;
	}
	public String getWaybillNumber() {
		return waybillNumber;
	}
	public void setWaybillNumber(String waybillNumber) {
		this.waybillNumber = waybillNumber;
	}
	public Long getPrcId() {
		return prcId;
	}
	public void setPrcId(Long prcId) {
		this.prcId = prcId;
	}
	public String getPrcCode() {
		return prcCode;
	}
	public void setPrcCode(String prcCode) {
		this.prcCode = prcCode;
	}
	public String getBillToCustomer() {
		return billToCustomer;
	}
	public void setBillToCustomer(String billToCustomer) {
		this.billToCustomer = billToCustomer;
	}
	public String getBillToAddr() {
		return billToAddr;
	}
	public void setBillToAddr(String billToAddr) {
		this.billToAddr = billToAddr;
	}
	public String getBillToEmail() {
		return billToEmail;
	}
	public void setBillToEmail(String billToEmail) {
		this.billToEmail = billToEmail;
	}
	public String getBillToPincode() {
		return billToPincode;
	}
	public void setBillToPincode(String billToPincode) {
		this.billToPincode = billToPincode;
	}
	public String getBillToLocation() {
		return billToLocation;
	}
	public void setBillToLocation(String billToLocation) {
		this.billToLocation = billToLocation;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getGstNum() {
		return gstNum;
	}
	public void setGstNum(String gstNum) {
		this.gstNum = gstNum;
	}
	public Long getConsignerId() {
		return consignerId;
	}
	public void setConsignerId(Long consignerId) {
		this.consignerId = consignerId;
	}
	public Long getConsigneeId() {
		return consigneeId;
	}
	public void setConsigneeId(Long consigneeId) {
		this.consigneeId = consigneeId;
	}
	public String getConsignerName() {
		return consignerName;
	}
	public void setConsignerName(String consignerName) {
		this.consignerName = consignerName;
	}
	public String getConsigneeName() {
		return consigneeName;
	}
	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}
	public String getBlngCycle() {
		return blngCycle;
	}
	public void setBlngCycle(String blngCycle) {
		this.blngCycle = blngCycle;
	}
	public Long getDeliveryBrId() {
		return deliveryBrId;
	}
	public void setDeliveryBrId(Long deliveryBrId) {
		this.deliveryBrId = deliveryBrId;
	}
	public String getDeliveryBr() {
		return deliveryBr;
	}
	public void setDeliveryBr(String deliveryBr) {
		this.deliveryBr = deliveryBr;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public Long getBkgBrId() {
		return bkgBrId;
	}
	public void setBkgBrId(Long bkgBrId) {
		this.bkgBrId = bkgBrId;
	}
	public String getBkgBr() {
		return bkgBr;
	}
	public void setBkgBr(String bkgBr) {
		this.bkgBr = bkgBr;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPymtTerm() {
		return pymtTerm;
	}
	public void setPymtTerm(String pymtTerm) {
		this.pymtTerm = pymtTerm;
	}
	public Date getPickupDate() {
		return pickupDate;
	}
	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}
	public Date getDelieveryDate() {
		return delieveryDate;
	}
	public void setDelieveryDate(Date delieveryDate) {
		this.delieveryDate = delieveryDate;
	}
	public double getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(double baseAmount) {
		this.baseAmount = baseAmount;
	}
	public double getIgstAmount() {
		return igstAmount;
	}
	public void setIgstAmount(double igstAmount) {
		this.igstAmount = igstAmount;
	}
	public double getCgstAmount() {
		return cgstAmount;
	}
	public void setCgstAmount(double cgstAmount) {
		this.cgstAmount = cgstAmount;
	}
	public double getSgstAmount() {
		return sgstAmount;
	}
	public void setSgstAmount(double sgstAmount) {
		this.sgstAmount = sgstAmount;
	}
	public double getTtlTaxAmount() {
		return ttlTaxAmount;
	}
	public void setTtlTaxAmount(double ttlTaxAmount) {
		this.ttlTaxAmount = ttlTaxAmount;
	}
	public double getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	
	
}
