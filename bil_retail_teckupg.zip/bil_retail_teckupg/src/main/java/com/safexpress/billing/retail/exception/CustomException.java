package com.safexpress.billing.retail.exception;
/******************************************************************
* <h1>CustomException</h1>
* Custom Exception Defined.
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
import org.springframework.http.HttpStatus;

public class CustomException extends Exception {

	private static final long serialVersionUID = -5634865875490294251L;
	private HttpStatus httpStatus = HttpStatus.NOT_FOUND;

	public CustomException(String message, Throwable cause) {
		super(message, cause);
	}

	public CustomException(String message, Throwable cause, HttpStatus httpStatus) {
		super(message, cause);
		this.httpStatus = httpStatus;
	}
	
	public CustomException(String message, HttpStatus httpStatus) {
		super(message);
		this.httpStatus = httpStatus;
	}


	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	
	public CustomException(String message) {
		super(message);
	}
}
