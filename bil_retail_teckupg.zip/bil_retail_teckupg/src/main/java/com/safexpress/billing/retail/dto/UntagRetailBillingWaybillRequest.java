package com.safexpress.billing.retail.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UntagRetailBillingWaybillRequest {
	
	@JsonProperty("billNumber")
	private String billNumber;

	/**
	 * @return the billNumber
	 */
	public String getBillNumber() {
		return billNumber;
	}

	/**
	 * @param billNumber the billNumber to set
	 */
	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}	

}
