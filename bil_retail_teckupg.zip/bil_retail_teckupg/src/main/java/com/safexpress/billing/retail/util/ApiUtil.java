package com.safexpress.billing.retail.util;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.safexpress.billing.retail.dto.JwtAuthenticationResponseDTO;
import com.safexpress.billing.retail.dto.LoginRequestDTO;

@Component
public class ApiUtil {
	
	@Value("${service.billing-jwt-url}")
	private String authServiceUrl;
	@Value("${billing.admin.user}")
	private String bilUserName;
	@Value("${billing.admin.password}")
	private String bilPassword;
	
	@Autowired
	RestTemplate restTemplate;
	
	/**
	 * Generate basic authentication header.
	 *
	 * @param userName     the user name
	 * @param userPassword the user password
	 * @return the string
	 */
	public static String generateBasicAutenticationHeader(String userName, String userPassword) {
		byte[] encodedBytes = Base64.getEncoder().encode((userName + ":" + userPassword).getBytes());
		return "Basic " + new String(encodedBytes);
	}
	
	/**
	 * @Description 		To create HttpHeader for AWS internal microservice call
	 * @return HttpHeaders  HttpHeder details
	 */
	public HttpHeaders createBillingServiceHeader() {
        HttpHeaders requestHeaders = new HttpHeaders();       
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        requestHeaders.add("Authorization", Constants.getJwtToken());
        requestHeaders.add("UserName", Constants.getUserName());
        requestHeaders.add("correlationId", Constants.getCorrelationId());
        return requestHeaders;
	}
	
	@Retryable
	public String getBillingToken() {
		LoginRequestDTO loginRequest = new LoginRequestDTO();
		loginRequest.setPassword(bilPassword);
		loginRequest.setUsername(bilUserName);
		Constants.setUserName(bilUserName);
		HttpEntity<LoginRequestDTO> entity = new HttpEntity<>(loginRequest,createBillingServiceHeader());
		String url = authServiceUrl + "/jwt/authorize";
		ResponseEntity<JwtAuthenticationResponseDTO> response = restTemplate.exchange(url, HttpMethod.POST, entity,
					JwtAuthenticationResponseDTO.class);
		JwtAuthenticationResponseDTO jwtTokenDTO = response.getBody();
		return jwtTokenDTO.getTokenType() + " " + jwtTokenDTO.getAccessToken();
	}

}
