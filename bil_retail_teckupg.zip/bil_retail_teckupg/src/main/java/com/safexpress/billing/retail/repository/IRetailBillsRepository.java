package com.safexpress.billing.retail.repository;

import java.sql.Timestamp;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.safexpress.billing.retail.model.RetailBills;

public interface IRetailBillsRepository extends JpaRepository<RetailBills, Long> {

	@Query(value = "select current_timestamp", nativeQuery = true)
	Timestamp getCurrentTimestamp();

	@Query(value = "select count(*)+1  from bil_retail.retail_bills rb  where extract(month from bill_dt) = :pMonth", nativeQuery = true)
	public Long getNextBillNum(@Param("pMonth") int billMonth);

	@Query(value = "SELECT rb.* from bil_retail.retail_bills rb where 1=1 " + " and status  = 'FINALIZED' "
			+ " and ((RB.gst_num notnull and RB.bill_ctgy = 'B2B' and RB.irn_flag = 'Y') or (RB.bill_ctgy = 'B2C' or RB.gst_num isnull or RB.gst_num = '')) "
			+ " and rb.bill_num  = :docNum", nativeQuery = true)
	public RetailBills getBillsByDocNums(@Param("docNum") String docNum);

	@Query(value = "SELECT RB.bill_Id, RB.bill_Type, RB.bill_To_Cust_Name, RB.bill_Num, "
			+ " RB.outstanding_Amt, RB.actual_outstanding_Amt, RB.bill_Dt, RB.bill_batch_id "
			+ " FROM bil_retail.retail_bills RB " + " WHERE 1=1 " + " AND RB.status='FINALIZED' "
			+ " and ((RB.gst_num notnull and RB.bill_ctgy = 'B2B' and RB.irn_flag = 'Y') or (RB.bill_ctgy = 'B2C' or RB.gst_num isnull or RB.gst_num = '')) "
			+ " AND (:documentNumber = '' or RB.bill_Num = :documentNumber) "
			+ " AND (:documentType = 'RETAIL_GST_INV' or RB.bill_Type = :documentType) "
			+ " AND RB.outstanding_Amt > 0 "
			+ " AND (:fromDate = '' or DATE_TRUNC('day',RB.bill_Dt) >= to_date(:fromDate, 'yyyy-MM-dd')) "
			+ " AND (:toDate = '' or DATE_TRUNC('day',RB.bill_Dt) <= to_date(:toDate, 'yyyy-MM-dd'))", nativeQuery = true)
	public List<Object[]> getRetailDetails(@Param("documentType") String documentType,
			@Param("documentNumber") String documentNumber, @Param("fromDate") String fromDate,
			@Param("toDate") String toDate);

//	/**
//	 * method to get B2B credit bills without irn generated
//	 * 
//	 */
//	@Query(value = "SELECT RB from RetailBills RB WHERE RB.gstNum IS NOT NULL AND RB.irn IS NULL AND RB.irnFlag IS NULL")
//	public List<RetailBills> getB2BRetailBills();

	/**
	 * method to get B2B credit bills without irn generated
	 * 
	 */
	@Query(value = "SELECT RB from RetailBills RB WHERE RB.gstNum IS NOT NULL AND RB.irn IS NULL AND RB.irnFlag IS NULL and RB.billCtgy = 'B2B'")
	public List<RetailBills> getB2BRetailBills();

//	/**
//	 * method to get fetch B2B credit bills with IRN error
//	 * 
//	 */
//	@Query(value = "SELECT RB from RetailBills RB WHERE RB.gstNum IS NOT NULL AND RB.irn IS NULL AND RB.irnFlag IS NOT NULL AND RB.irnFlag= ?1")
//	public List<RetailBills> getIrnErrorBills(String errorFlag);

	/**
	 * method to get fetch B2B credit bills with IRN error
	 * 
	 */
	@Query(value = "select * from bil_retail.retail_bills rb " + "where irn_flag = :errorFlag "
			+ "and ( (message like '%Unexpected error calling gstin:%') " + "or (message is null) "
			+ "or (message like '%Invalid Token%') " + "or (message like '%Duplicate IRN%') "
			+ "or (message like '%Application error%') ) " + "and bill_ctgy = 'B2B' ", nativeQuery = true)
	public List<RetailBills> getIrnErrorBills(@Param("errorFlag") String errorFlag);

	/**
	 * 
	 */
	@Query(value = "SELECT RB from RetailBills RB WHERE RB.gstNum IS NOT NULL AND RB.billNum = ?1 AND RB.gstNum = ?2 ")
	public RetailBills getBillByNumberandGst(String invNum, String gstIn);

	/********
	 * New Code B2B and B2C
	 *************************************************************************/

	@Query(value = "select * from bil_retail.retail_bills rb where rb.bill_num = :invNum \r\n"
			+ "and rb.bill_ctgy = 'B2C' and rb.irn_flag is null", nativeQuery = true)
	public RetailBills getBillByNumberWithoutGst(@Param("invNum") String invNum);

	@Query(value = "select * from bil_retail.retail_bills rb where rb.gst_num is not null and \r\n"
			+ "rb.bill_num = :invNum and rb.gst_num = :gstIn and rb.bill_ctgy = 'B2B'", nativeQuery = true)
	public RetailBills getBillByNumberWithGst(@Param("invNum") String invNum, @Param("gstIn") String gstIn);

	/******************************************************************************************************/

//	@Query(value = "SELECT CB " + "FROM RetailBills CB "
//			+ "WHERE (:documentNumber is null OR CB.billNum = :documentNumber) "
//			+ "AND DATE(CB.billDt) BETWEEN TO_DATE(:billFromDt, 'DD/MM/YYY') AND TO_DATE(:billToDt, 'DD/MM/YYY') "
//			+ "AND (:gstNumber is null OR CB.gstNum = :gstNumber) " + "AND CB.irnFlag in :irnFlag "
//			+ "AND CB.irnFlag IS NOT NULL " + "AND CB.gstNum is not null")
//	List<RetailBills> getInvoiceDetails(@Param("documentNumber") String docNum, @Param("billFromDt") String fromDate,
//			@Param("billToDt") String toDate, @Param("gstNumber") String buyerGstin,
//			@Param("irnFlag") List<String> status);

	@Query(value = "SELECT * FROM bil_retail.retail_bills rb\r\n"
			+ "	WHERE (:documentNumber is null OR rb.bill_num = :documentNumber) \r\n"
			+ "	AND DATE(rb.bill_dt) BETWEEN TO_DATE(:billFromDt, 'DD/MM/YYY') AND TO_DATE(:billToDt, 'DD/MM/YYY') \r\n"
			+ "	AND (:gstNumber is null OR rb.gst_num = :gstNumber) \r\n"
			+ "	AND rb.irn_flag in :irnFlag\r\n"
			+ "	AND rb.irn_flag IS NOT NULL\r\n"
			+ "	AND rb.gst_num is not null\r\n",nativeQuery = true)
	List<RetailBills> getInvoiceDetails(@Param("documentNumber") String docNum, @Param("billFromDt") String fromDate,
			@Param("billToDt") String toDate, @Param("gstNumber") String buyerGstin,
			@Param("irnFlag") List<String> status);

	List<RetailBills> findByBillNum(String billNum);

	/**
	 * method to get retail bills with IRN is Y, s3_document_key is not null and
	 * email sent count is null or 0
	 * 
	 */
//	@Query(value = "select * from bil_retail.retail_bills rb "
//			+ "where 1=1\r\n" + 
//			"and rb.irn_flag ='Y'\r\n" + 
//			"and (rb.email_sent_count isnull or rb.email_sent_count =0)\r\n" + 
//			"and rb.s3_document_key notnull \r\n" +
//			"order by cr_dt desc")
//	public List<RetailBills> getEligibleRetailBills();

//	@Query(value = "select rb.* from bil_retail.retail_bills rb "+
//			"where 1=1 \r\n" + 
//			"and rb.irn_flag ='Y' \r\n" + 
//			"and (rb.email_sent_count isnull or rb.email_sent_count =0) \r\n" + 
//			"and rb.s3_document_key notnull \r\n" +
//			"and bill_num = '220608000037'", nativeQuery = true)
//	public List<RetailBills> getEligibleRetailBills();

	// Old Query
//		@Query(value = "select rb.* from bil_retail.retail_bills rb "
//		+ "where 1=1\r\n" + 
//		"and rb.irn_flag ='Y'\r\n" + 
//		"and (rb.email_sent_count isnull or rb.email_sent_count =0)\r\n" + 
//		"and rb.s3_document_key notnull \r\n" +
//		"and rb.bill_to_email notnull \r\n" +
//		"order by rb.upd_dt asc \r\n " + 
//		"FETCH FIRST 50 ROWS ONLY", nativeQuery = true)
//	 public List<RetailBills> getEligibleRetailBills();

	@Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where 1=1 \r\n" + "and rb.irn_flag ='Y' \r\n"
			+ "and (rb.email_sent_count isnull or rb.email_sent_count =0) \r\n" + "and rb.s3_document_key notnull \r\n"
			+ "and rb.bill_to_email notnull \r\n" + "and rb.bill_ctgy = 'B2B'\r\n" + "order by rb.upd_dt asc \r\n"
			+ "FETCH FIRST 75 ROWS only", nativeQuery = true)
	public List<RetailBills> getB2BEligibleRetailBills();

	/**
	 * @Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where
	 *              1=1 \r\n" + "and rb.irn_flag is null \r\n" + "and
	 *              (rb.email_sent_count isnull or rb.email_sent_count =0) \r\n" +
	 *              "and rb.s3_document_key notnull \r\n" + "and rb.bill_to_email
	 *              notnull \r\n" + "and rb.bill_ctgy = 'B2C'\r\n" + "order by
	 *              rb.upd_dt asc " + "FETCH FIRST 50 ROWS only",nativeQuery = true)
	 *              public List<RetailBills> getB2CEligibleRetailBills();
	 * 
	 * @Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where
	 *              1=1 \r\n" + "and rb.irn_flag ='Y' \r\n" + "and
	 *              (rb.email_sent_count isnull or rb.email_sent_count =0) \r\n" +
	 *              "and rb.s3_document_key notnull \r\n" + "and rb.bill_to_email
	 *              notnull \r\n" + "and rb.bill_ctgy = 'B2B'\r\n" + "and bill_num =
	 *              '220609000002'", nativeQuery = true) public List<RetailBills>
	 *              getB2BEligibleRetailBillsTest();
	 * 
	 * @Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where
	 *              1=1 \r\n" + "and rb.irn_flag is null \r\n" + "and
	 *              (rb.email_sent_count isnull or rb.email_sent_count =0) \r\n" +
	 *              "and rb.s3_document_key notnull \r\n" + "and rb.bill_to_email
	 *              notnull \r\n" + "and rb.bill_ctgy = 'B2C'\r\n" + "and bill_num
	 *              in ('230601000041','230601000046')", nativeQuery = true) public
	 *              List<RetailBills> getB2CEligibleRetailBillsTest();
	 */

	// Old Query
//	@Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + 
//				"where 1=1\r\n" + 
//				"and rb.irn_flag ='Y'\r\n" + 
//				"and rb.s3_document_key isnull\r\n" + 
//				"order by rb.bill_dt asc \r\n" +
//				"FETCH FIRST 50 ROWS ONLY", nativeQuery = true)
//	 public List<RetailBills> getEligibleIRNRetailBills();

	@Query(value = "select rb.* from bil_retail.retail_bills rb  \r\n" + "where 1=1 \r\n" + "and rb.irn_flag ='Y' \r\n"
			+ "and rb.s3_document_key isnull \r\n" + "and rb.bill_ctgy = 'B2B'\r\n" + "order by rb.bill_dt asc \r\n"
			+ "FETCH FIRST 75 ROWS only", nativeQuery = true)
	public List<RetailBills> getB2BEligibleIRNRetailBills();

	@Query(value = "select rb.* from bil_retail.retail_bills rb  \r\n" + "where 1=1 \r\n"
			+ "and rb.irn_flag isnull \r\n" + "and rb.s3_document_key isnull \r\n"
			+ "and (rb.gst_num isnull or rb.gst_num = '') " + "and rb.bill_ctgy = 'B2C'\r\n"
			+ "order by rb.bill_dt asc \r\n" + "FETCH FIRST 200 ROWS only", nativeQuery = true)
	public List<RetailBills> getB2CEligibleWithoutIRNRetailBills();

	/*****
	 * For Test
	 * 
	 * @Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where
	 *              1=1 \r\n" + "and rb.irn_flag ='Y' \r\n" + "and
	 *              rb.s3_document_key isnull \r\n" + "and rb.bill_ctgy = 'B2B'
	 *              \r\n" + "and rb.bill_num in ('230601000001','230601000004')
	 *              \r\n" + "order by rb.bill_dt desc \r\n" + "FETCH FIRST 50 ROWS
	 *              only", nativeQuery = true) public List<RetailBills>
	 *              getB2BEligibleIRNRetailBillsTest(); //Test 220608000509
	 * 
	 * @Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + "where
	 *              1=1 \r\n" + "and rb.irn_flag is null \r\n" + "and
	 *              rb.s3_document_key isnull \r\n" + "and (rb.gst_num is null or
	 *              rb.gst_num = '') \r\n" + "and rb.bill_ctgy = 'B2C' \r\n" + "and
	 *              cast(cr_dt as date) >= cast('2023-01-19' as date) "+ "order by
	 *              rb.bill_dt asc \r\n" + "FETCH FIRST 50 ROWS only", nativeQuery =
	 *              true) public List<RetailBills>
	 *              getB2CEligibleWithoutIRNRetailBillsTest();
	 */

	/*******************************************************************************/

	@Query(value = "SELECT rb.* from bil_retail.retail_bills rb where rb.bill_id  = :billId", nativeQuery = true)
	public RetailBills getNewBillsById(@Param("billId") Long billId);

//	For Test
//		@Query(value = "select rb.* from bil_retail.retail_bills rb \r\n" + 
//				"where 1=1\r\n" + 
//				"and rb.irn_flag ='Y'\r\n" + 
//				"and rb.s3_document_key isnull\r\n" +
//				"and bill_num in ('220608000498')", nativeQuery = true)
//	 public List<RetailBills> getEligibleIRNRetailBills();

//	@Query(value = "select rb.* from bil_retail.retail_bills rb where rb.bill_num = :billNum", nativeQuery = true)
//	public RetailBills getSourceByBillNum(@Param("billNum") String billNum);

	@Query(value = "select rb.bill_ctgy, rb.bill_num, rb.irn_flag, rb.message, rb.irn, rb.bill_dt, rbb.\"source\",rb.bill_type, rb.base_amt, \r\n"
			+ "rb.cgst_amt, rb.sgst_amt, rb.igst_amt, rb.actual_outstanding_amt, rb.gst_num, rb.s3_document_key, rb.status \r\n"
			+ "from bil_retail.retail_bills rb \r\n"
			+ "inner join bil_retail.retail_bill_batches rbb on rb.bill_batch_id = rbb.bill_batch_id \r\n"
			+ "where rb.bill_num in :billNum", nativeQuery = true)
	public List<Object[]> getSourceByBillNum(@Param("billNum") List<String> billNum);
	
	

//	@Query(value = "select rb.* from bil_retail.retail_bills rb \r\n"
//			+ "inner join bil_retail.retail_bill_batches rbb \r\n" + "on rb.bill_batch_id = rbb.bill_batch_id \r\n" + ""
//			+ " where rb.bill_num in :billNum", nativeQuery = true)
//	public RetailBills getSourceByBilNum(@Param("billNum") List<String> billNum);

	

//	@Query(value = "Select rb.bill_ctgy, rb.bill_num, rb.irn_flag, rb.message from bil_retail.retail_bills rb "
//			+ " where rb.bill_num  = :billNum", nativeQuery = true)
//	public List<Object[]> getSourceByBillNum(@Param("billNum") String billNum);

	/******************************************************************************************************/
	/*****
	 * For Test
	 */
	
	@Query(value = "SELECT * from retail_bills rb \r\n"
			+ "where rb.gst_num IS NOT NULL AND rb.irn IS NULL \r\n"
			+ "AND rb.irn_flag  IS NULL \r\n"
			+ "and rb.bill_ctgy = 'B2B'\r\n"
			+ "where bill_num in :billNum",nativeQuery = true)
	public List<RetailBills> getB2BTestRetailBills(@Param("billNum") List<String> billNum);
}
