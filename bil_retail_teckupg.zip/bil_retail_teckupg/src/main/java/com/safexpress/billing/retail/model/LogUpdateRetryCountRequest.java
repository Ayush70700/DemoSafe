package com.safexpress.billing.retail.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"projectName",
	"integrationId",
	"retryCount"
})
public class LogUpdateRetryCountRequest {
	
	@JsonProperty("projectName")
	private String projectName;
	
	@JsonProperty("integrationId")
	private Long integrationId;
	
	@JsonProperty("retryCount")
	private String retryCount;
	

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the integrationId
	 */
	public Long getIntegrationId() {
		return integrationId;
	}

	/**
	 * @param integrationId the integrationId to set
	 */
	public void setIntegrationId(Long integrationId) {
		this.integrationId = integrationId;
	}

	/**
	 * @return the retryCount
	 */
	public String getRetryCount() {
		return retryCount;
	}

	/**
	 * @param retryCount the retryCount to set
	 */
	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}

}
