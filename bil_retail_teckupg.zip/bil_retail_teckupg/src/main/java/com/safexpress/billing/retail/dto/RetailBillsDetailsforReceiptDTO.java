package com.safexpress.billing.retail.dto;

import java.util.Date;

public class RetailBillsDetailsforReceiptDTO {
	private Long documentId;
	private String documentNumber;
	private String documentType;
	private Date documentDate;
	private String customerName;
	private Double actualAmount;
	private Double outstandingAmount;
	private String billingLevelValue;
	
	public Long getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public Date getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Double getActualAmount() {
		return actualAmount;
	}
	public void setActualAmount(Double actualAmount) {
		this.actualAmount = actualAmount;
	}
	public Double getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	public String getBillingLevelValue() {
		return billingLevelValue;
	}
	public void setBillingLevelValue(String billingLevelValue) {
		this.billingLevelValue = billingLevelValue;
	}
	
	

}
