package com.safexpress.billing.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.safexpress.billing.retail.model.RetailDocDeviationHistory;

public interface IRetailDocDeviationHistoryRepository extends JpaRepository<RetailDocDeviationHistory, Long> {

	@Query("SELECT RDH FROM RetailDocDeviationHistory RDH where RDH.sourceRefId =?1")
	List<RetailDocDeviationHistory> findBySourceRefId(Long sourceRefId);

}