package com.safexpress.billing.retail.config.security;

/******************************************************************
* <h1>JwtAuthenticationFilter</h1>
* JWT Authentication Filter for validating JWT token.
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-08-27 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         27-Aug-2020   KPMG      Initial version . 
******************************************************************/
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.exception.ExceptionResponse;
import com.safexpress.billing.retail.util.Constants;


public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
	@Autowired
	private JwtTokenProvider tokenProvider;
	
	//list of url not to be authenticated.
	public static final List<String> NON_AUTH_END_POINTS = Collections.unmodifiableList(Arrays.asList("/admin/common", "swagger","/api-docs","/actuator","/actuator/health"));

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
			String jwt = getJwtFromRequest(request);
				if (jwt == null) {
					throw new CustomException("JWT Token not found", HttpStatus.UNAUTHORIZED);
				}
				// validate JWT token
				if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
					// check if token user-id matches header user-id
					String userID = request.getHeader("UserName");
					String userName = tokenProvider.getUsernameFromJWT(jwt);
					if (userName != null) {
						// set the data in the constant.
						Constants.setUserName(userName);
					}
					if (userID == null || !userID.equalsIgnoreCase(userName)) {
						throw new CustomException("UserName is invalid", HttpStatus.UNAUTHORIZED);
					}
					Constants.setJwtToken(request.getHeader("Authorization"));
				}
			filterChain.doFilter(request, response);
		} catch (Exception ex) {
			ExceptionResponse errorResponse = new ExceptionResponse("invalid_token", ex.getMessage(), ex.getMessage());
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			response.setContentType("application/json");
			response.getWriter().write(convertObjectToJson(errorResponse));
		}

	}

	 /**
	  * This method is to convert Object to String
	  * @param Object
	  * @return String
	 */
	public String convertObjectToJson(Object object) throws JsonProcessingException {
		if (object == null) {
			return null;
		}
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(object);
	}
	
	 /**
	  * This method is to set the log HeaderInfo
	  * @param userName
	  * @param contextPath
	  * @param 	private
	  * @return Nothing
	 */
	private void setLogHeaderInfo(String userName, String contextPath, String correlationId) {
		// get correlation ID
		String sessionId = correlationId;
		if (sessionId == null || sessionId.isEmpty()) {
			sessionId = generateUniqueCorrelationId();
		}
		String headerInfo = "<"+sessionId + "|" + contextPath + "|" + userName+">:";
		MDC.put("headerInfo", headerInfo);
		Constants.setCorrelationId(sessionId);
	}

	 /**
	  * This method is to generate random CorrelationId
	  * @param Nothing
	  * @return String
	 */
	private String generateUniqueCorrelationId() {
		return UUID.randomUUID().toString();
	}

	 /**
	  * This method is to get JWT Token from the Request Header
	  * @param Nothing
	  * @return String
	 */
	private String getJwtFromRequest(HttpServletRequest request) {
		String bearerToken = request.getHeader("Authorization");
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			return  bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}
	
	 /**
	  * Standard filter method to bypass calling filter
	  * @param request HttpServlet Request
	  * @return boolean
	 */
	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
		// set Log Header Info
		setLogHeaderInfo(request.getHeader("UserName"), request.getRequestURI(), request.getHeader("correlationId"));
		return  NON_AUTH_END_POINTS.stream().anyMatch(p -> {
	        return request.getServletPath().contains(p);
	    });
	}
}