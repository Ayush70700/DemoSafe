package com.safexpress.billing.retail.irn.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class IrnHeaderDTO {
	
	@JsonProperty("BillType") 
	public String billType;
	@JsonProperty("BillId") 
	public Long billId;
	@JsonProperty("Version") 
    public String version;
    @JsonProperty("TranDtls") 
    public TranDtls tranDtls;
    @JsonProperty("DocDtls") 
    public DocDtls docDtls;
    @JsonProperty("SellerDtls") 
    public SellerDtls sellerDtls;
    @JsonProperty("BuyerDtls") 
    public BuyerDtls buyerDtls;
    @JsonProperty("DispDtls") 
    public Object dispDtls;
    @JsonProperty("ShipDtls") 
    public Object shipDtls;
    @JsonProperty("ItemList") 
    public List<ItemList> itemList;
    @JsonProperty("ValDtls") 
    public ValDtls valDtls;
	public String getVersion() {
		return version;
	}
	public TranDtls getTranDtls() {
		return tranDtls;
	}
	public DocDtls getDocDtls() {
		return docDtls;
	}
	public SellerDtls getSellerDtls() {
		return sellerDtls;
	}
	public BuyerDtls getBuyerDtls() {
		return buyerDtls;
	}
	public Object getDispDtls() {
		return dispDtls;
	}
	public Object getShipDtls() {
		return shipDtls;
	}
	public List<ItemList> getItemList() {
		return itemList;
	}
	public ValDtls getValDtls() {
		return valDtls;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public void setTranDtls(TranDtls tranDtls) {
		this.tranDtls = tranDtls;
	}
	public void setDocDtls(DocDtls docDtls) {
		this.docDtls = docDtls;
	}
	public void setSellerDtls(SellerDtls sellerDtls) {
		this.sellerDtls = sellerDtls;
	}
	public void setBuyerDtls(BuyerDtls buyerDtls) {
		this.buyerDtls = buyerDtls;
	}
	public void setDispDtls(Object dispDtls) {
		this.dispDtls = dispDtls;
	}
	public void setShipDtls(Object shipDtls) {
		this.shipDtls = shipDtls;
	}
	public void setItemList(List<ItemList> itemList) {
		this.itemList = itemList;
	}
	public void setValDtls(ValDtls valDtls) {
		this.valDtls = valDtls;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
    
}
