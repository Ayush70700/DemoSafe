package com.safexpress.billing.retail.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.safexpress.billing.retail.dto.PropelAuthRequestDTO;
import com.safexpress.billing.retail.dto.PropelJwtTokenRespDTO;
import com.safexpress.billing.retail.exception.CustomException;


@Component
public class PropelAuthUtil {

	@Value("${service.propel.authorize}")
	private String serviceUrl;
	@Value("${propel.admin.user}")
	private String username;
	@Value("${propel.admin.password}")
	private String password;
	@Value("${propel.channel.id}")
	private Long channelId;

	public String getPropelToken() throws CustomException {
		PropelAuthRequestDTO request = new PropelAuthRequestDTO();
		request.setChannelId(channelId);
		request.setUsername(username);
		request.setPassword(password);
		HttpEntity<PropelAuthRequestDTO> entity = new HttpEntity<>(request, createPropelBookingHeader(username, null));
		try {
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<PropelJwtTokenRespDTO> response = restTemplate.exchange(serviceUrl, HttpMethod.POST, entity,
					PropelJwtTokenRespDTO.class);
			PropelJwtTokenRespDTO jwtToken = response.getBody();
			return jwtToken.getData().getAccessToken();
		} catch (Exception exception) {
			throw new CustomException(exception.getMessage());
		}

	}

	/**
	 * Creates HttpHeaders for Propel-I booking services
	 * 
	 * @param header
	 * @return HttpHeaders
	 */
	public static HttpHeaders createPropelBookingHeader(String userid, String jwtToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", jwtToken);
		headers.set("correlationId", Constants.getCorrelationId());
		headers.set("userId", userid);
		return headers;
	}

}
