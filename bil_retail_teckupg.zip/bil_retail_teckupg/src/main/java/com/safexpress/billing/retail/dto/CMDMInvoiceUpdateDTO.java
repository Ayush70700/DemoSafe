package com.safexpress.billing.retail.dto;

import java.math.BigDecimal;

public class CMDMInvoiceUpdateDTO {
//	private Long billId;
//	private Long billLineId;
//	private Long documentId;
//	private Double amount;
//	private String reason;
//	private String remarks;
	
	private Long cmdmBillId;
	private Long cmdmBillLineId;
	private Long documentId;
	private String documentType;
	private BigDecimal amount;
	private String reason;
	private String remarks;
	public Long getCmdmBillId() {
		return cmdmBillId;
	}
	public void setCmdmBillId(Long cmdmBillId) {
		this.cmdmBillId = cmdmBillId;
	}
	public Long getCmdmBillLineId() {
		return cmdmBillLineId;
	}
	public void setCmdmBillLineId(Long cmdmBillLineId) {
		this.cmdmBillLineId = cmdmBillLineId;
	}
	public Long getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
