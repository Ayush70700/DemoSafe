package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SellerDtls {

	@JsonProperty("Gstin") 
    public String gstin;
    @JsonProperty("LglNm") 
    public String lglNm;
    @JsonProperty("TrdNm") 
    public String trdNm;
    @JsonProperty("Addr1") 
    public String addr1;
    @JsonProperty("Addr2") 
    public String addr2;
    @JsonProperty("Loc") 
    public String loc;
    @JsonProperty("Pin") 
    public int pin;
    @JsonProperty("Stcd") 
    public String stcd;
    @JsonProperty("Ph") 
    public String ph;
    @JsonProperty("Em") 
    public String em;
	public String getGstin() {
		return gstin;
	}
	public String getLglNm() {
		return lglNm;
	}
	public String getTrdNm() {
		return trdNm;
	}
	public String getAddr1() {
		return addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public String getLoc() {
		return loc;
	}
	public int getPin() {
		return pin;
	}
	public String getStcd() {
		return stcd;
	}
	public String getPh() {
		return ph;
	}
	public String getEm() {
		return em;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public void setLglNm(String lglNm) {
		this.lglNm = lglNm;
	}
	public void setTrdNm(String trdNm) {
		this.trdNm = trdNm;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public void setStcd(String stcd) {
		this.stcd = stcd;
	}
	public void setPh(String ph) {
		this.ph = ph;
	}
	public void setEm(String em) {
		this.em = em;
	}
}
