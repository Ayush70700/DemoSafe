
package com.safexpress.billing.retail.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.safexpress.billing.retail.dto.TestDTO;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;
import com.safexpress.billing.retail.service.TestIrnService;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping(path = "/")
public class TestController {
	
	@Autowired
	TestIrnService testIrnService;
	
	/**
	 * REST API: GET : Method to get the B2B bills not integrated for IRN
	 * 
	 */
	@Operation(summary = "Method to get applied Credit Bills")
	@GetMapping(path = "/irn/test/{errorFlag}")
	public List<IrnHeaderDTO> getB2BBills(@RequestBody TestDTO testDTO ,@PathVariable String errorFlag) {
		return testIrnService.getB2bTestBills(testDTO,errorFlag);
	}
}
