package com.safexpress.billing.retail.util;

/**
 * <h1>RetailBillingUtil</h1>
 * <P>
 * The RetailBillingUtil contains all the util methods required for Retail Billing.
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.safexpress.billing.retail.dto.BasicApiResponseDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateResponseDTO;
import com.safexpress.billing.retail.dto.ErrorResponse;
import com.safexpress.billing.retail.dto.PostRetailBillRequestDTO;
import com.safexpress.billing.retail.dto.RespData;
import com.safexpress.billing.retail.dto.RetailBillWaybillDetailDTO;
import com.safexpress.billing.retail.dto.RetailGetWaybillRequestDTO;
import com.safexpress.billing.retail.dto.RetailWayBillWriteOffDTO;
import com.safexpress.billing.retail.dto.RetailWaybillByBillsReqDTO;
import com.safexpress.billing.retail.dto.RetailWaybillByBillsRespDTO;
import com.safexpress.billing.retail.dto.RetailWaybillDTO;
import com.safexpress.billing.retail.dto.RetailWaybillResponseDTO;
import com.safexpress.billing.retail.dto.RetailWaybillResponseWrapperDTO;
import com.safexpress.billing.retail.dto.UntagRetailBillWaybillRequest;
import com.safexpress.billing.retail.dto.UntagRetailBillingWaybillRequest;
import com.safexpress.billing.retail.dto.WaybilDetailRequestDTO;
import com.safexpress.billing.retail.dto.WaybillDetailsDTO;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.model.DeleteRetailBillingWaybillResponse;
import com.safexpress.billing.retail.model.RetailBillBatchDetails;
import com.safexpress.billing.retail.model.RetailBillBatches;
import com.safexpress.billing.retail.model.RetailBillIntegrations;
import com.safexpress.billing.retail.model.RetailBills;
import com.safexpress.billing.retail.model.RetailDocDeviationHistory;
import com.safexpress.billing.retail.repository.IRetailBillBatchDetailsRepository;
import com.safexpress.billing.retail.repository.IRetailBillsRepository;

@Component
public class RetailBillingUtil {

	private static final Logger logger = LoggerFactory.getLogger(RetailBillingUtil.class);
	@Autowired
	PropelAuthUtil propelAuthUti;

	@Autowired
	ApiUtil apiUtil;
	
	@Autowired
	private IRetailBillBatchDetailsRepository retailBillBatchDetailsRepository;

	@Autowired
	private IRetailBillsRepository retailBillsRepository;

	@Value("${propel.admin.user}")
	private String userid;

	@Value("${retail.waybill.api}")
	private String retailWaybillApiVal;

	@Value("${credit.waybill.api}")
	private String creditWaybillApiVal;

	@Value("${billing.ebill.api}")
	private String eBillServiceUrl;
	
	@Value("${cloud.oracle.taxRateCode.cgst}")
	private String oracleCgst;
	@Value("${cloud.oracle.taxRateCode.igst}")
	private String oracleIgst;
	@Value("${cloud.oracle.taxRateCode.sgst}")
	private String oracleSgst;

	@Value("${cloud.oracle.taxRateVal.cgst}")
	private String oracleCgstVal;
	@Value("${cloud.oracle.taxRateVal.igst}")
	private String oracleIgstVal;
	@Value("${cloud.oracle.taxRateVal.sgst}")
	private String oracleSgstVal;

	/**
	 * method to create Retail Bill Batch Record
	 * 
	 * @return RetailBillBatches
	 */
	public RetailBillBatches createRetailBillBatch(String source) {
		RetailBillBatches retailBillBatch = new RetailBillBatches();
		retailBillBatch.setBatchType(Constants.getRetailBatchType());
		retailBillBatch.setPhase("INITIATE");
		retailBillBatch.setSource(source);
		return retailBillBatch;
	}

	public RetailBillBatchDetails generateSSPBillBatchDetails(RetailBillBatches retailBillBatches) {
		RetailBillBatchDetails retailBillBatchDetails = new RetailBillBatchDetails();
		retailBillBatchDetails.setSspFlag("Y");
		retailBillBatchDetails.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		return retailBillBatchDetails;
	}

	/**
	 * GEt waybills for SSP
	 * 
	 * @param source
	 * @param retailBillBatches
	 * @param rbDetail
	 * @param wayBillNums
	 * @param waybillNumArray
	 * @return
	 * @throws URISyntaxException
	 * @throws CustomException
	 */
	public RetailWaybillResponseDTO callGetWaybillsService(String source, RetailBillBatches retailBillBatches,
			RetailBillBatchDetails rbDetail, List<String> wayBillNums) throws URISyntaxException, CustomException {
		String propelToken = propelAuthUti.getPropelToken();
		logger.info("RetailBatch:: RetailBillingUtil - callGetWaybillsService - BillBatchDetailId: {}",
				rbDetail.getBillBatchDetailId());
		RetailGetWaybillRequestDTO retailGetWaybillRequestDTO = new RetailGetWaybillRequestDTO();
		retailGetWaybillRequestDTO.setBillBatchId(retailBillBatches.getBillBatchId());
		retailGetWaybillRequestDTO.setBatchDetailId(rbDetail.getBillBatchDetailId());
		retailGetWaybillRequestDTO.setBatchType("Retail");
		retailGetWaybillRequestDTO.setGstFlag(rbDetail.getGstFlag());
		retailGetWaybillRequestDTO.setPrcFlag(rbDetail.getPrcFlag());
		retailGetWaybillRequestDTO.setPrcFlag(rbDetail.getPrcFlag());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		if ("Y".equals(rbDetail.getPaidFlag())) {
			retailGetWaybillRequestDTO.setMode("PAID");
			if (rbDetail.getToPickupDt() != null) {
				retailGetWaybillRequestDTO.setToPickupDate(dateFormat.format(rbDetail.getToPickupDt()));
			}
		} else if ("N".equals(rbDetail.getPaidFlag())) {
			retailGetWaybillRequestDTO.setMode("TOPAY");
			if (rbDetail.getToDeliveryDt() != null) {
				retailGetWaybillRequestDTO.setToDeliveryDate(dateFormat.format(rbDetail.getToDeliveryDt()));
			}
		} else {
			retailGetWaybillRequestDTO.setMode("");
		}
		retailGetWaybillRequestDTO.setSource(source);
		retailGetWaybillRequestDTO.setWaybills(wayBillNums);
		Gson g = new Gson();
		logger.info("RetailBatch:: RetailBillingUtil - callGetWaybillsService - Get Waybill Payload -- {}",
				g.toJson(retailGetWaybillRequestDTO));
		final String url = retailWaybillApiVal + "/v1/wbdetails/values";
		HttpEntity<RetailGetWaybillRequestDTO> requestEntity = new HttpEntity<>(retailGetWaybillRequestDTO,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		return this.restTemplateCall(url, requestEntity);
	}

	/**
	 * Method to call Rest Service and Handle Error
	 * 
	 * @param url
	 * @param requestEntity
	 * @return
	 */
	private RetailWaybillResponseDTO restTemplateCall(String url,
			HttpEntity<RetailGetWaybillRequestDTO> requestEntity) {
		try {
			logger.info("API URL:" + url);
			ResponseEntity<RetailWaybillResponseWrapperDTO> responseEntity = null;
			RestTemplate restTemplate = new RestTemplate();
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					RetailWaybillResponseWrapperDTO.class);

			RetailWaybillResponseWrapperDTO wbWrapper = responseEntity.getBody();
			Gson g = new Gson();
			logger.info("GET WAYBILL RESPONSE" + g.toJson(responseEntity.getBody()));
			if (wbWrapper != null) {
				if ("SUCCESS".equals(wbWrapper.getStatus()) && (wbWrapper.getData() != null)) {
					RespData wbResp = wbWrapper.getData();
					return wbResp.getRetBillWayblResp();
				} else {
					return null;
				}

			} else {
				return null;
			}
		} catch (Exception e) {
			logger.info("Waybill API Call Error " + e.getMessage());
			return null;
			// Notification
		}
	}

	/**
	 * Method to initial Bill Id Post
	 * 
	 * @param newbill
	 * @param wbList
	 * @throws CustomException
	 */
	public BasicApiResponseDTO initiatePostBillId(RetailBills newbill, List<RetailWaybillDTO> wbList)
			throws CustomException {
		logger.info("RetailBatch:: initiatePostBillId: Bill Number {} -- BillBatchDetailId: {} ", newbill.getBillNum(),
				newbill.getBillBatchDetailId());

		try {
			PostRetailBillRequestDTO postRetailBillRequestDTO = new PostRetailBillRequestDTO();
			postRetailBillRequestDTO.setBatchDetailId(newbill.getBillBatchDetailId());
			postRetailBillRequestDTO.setBatchId(newbill.getRetailBillBatches().getBillBatchId());
			postRetailBillRequestDTO.setBillId(String.valueOf(newbill.getBillId()));
			postRetailBillRequestDTO.setBillNumber(newbill.getBillNum());
			List<Long> wbIds = new ArrayList<>();
			for (RetailWaybillDTO wb : wbList) {
				wbIds.add(wb.getWaybillId());
			}
			postRetailBillRequestDTO.setWaybillIds(wbIds);
			return this.callPostRetailBillId(postRetailBillRequestDTO);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("RetailBatch:: initiatePostBillId: Bill Number {} -- BillBatchDetailId: {} -- Exception: {} ",
					newbill.getBillNum(), newbill.getBillBatchDetailId(), e.getMessage());

		}
		return null;

	}

	/**
	 * Method to call Retail Bill Id Post API
	 * 
	 * @param postRetailBillRequestDTO
	 * @return
	 * @throws CustomException
	 */
	private BasicApiResponseDTO callPostRetailBillId(PostRetailBillRequestDTO postRetailBillRequestDTO)
			throws CustomException {
		String propelToken = propelAuthUti.getPropelToken();
		RestTemplate restTemplate = new RestTemplate();
		String url = retailWaybillApiVal + "/v1/billing/confirm-batch/post-retail-bill-detail";
		logger.info("RetailBatch:: callPostRetailBillId -- Post Bill API {} ", url);

		Gson g = new Gson();
		logger.info("RetailBatch:: callPostRetailBillId: BatchDetailId: {} -- Post Bill Request {} ",
				postRetailBillRequestDTO.getBatchDetailId(), g.toJson(postRetailBillRequestDTO));

		HttpEntity<PostRetailBillRequestDTO> requestEntity = new HttpEntity<>(postRetailBillRequestDTO,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		ResponseEntity<BasicApiResponseDTO> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, BasicApiResponseDTO.class);
			logger.info("RetailBatch:: callPostRetailBillId -- Post Bill API Response Status: {} ", responseEntity.getBody().getStatus());
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
			logger.info("RetailBatch:: callPostRetailBillId:: BatchDetailId: {} -- HttpClientErrorException: {} ",
					postRetailBillRequestDTO.getBatchDetailId(), e.getMessage());
			throw new CustomException("RetailBatch:: callPostRetailBillId -- Exception while post retail Bill :"
					+ e.getLocalizedMessage());
		}
		return responseEntity.getBody();

	}

	/**
	 * Method to Untag Retail Bill Number Post API
	 * 
	 * @param untagRetailBillingWaybillRequest
	 * @return
	 */
	public String untagRetailBillNumber(String billNumber) throws CustomException {

		logger.info("RetailBatch:: untagRetailBillNumber: billNumber to Untag Waybill for Retail Bills: {} ",
				billNumber);

		String respoStatus = "FAILURE";
		String propelToken = propelAuthUti.getPropelToken();
		RestTemplate restTemplate = new RestTemplate();
		String url = retailWaybillApiVal + "/v1/wbdetails/retail/untagwb";

		UntagRetailBillingWaybillRequest untagRetailBillRequest = new UntagRetailBillingWaybillRequest();
		untagRetailBillRequest.setBillNumber(billNumber);

		HttpEntity<UntagRetailBillingWaybillRequest> requestEntity = new HttpEntity<>(untagRetailBillRequest,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		ResponseEntity<DeleteRetailBillingWaybillResponse> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					DeleteRetailBillingWaybillResponse.class);
			if (responseEntity.getBody() != null) {
				logger.info("RetailBatch:: :: Untag Retail Bill Response Message: {} -- BillNumber: {} ",
						responseEntity.getBody().getMessage(), billNumber);

				if (responseEntity.getBody().getStatus().equalsIgnoreCase("SUCCESS")) {
					respoStatus = "SUCCESS";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("RetailBatch:: Untag RetailBill Number: Exception: {} ", e.getMessage());

		}
		return respoStatus;

	}

	/**
	 * Method to group Waybills by Pickup Date
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Date, List<RetailWaybillDTO>> groupByPickupDate(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getPickupDate() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getPickupDate));
	}

	/**
	 * Method to group Waybills by Pickup Date
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Long, List<RetailWaybillDTO>> groupByCnorId(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getConsignerId() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getConsignerId));
	}
	
	/**
	 * Method to group Waybills by Destination Branch
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Long, List<RetailWaybillDTO>> groupByDestinationBr(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getDeliveryBrId() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getDeliveryBrId));
	}

	/**
	 * Method to group Waybills by booking Branch
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Long, List<RetailWaybillDTO>> groupByBookingBr(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getBkgBrId() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getBkgBrId));
	}

	/**
	 * Method to group Waybills by Delivery Date
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Date, List<RetailWaybillDTO>> groupByDeliveryDate(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getDelieveryDate() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getDelieveryDate));
	}

	/**
	 * Method to group Waybills by Consignee Id
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Long, List<RetailWaybillDTO>> groupByCneeId(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getConsigneeId() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getConsigneeId));
	}
	
	/**
	 * Method to group Waybills by GSTIN
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<String, List<RetailWaybillDTO>> groupByGSTIN(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getGstNum() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getGstNum));
	}

	/**
	 * method to group waybills by PRC ID
	 * 
	 * @param waybillList
	 * @return
	 */
	public Map<Long, List<RetailWaybillDTO>> groupByPrcId(List<RetailWaybillDTO> waybillList) {
		waybillList = waybillList.stream().filter(wb -> wb.getPrcId() != null).collect(Collectors.toList());
		return waybillList.stream().collect(Collectors.groupingBy(RetailWaybillDTO::getPrcId));
	}

	/**
	 * Validate SSP API Non Availability Time
	 * 
	 * @param waybillList
	 * @return
	 */
	public boolean vldSSPAPINonAvailTime(String startTime, String endTime) {
		 
		 boolean checkFlagResp = true;
		 //Capturing today's date
	     Date today = new Date();
	        
	     DateFormat dftime = new SimpleDateFormat("HH:mm");
	     dftime.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
	     String currTimeIST = dftime.format(today);
	     logger.info("RetailServiceImpl - initateSSPBillCreation - Date in Indian Timezone (IST) current Time IST: {} ",currTimeIST);
	     
	     LocalTime startTime1  = LocalTime.parse(startTime); 
         LocalTime endTime2 = LocalTime.parse(endTime); 
         LocalTime currtime = LocalTime.parse(currTimeIST);
         logger.info("RetailServiceImpl - initateSSPBillCreation -Value of currtime: {}" ,currtime); 
         
         // apply compareTo() 
         int startTimeValue = currtime.compareTo(startTime1); 
         int limitTimeValue = currtime.compareTo(endTime2);
         // print LocalDateTime 
         logger.info("RetailServiceImpl - initateSSPBillCreation -Int startTimeValue: {}" ,startTimeValue); 
         logger.info("RetailServiceImpl - initateSSPBillCreation -Int limitTimeValue: {}" ,limitTimeValue); 
	     
       
      	if ((startTimeValue > 0 && limitTimeValue < 0) || (startTimeValue == 0 && limitTimeValue < 0)) {
      		logger.info("RetailServiceImpl - initateSSPBillCreation -This service is not available between : {}PM - {}PM. Please try after: {}PM", startTime, endTime, endTime);
      		checkFlagResp = false;
     	}else {
     		logger.info("RetailServiceImpl - initateSSPBillCreation -This service is available at this time {}.",currTimeIST);
     	}
	      
		return checkFlagResp;
	}

	public RetailWaybillByBillsRespDTO getWayBillsByBillId(String billId) throws CustomException {
		String propelToken = propelAuthUti.getPropelToken();
		RestTemplate restTemplate = new RestTemplate();
		String url = retailWaybillApiVal + "/v1/waybillbilling/cmdm/values";
		RetailWaybillByBillsReqDTO request = new RetailWaybillByBillsReqDTO();
		request.setBillId(billId);
		request.setBillType("RETAIL_GST_BILL");
		request.setWaybillNumber("");
		HttpEntity<RetailWaybillByBillsReqDTO> requestEntity = new HttpEntity<>(request,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		ResponseEntity<RetailWaybillByBillsRespDTO> responseEntity = null;
		logger.info("Request Data" + new Gson().toJson(request));
		try {
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					RetailWaybillByBillsRespDTO.class);
		} catch (HttpClientErrorException e) {
			throw new CustomException("Exception Calling get waybill api :" + e.getLocalizedMessage());
		}
		logger.info("Response Data" + new Gson().toJson(responseEntity.getBody()));
		return responseEntity.getBody();
	}

	public RetailBillIntegrations mapWriteOffDataIntegration(RetailWayBillWriteOffDTO retailObj, Long devId) {

		RetailBillIntegrations retailBillIntegrations = new RetailBillIntegrations();
		retailBillIntegrations.setBillType(retailObj.getDocumentType());
		retailBillIntegrations.setDest("ORACLE-GL");
		retailBillIntegrations.setEvent(Constants.RETAIL_WRITEOFF_STATUS);
		retailBillIntegrations.setSource("SAFEX-BILLING");
		retailBillIntegrations.setStatus("INSERTED");
		retailBillIntegrations.setRetryCount(0);
		retailBillIntegrations.setSourceDocAmt(String.valueOf(retailObj.getWriteOffAmt()));
		retailBillIntegrations.setSourceRefId(retailObj.getDocumentId());
		retailBillIntegrations.setCrBy(Constants.getUserName());
		retailBillIntegrations.setUpdBy(Constants.getUserName());
		retailBillIntegrations.setDevId(devId);

		return retailBillIntegrations;
	}

	public RetailDocDeviationHistory mapDevaitionHistFromDtoForWriteoff(RetailWayBillWriteOffDTO retailObj) {

		RetailDocDeviationHistory retailDocDeviationHistory = new RetailDocDeviationHistory();
		retailDocDeviationHistory.setDocNum(retailObj.getDocumentNum());
		retailDocDeviationHistory.setDocType(retailObj.getDocumentType());
		retailDocDeviationHistory.setWriteOffDate(new Date());
		retailDocDeviationHistory.setAmount(retailObj.getWriteOffAmt());
		retailDocDeviationHistory.setSource("SAFEX-BILLING");
		retailDocDeviationHistory.setReason(retailObj.getMessage());
		retailDocDeviationHistory.setRemarks(retailObj.getRemarks());
		retailDocDeviationHistory.setSourceRefId(retailObj.getDocumentId());
		retailDocDeviationHistory.setAmount(retailObj.getWriteOffAmt());
		retailDocDeviationHistory.setCrBy(Constants.getUserName());
		retailDocDeviationHistory.setUpdBy(Constants.getUserName());

		return retailDocDeviationHistory;
	}

	public RetailBillIntegrations mapCreationDataIntegration(RetailBills newbill) {

		logger.info("RetailBillingUtil -- mapCreationDataIntegration -- BillId/SourceRefId -- {} -- Bill Number -- {}",
				newbill.getBillId(), newbill.getBillNum());
		RetailBillIntegrations retailBillIntegrations = new RetailBillIntegrations();
		retailBillIntegrations.setBillType(newbill.getBillType());
		retailBillIntegrations.setDest("ORACLE-GL");
		retailBillIntegrations.setEvent(Constants.RETAIL_BILL_CREATION);
		retailBillIntegrations.setSource("SAFEX-BILLING");
		retailBillIntegrations.setStatus("INSERTED");
		retailBillIntegrations.setRetryCount(0);
		retailBillIntegrations.setSourceDocAmt(String.valueOf(newbill.getOutstandingAmt()));
		retailBillIntegrations.setSourceRefId(newbill.getBillId());
		retailBillIntegrations.setCrBy(Constants.getUserName());
		retailBillIntegrations.setUpdBy(Constants.getUserName());

		return retailBillIntegrations;
	}

	public CMDMInvoiceUpdateResponseDTO setCMDMInvoiceUpdateResponseDTO(CMDMInvoiceUpdateDTO obj, String status,
			String message) {
		CMDMInvoiceUpdateResponseDTO response = new CMDMInvoiceUpdateResponseDTO();
		response.setMessage(message);
		response.setBillId(obj.getCmdmBillId());
		response.setStatus(status);
		response.setBillLineId(obj.getCmdmBillLineId());
		return response;
	}

	public RetailDocDeviationHistory mapDevaitionHistFromDtoForCmdm(RetailBills rbill, CMDMInvoiceUpdateDTO obj) {
		RetailDocDeviationHistory retDocDeviationHistory = new RetailDocDeviationHistory();
		retDocDeviationHistory.setRetailBills(rbill);
		retDocDeviationHistory.setCrBy(Constants.getUserName());
		retDocDeviationHistory.setCustPrcId(rbill.getPrcId());
		retDocDeviationHistory.setCustName(rbill.getBillToCustName());
		retDocDeviationHistory.setDocType("RETAIL_BILL");
		retDocDeviationHistory.setExistingAltColBr(rbill.getAltCollBr());
		retDocDeviationHistory.setExistingAltColBrId(rbill.getAltCollBrId());
		retDocDeviationHistory.setExistingColBrId(rbill.getCollBrId());
		retDocDeviationHistory.setExistingAltColBr(rbill.getCollBr());
		retDocDeviationHistory.setExistingSubmsnBr(rbill.getSubmsnBr());
		retDocDeviationHistory.setExistingSubmsnBrId(rbill.getSubmsnBrId());
		retDocDeviationHistory.setSource("SFX-BILLING");
		retDocDeviationHistory.setStatus(rbill.getStatus());
		retDocDeviationHistory.setAmount(obj.getAmount().doubleValue());
		retDocDeviationHistory.setEvent("CMDM");
		retDocDeviationHistory.setSourceRefId(obj.getCmdmBillId());
		retDocDeviationHistory.setRemarks(obj.getRemarks());
		retDocDeviationHistory.setReason(obj.getReason());
		return retDocDeviationHistory;
	}

	// format date
	public String formatDateToString(Date utilDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return formatter.format(utilDate);
	}

	/**
	 * Converts the JSON String to a List of ErrorResponse DTO
	 * 
	 * @param message
	 * @return
	 * @throws CustomException
	 */
	public List<ErrorResponse> convertStringToJson(String message) throws CustomException {
		try {
			List<ErrorResponse> err = new ArrayList<>();

			if (message != null) {
				System.out.println("Message: " + message);
				ObjectMapper mapper = new ObjectMapper();
				err = Arrays.asList(mapper.readValue(message, ErrorResponse[].class));
			}
			return err;
		} catch (Exception ex) {
			throw new CustomException("Exception Message: " + ex.getMessage());
		}
	}

	public String retailBillsIntegrationListToString(List<RetailBillIntegrations> retailBillsIntegrationsList,
			String emailHeader) {
		String header = emailHeader;
		StringBuilder buf = new StringBuilder();
		buf.append("\t\r\n").append(header).append("\t\r\n");

		for (RetailBillIntegrations retailBillsIntegration : retailBillsIntegrationsList) {
//			RetailBills retailBill = retailBillsRepository.getOne(retailBillsIntegration.getSourceRefId());
			Optional<RetailBills> retailBill = retailBillsRepository.findById(retailBillsIntegration.getSourceRefId());
			if (retailBill.isPresent()) {
				RetailBills bill = retailBill.get();
				String tableHeader = "------------------- Bill Number : " + bill.getBillNum() + " -------------------";
				buf.append("\t\r\n").append(tableHeader).append("\t\r\n");

				buf.append("Customer Name : ").append(bill.getBillToCustName()).append("\t\r\n")
						// .append("Customer MSA Code :
						// ").append(retailBill.getMsaCode()).append("\t\r\n")
						.append("Error Message : ").append(retailBillsIntegration.getMessage()).append("\t\r\n")
						.append("\t\r\n");
			}
		}
		buf.append("\t\r\n");

		return buf.toString();
	}

	/**
	 * Checks if the value is null or empty.
	 *
	 * @param value
	 * @return boolean
	 */
	public static boolean isNullOrEmpty(String value) {

		// LOGGER.info("ContractUtils ----- isNullOrEmpty");

		boolean isNullOrEmptyFlag = false;
		if (null == value) {
			isNullOrEmptyFlag = true;
		} else if ("".equals(value.trim())) {
			isNullOrEmptyFlag = true;
		} else if (value.trim().length() == 0) {
			isNullOrEmptyFlag = true;
		}

		return isNullOrEmptyFlag;
	}
	
	/**
	 * Method to Untag Retail Bill Number Post API
	 * 
	 * @param untagRetailBillingWaybillRequest
	 * @return
	 */
	public String untagWaybillRetailBillNumber(List<RetailWaybillDTO> waybillList, String billNumber) throws CustomException {

		logger.info("RetailBatch:: createRetailBillforSSP:: untagWaybillRetailBillNumber: billNumber to Untag Waybill for Retail Bills: {} ",
				billNumber);
		
		List<Long> waybillIdList = new ArrayList<>();
		
		for (RetailWaybillDTO wb : waybillList) {
			
			logger.info("RetailBatch:: createRetailBillforSSP:: untagWaybillRetailBillNumber: BillNumber: {} -- WaybillId: {} -- WaybillNumber: {} ", billNumber,
					wb.getWaybillId(), wb.getWaybillNumber());
			waybillIdList.add(wb.getWaybillId());
			
		}

		logger.info("RetailBatch:: createRetailBillforSSP:: untagWaybillRetailBillNumber: BillNumber: {} -- WaybillIdList Size: {}", billNumber, waybillIdList.size());
		
		String respoStatus = "FAILURE";
		String propelToken = propelAuthUti.getPropelToken();
		RestTemplate restTemplate = new RestTemplate();
		String url = retailWaybillApiVal + "/v1/wbdetails/retail/untagwaybill";

		UntagRetailBillWaybillRequest untagRetailBillRequest = new UntagRetailBillWaybillRequest();
		untagRetailBillRequest.setWaybillIdList(waybillIdList);
		untagRetailBillRequest.setBillNumber(billNumber);

		HttpEntity<UntagRetailBillWaybillRequest> requestEntity = new HttpEntity<>(untagRetailBillRequest,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		ResponseEntity<DeleteRetailBillingWaybillResponse> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity,
					DeleteRetailBillingWaybillResponse.class);
			if (responseEntity.getBody() != null) {
				logger.info("RetailBatch:: createRetailBillforSSP:: untagWaybillRetailBillNumber -- Untag Retail Bill Response Message: {} -- BillNumber: {} ",
						responseEntity.getBody().getMessage(), billNumber);

				if (responseEntity.getBody().getStatus().equalsIgnoreCase("SUCCESS")) {
					respoStatus = "SUCCESS";
				} else {
					respoStatus = "FAILURE";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("RetailBatch:: createRetailBillforSSP:: untagWaybillRetailBillNumber -- Untag RetailBill Number: {} -- Exception: {} ", billNumber, e.getMessage());

		}
		return respoStatus;

	}
	
	/**
	 * Method to SSP initial Bill Id Post
	 * 
	 * @param newbill
	 * @param wbList
	 * @throws CustomException
	 */
	public BasicApiResponseDTO initiatePostSspBillId(RetailBills newbill, List<RetailWaybillDTO> wbList)
			throws CustomException {
		logger.info("RetailBatch:: initiatePostSspBillId: Bill Number {} -- BillBatchDetailId: {} ", newbill.getBillNum(),
				newbill.getBillBatchDetailId());

		try {
			PostRetailBillRequestDTO postRetailBillRequestDTO = new PostRetailBillRequestDTO();
			postRetailBillRequestDTO.setBatchDetailId(newbill.getBillBatchDetailId());
			postRetailBillRequestDTO.setBatchId(newbill.getRetailBillBatches().getBillBatchId());
			postRetailBillRequestDTO.setBillId(String.valueOf(newbill.getBillId()));
			postRetailBillRequestDTO.setBillNumber(newbill.getBillNum());
			List<Long> wbIds = new ArrayList<>();
			for (RetailWaybillDTO wb : wbList) {
				wbIds.add(wb.getWaybillId());
			}
			postRetailBillRequestDTO.setWaybillIds(wbIds);
			return this.callPostSspRetailBillId(postRetailBillRequestDTO);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("RetailBatch:: initiatePostSspBillId: Bill Number {} -- BillBatchDetailId: {} -- Exception: {} ",
					newbill.getBillNum(), newbill.getBillBatchDetailId(), e.getMessage());

		}
		return null;

	}

	/**
	 * Method to call SSP Retail Bill Id Post API
	 * 
	 * @param postRetailBillRequestDTO
	 * @return
	 * @throws CustomException
	 */
	private BasicApiResponseDTO callPostSspRetailBillId(PostRetailBillRequestDTO postRetailBillRequestDTO)
			throws CustomException {
		String propelToken = propelAuthUti.getPropelToken();
		RestTemplate restTemplate = new RestTemplate();
		String url = retailWaybillApiVal + "/v1/billing/ssp-confirm-batch/post-retail-bill-detail";
		logger.info("RetailBatch:: callPostSspRetailBillId -- Post Bill API {} ", url);

		Gson g = new Gson();
		logger.info("RetailBatch:: callPostSspRetailBillId: BatchDetailId: {} -- Post Bill Request {} ",
				postRetailBillRequestDTO.getBatchDetailId(), g.toJson(postRetailBillRequestDTO));

		HttpEntity<PostRetailBillRequestDTO> requestEntity = new HttpEntity<>(postRetailBillRequestDTO,
				PropelAuthUtil.createPropelBookingHeader(userid, propelToken));
		ResponseEntity<BasicApiResponseDTO> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, BasicApiResponseDTO.class);
			logger.info("RetailBatch:: callPostSspRetailBillId -- Post Bill API Response Status: {} ", responseEntity.getBody().getStatus());
		} catch (HttpClientErrorException e) {
			e.printStackTrace();
			logger.info("RetailBatch:: callPostSspRetailBillId:: BatchDetailId: {} -- HttpClientErrorException: {} ",
					postRetailBillRequestDTO.getBatchDetailId(), e.getMessage());
			throw new CustomException("RetailBatch:: callPostSspRetailBillId -- Exception while post retail Bill :"
					+ e.getLocalizedMessage());
		}
		return responseEntity.getBody();

	}
	
	public Date getB2CBillDate() {
		
		Calendar calender2 = Calendar.getInstance();
		calender2.add(Calendar.MONTH, -1);
        calender2.set(Calendar.DAY_OF_MONTH, calender2.getActualMaximum(Calendar.DAY_OF_MONTH));
		
        return calender2.getTime();
		
	}
	
	public List<WaybillDetailsDTO> getBillSourceDetails(String billInfoDTO)throws CustomException{
		
		WaybilDetailRequestDTO req = new WaybilDetailRequestDTO();
		req.setRetailBillNum(billInfoDTO);

		HttpEntity<WaybilDetailRequestDTO> requestEntity= new HttpEntity<>(req,
				apiUtil.createBillingServiceHeader());
		
		RestTemplate restTemplate = new RestTemplate();
		String url=eBillServiceUrl+ "/reports/v1/retailBill/waybillDetails";
		
		ResponseEntity<List<WaybillDetailsDTO>> responseEntity=null;
		try {
			responseEntity=restTemplate.exchange(url, HttpMethod.POST,requestEntity, new ParameterizedTypeReference<List<WaybillDetailsDTO>>(){});
		
		logger.info("Waybill details list size ---- {}",responseEntity.getBody());
		}
		catch(Exception e){
			e.printStackTrace();
			logger.info("Retail Waybill details ----exception{}  ", e.getMessage());
		}
		return responseEntity.getBody();
	}

	
}
