package com.safexpress.billing.retail.dto;

public class CMDMInvoiceUpdateResponseDTO {
	private Long billId;
	private Long billLineId;
	private String status;
	private String message;
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	public Long getBillLineId() {
		return billLineId;
	}
	public void setBillLineId(Long billLineId) {
		this.billLineId = billLineId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
