package com.safexpress.billing.retail.model;

/******************************************************************
* <h1>CreditDocDeviationHistory</h1>
* This is the entity object created for table - CreditDocDeviationHistory .
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-09-02 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         02-Sep-2020   KPMG      Initial version . 
*******************************************************************/

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "retail_deviation_hist", schema = "bil_retail")
public class RetailDocDeviationHistory extends BaseModel {

	private Long devId;
	private String docType;
	private String docNum;
	private Long custPrcId;
	private String custName;
	private String source;
	private String submsnStatus;
	private Date submsnDt;
	private String submsnPersonName;
	private String submsnContactNum;
	private String submsnContactMail;
	private String submsnNote;
	private String reason;
	private Long existingSubmsnBrId;
	private String existingSubmsnBr;
	private Long existingColBrId;
	private String existingColBr;
	private Long existingAltColBrId;
	private String existingAltColBr;
	private Long updSubmsnBrId;
	private String updSubmsnBr;
	private Long updColBrId;
	private String updColBr;
	private Long updAltBrId;
	private String updAltBr;
	private Date writeOffDate;
	private String remarks;
	private String status;
	private String ver;
	private RetailBills retailBills;
	private Double amount;
	private String event;
	private Long sourceRefId;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "dev_id")
	public Long getDevId() {
		return devId;
	}

	public void setDevId(Long devId) {
		this.devId = devId;
	}

	@Column(name = "doc_type")
	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	@Column(name = "cust_prc_id")
	public Long getCustPrcId() {
		return custPrcId;
	}

	public void setCustPrcId(Long custPrcId) {
		this.custPrcId = custPrcId;
	}

	@Column(name = "cust_name")
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Column(name = "source")
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Column(name = "submsn_status")
	public String getSubmsnStatus() {
		return submsnStatus;
	}

	public void setSubmsnStatus(String submsnStatus) {
		this.submsnStatus = submsnStatus;
	}

	@Column(name = "submsn_dt")
	public Date getSubmsnDt() {
		return submsnDt;
	}

	public void setSubmsnDt(Date submsnDt) {
		this.submsnDt = submsnDt;
	}

	@Column(name = "submsn_person_name")
	public String getSubmsnPersonName() {
		return submsnPersonName;
	}

	public void setSubmsnPersonName(String submsnPersonName) {
		this.submsnPersonName = submsnPersonName;
	}

	@Column(name = "submsn_contact_num")
	public String getSubmsnContactNum() {
		return submsnContactNum;
	}

	public void setSubmsnContactNum(String submsnContactNum) {
		this.submsnContactNum = submsnContactNum;
	}

	@Column(name = "submsn_contact_mail")
	public String getSubmsnContactMail() {
		return submsnContactMail;
	}

	public void setSubmsnContactMail(String submsnContactMail) {
		this.submsnContactMail = submsnContactMail;
	}

	@Column(name = "submsn_note")
	public String getSubmsnNote() {
		return submsnNote;
	}

	public void setSubmsnNote(String submsnNote) {
		this.submsnNote = submsnNote;
	}

	@Column(name = "reason")
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Column(name = "existing_submsn_br_id")
	public Long getExistingSubmsnBrId() {
		return existingSubmsnBrId;
	}

	public void setExistingSubmsnBrId(Long existingSubmsnBrId) {
		this.existingSubmsnBrId = existingSubmsnBrId;
	}

	@Column(name = "existing_submsn_br")
	public String getExistingSubmsnBr() {
		return existingSubmsnBr;
	}

	public void setExistingSubmsnBr(String existingSubmsnBr) {
		this.existingSubmsnBr = existingSubmsnBr;
	}

	@Column(name = "existing_col_br_id")
	public Long getExistingColBrId() {
		return existingColBrId;
	}

	public void setExistingColBrId(Long existingColBrId) {
		this.existingColBrId = existingColBrId;
	}

	@Column(name = "existing_col_br")
	public String getExistingColBr() {
		return existingColBr;
	}

	public void setExistingColBr(String existingColBr) {
		this.existingColBr = existingColBr;
	}

	@Column(name = "existing_alt_br_id")
	public Long getExistingAltColBrId() {
		return existingAltColBrId;
	}

	public void setExistingAltColBrId(Long existingAltColBrId) {
		this.existingAltColBrId = existingAltColBrId;
	}

	@Column(name = "existing_alt_br")
	public String getExistingAltColBr() {
		return existingAltColBr;
	}

	public void setExistingAltColBr(String existingAltColBr) {
		this.existingAltColBr = existingAltColBr;
	}

	@Column(name = "upd_submsn_br_id")
	public Long getUpdSubmsnBrId() {
		return updSubmsnBrId;
	}

	public void setUpdSubmsnBrId(Long updSubmsnBrId) {
		this.updSubmsnBrId = updSubmsnBrId;
	}

	@Column(name = "upd_submsn_br")
	public String getUpdSubmsnBr() {
		return updSubmsnBr;
	}

	public void setUpdSubmsnBr(String updSubmsnBr) {
		this.updSubmsnBr = updSubmsnBr;
	}

	@Column(name = "upd_col_br_id")
	public Long getUpdColBrId() {
		return updColBrId;
	}

	public void setUpdColBrId(Long updColBrId) {
		this.updColBrId = updColBrId;
	}

	@Column(name = "upd_col_br")
	public String getUpdColBr() {
		return updColBr;
	}

	public void setUpdColBr(String updColBr) {
		this.updColBr = updColBr;
	}

	@Column(name = "upd_alt_br_id")
	public Long getUpdAltBrId() {
		return updAltBrId;
	}

	public void setUpdAltBrId(Long updAltBrId) {
		this.updAltBrId = updAltBrId;
	}

	@Column(name = "upd_alt_br")
	public String getUpdAltBr() {
		return updAltBr;
	}

	public void setUpdAltBr(String updAltBr) {
		this.updAltBr = updAltBr;
	}

	@Column(name = "remarks")
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Column(name = "status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ver")
	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	@Column(name = "amount")
	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Column(name = "event")
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	@Column(name = "source_ref_id")
	public Long getSourceRefId() {
		return sourceRefId;
	}

	public void setSourceRefId(Long sourceRefId) {
		this.sourceRefId = sourceRefId;
	}

	@Column(name = "doc_num")
	public String getDocNum() {
		return docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	@Column(name = "write_off_date")
	public Date getWriteOffDate() {
		return writeOffDate;
	}

	public void setWriteOffDate(Date writeOffDate) {
		this.writeOffDate = writeOffDate;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bill_id")
	public RetailBills getRetailBills() {
		return retailBills;
	}

	public void setRetailBills(RetailBills retailBills) {
		this.retailBills = retailBills;
	}
	
	

}
