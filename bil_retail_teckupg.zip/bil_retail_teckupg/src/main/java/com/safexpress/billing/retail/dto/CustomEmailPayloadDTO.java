package com.safexpress.billing.retail.dto;

import java.util.Map;

public class CustomEmailPayloadDTO extends SendEmailPayloadDTO {

	String emailType;
	int errCount;
	Map<String, Object> customTemplateData;

	public String getEmailType() {
		return emailType;
	}

	public Map<String, Object> getCustomTemplateData() {
		return customTemplateData;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public void setCustomTemplateData(Map<String, Object> customTemplateData) {
		this.customTemplateData = customTemplateData;
	}

	public int getErrCount() {
		return errCount;
	}

	public void setErrCount(int errCount) {
		this.errCount = errCount;
	}

}
