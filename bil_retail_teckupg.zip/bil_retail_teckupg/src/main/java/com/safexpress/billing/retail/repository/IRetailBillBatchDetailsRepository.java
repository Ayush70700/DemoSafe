package com.safexpress.billing.retail.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.safexpress.billing.retail.model.RetailBillBatchDetails;

public interface IRetailBillBatchDetailsRepository extends JpaRepository<RetailBillBatchDetails,Long>{
	@Query(value = "SELECT nextval('bil_retail.retail_bills_bill_detail_id_seq')", nativeQuery = true)
	public Long getNextBillBatchDetailId();
}
