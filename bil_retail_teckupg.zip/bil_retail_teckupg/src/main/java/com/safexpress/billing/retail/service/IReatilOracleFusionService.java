package com.safexpress.billing.retail.service;

import java.util.List;

public interface IReatilOracleFusionService {

	/**
	 * To integrate the ALLIED CREDIT write off details to oracle GL.
	 */
	public void fusionRetailWriteOffGlIntg();
	/**
	 * Fusion retail Bill 
	 */
	public void fusionRetailBillGlIntg();
	
	public void fusionRetailBillGlIntegration(List<String> status);
	
	public void fusionRetailWriteOffGlIntegration(List<String> status);

}
