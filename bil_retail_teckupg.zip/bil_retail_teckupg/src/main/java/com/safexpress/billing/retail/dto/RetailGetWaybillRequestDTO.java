package com.safexpress.billing.retail.dto;

import java.util.List;

public class RetailGetWaybillRequestDTO {
	private Long batchDetailId;
	private String batchType;
	private Long billBatchId;
	private String gstFlag;
	private String mode;
	private String prcFlag;
	private String source;
	private String toDeliveryDate;
	private String toPickupDate;
	private List<String> waybills;
	
	public Long getBatchDetailId() {
		return batchDetailId;
	}
	public void setBatchDetailId(Long batchDetailId) {
		this.batchDetailId = batchDetailId;
	}
	public String getBatchType() {
		return batchType;
	}
	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
	public Long getBillBatchId() {
		return billBatchId;
	}
	public void setBillBatchId(Long billBatchId) {
		this.billBatchId = billBatchId;
	}
	public String getGstFlag() {
		return gstFlag;
	}
	public void setGstFlag(String gstFlag) {
		this.gstFlag = gstFlag;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getPrcFlag() {
		return prcFlag;
	}
	public void setPrcFlag(String prcFlag) {
		this.prcFlag = prcFlag;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getToDeliveryDate() {
		return toDeliveryDate;
	}
	public void setToDeliveryDate(String toDeliveryDate) {
		this.toDeliveryDate = toDeliveryDate;
	}
	public String getToPickupDate() {
		return toPickupDate;
	}
	public void setToPickupDate(String toPickupDate) {
		this.toPickupDate = toPickupDate;
	}
	public List<String> getWaybills() {
		return waybills;
	}
	public void setWaybills(List<String> waybills) {
		this.waybills = waybills;
	}
	
}
