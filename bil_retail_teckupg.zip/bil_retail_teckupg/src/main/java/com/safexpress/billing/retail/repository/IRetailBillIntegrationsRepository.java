package com.safexpress.billing.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.safexpress.billing.retail.model.RetailBillIntegrations;

public interface IRetailBillIntegrationsRepository extends JpaRepository<RetailBillIntegrations, Long> {

	@Query("SELECT RBI FROM RetailBillIntegrations RBI WHERE RBI.status <> 'PROCESSED' AND RBI.event=?1 AND RBI.retryCount < ?2")
	List<RetailBillIntegrations> findUnprocessedGLRecords(String retailWriteoffStatus, Integer retryCount);
	
	@Query("SELECT RBI FROM RetailBillIntegrations RBI WHERE RBI.status IN ?1 AND RBI.event=?2 AND RBI.retryCount < ?3")
	List<RetailBillIntegrations> findUnprocessedGLRecordsByStatus(List<String> status, String retailWriteoffStatus, Integer retryCount);

	@Query(value = "SELECT nextval('bil_retail.retail_ora_gl_intg_group_id')", nativeQuery = true)
	Long getNextGroupId();

	@Query("SELECT RBI FROM RetailBillIntegrations RBI WHERE RBI.status ='ERROR' AND RBI.event =?1")
	List<RetailBillIntegrations> findErrorRecords(String retailWriteoffStatus);
	
	@Query(value = "SELECT BI from RetailBillIntegrations BI  WHERE BI.status = ?1")
	List<RetailBillIntegrations> getBillsIntegrationsByStatus(String pStatus);

}
