package com.safexpress.billing.retail.service;

import java.text.ParseException;
import java.util.List;

import com.safexpress.billing.retail.model.LogUpdateRetryCountRequest;
import com.safexpress.billing.retail.model.LogUpdateRetryCountResponse;
import com.safexpress.billing.retail.model.PiBilRetailLogRequest;
import com.safexpress.billing.retail.model.PiBilRetailLogResponse;

public interface PiBilRetailLogService {
	
	List<PiBilRetailLogResponse> getRetailApiLogsInfo(PiBilRetailLogRequest rlr) throws ParseException;

	LogUpdateRetryCountResponse updateLogRetryCount(LogUpdateRetryCountRequest req);

}
