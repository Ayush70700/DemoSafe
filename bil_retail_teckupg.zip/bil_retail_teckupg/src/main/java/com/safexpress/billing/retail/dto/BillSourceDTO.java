package com.safexpress.billing.retail.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class BillSourceDTO {

	private String billNum;
	private String billCtgy;
	private String source;
	private String irnFlag;
	private String message;
	private String irn;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "Asia/Kolkata")
	private Date billdt;
	private String billType;
	private Double baseAmt;
	private Double csgtAmt;
	private Double sgstAmt;
	private Double igstAmt;
	private Double actualOutstandingAmt;
	private String gstNum;
	private String s3DocumentKey;
	private String status;
	private List<WaybillDetailsDTO> waybillDetailsDTO; 
	
	public String getBillNum() {
		return billNum;
	}
	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}
	public String getBillCtgy() {
		return billCtgy;
	}
	public void setBillCtgy(String billCtgy) {
		this.billCtgy = billCtgy;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getIrnFlag() {
		return irnFlag;
	}
	public void setIrnFlag(String irnFlag) {
		this.irnFlag = irnFlag;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getIrn() {
		return irn;
	}
	public void setIrn(String irn) {
		this.irn = irn;
	}
	public Date getBilldt() {
		return billdt;
	}
	public void setBilldt(Date billdt) {
		this.billdt = billdt;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public Double getBaseAmt() {
		return baseAmt;
	}
	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}
	public Double getCsgtAmt() {
		return csgtAmt;
	}
	public void setCsgtAmt(Double csgtAmt) {
		this.csgtAmt = csgtAmt;
	}
	public Double getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public Double getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}
	public Double getActualOutstandingAmt() {
		return actualOutstandingAmt;
	}
	public void setActualOutstandingAmt(Double actualOutstandingAmt) {
		this.actualOutstandingAmt = actualOutstandingAmt;
	}
	public String getGstNum() {
		return gstNum;
	}
	public void setGstNum(String gstNum) {
		this.gstNum = gstNum;
	}
	public String getS3DocumentKey() {
		return s3DocumentKey;
	}
	public void setS3DocumentKey(String s3DocumentKey) {
		this.s3DocumentKey = s3DocumentKey;
	}
	public List<WaybillDetailsDTO> getWaybillDetailsDTO() {
		return waybillDetailsDTO;
	}
	public void setWaybillDetailsDTO(List<WaybillDetailsDTO> waybillDetailsDTO) {
		this.waybillDetailsDTO = waybillDetailsDTO;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
