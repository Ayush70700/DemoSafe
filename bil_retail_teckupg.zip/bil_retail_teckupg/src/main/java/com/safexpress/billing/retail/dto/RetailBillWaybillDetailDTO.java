package com.safexpress.billing.retail.dto;

import java.util.List;

public class RetailBillWaybillDetailDTO {
	
	private String message;
	private String status;
	private List<WaybillDetailsDTO> data;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<WaybillDetailsDTO> getData() {
		return data;
	}
	public void setData(List<WaybillDetailsDTO> data) {
		this.data = data;
	}
	
	
	
}
