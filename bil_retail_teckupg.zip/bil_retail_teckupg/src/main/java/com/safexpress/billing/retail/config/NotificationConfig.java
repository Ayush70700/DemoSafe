package com.safexpress.billing.retail.config;
/******************************************************************
* <h1>NotificationConfig</h1>
* This is the configuration file for notifications<p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class NotificationConfig {

	@Value("${notification.url}")
	private String url;

	@Value("${notification.toRecipients}")
	List<String> toRecipients;

	@Value("${notification.ccRecipients}")
	List<String> ccRecipients;

	@Value("${notification.bccRecipients}")
	List<String> bccRecipients;

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	public String getNotificationUrl() {
		return url;
	}

	public List<String> getToRecipients() {
		return toRecipients;
	}

	public List<String> getCcRecipients() {
		return ccRecipients;
	}

	public List<String> getBccRecipients() {
		return bccRecipients;
	}

}
