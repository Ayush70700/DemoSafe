package com.safexpress.billing.retail.dto;

import java.util.List;

public class SelfServiceResponseDTO {
	private String data;
	private String status;
	private String message;
	private List<ErrorResponseDTO> errors;
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<ErrorResponseDTO> getErrors() {
		return errors;
	}
	public void setErrors(List<ErrorResponseDTO> errors) {
		this.errors = errors;
	}
	
	
}
