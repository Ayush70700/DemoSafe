package com.safexpress.billing.retail.dto;
/******************************************************************
* <h1>SendEmailPayloadDTO</h1>
* DTO for Send Email Payload
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
import java.util.List;

public class SendEmailPayloadDTO {

	List<String> toRecipients;
	String body;
	String subject;
	List<String> ccRecipients;
	List<String> bccRecipients;

	public List<String> getToRecipients() {
		return toRecipients;
	}

	public void setToRecipients(List<String> toRecipients) {
		this.toRecipients = toRecipients;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public List<String> getCcRecipients() {
		return ccRecipients;
	}

	public void setCcRecipients(List<String> ccRecipients) {
		this.ccRecipients = ccRecipients;
	}

	public List<String> getBccRecipients() {
		return bccRecipients;
	}

	public void setBccRecipients(List<String> bccRecipients) {
		this.bccRecipients = bccRecipients;
	}

}
