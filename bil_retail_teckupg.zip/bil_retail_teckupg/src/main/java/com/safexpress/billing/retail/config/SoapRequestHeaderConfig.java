package com.safexpress.billing.retail.config;

import java.io.IOException;

import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpUrlConnection;

import com.safexpress.billing.retail.util.ApiUtil;

/**
 * The Class SoapRequestHeaderConfig.
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-08-05
 */
@Configuration
public class SoapRequestHeaderConfig implements WebServiceMessageCallback {

	/** The soap client config. */
	@Autowired
	private SoapClientConfig soapClientConfig;

	/**
	 * Do with message.
	 *
	 * @param message the message
	 * @throws IOException          Signals that an I/O exception has occurred.
	 * @throws TransformerException the transformer exception
	 */
	@Override
	public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
		TransportContext context = TransportContextHolder.getTransportContext();
		HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
		connection.getConnection().addRequestProperty("Authorization", ApiUtil
				.generateBasicAutenticationHeader(soapClientConfig.getUserName(), soapClientConfig.getUserPassword()));

	}

}
