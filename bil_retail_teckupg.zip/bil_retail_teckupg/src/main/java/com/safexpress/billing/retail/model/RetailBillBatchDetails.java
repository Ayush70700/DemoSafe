package com.safexpress.billing.retail.model;
/**
 * <h1>RetailBillBatchDetails</h1>
 * <P>
 * The RetailBillBatchDetails is entity for retail_bill_batch_details table
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="retail_bill_batch_details", schema = "bil_retail")
public class RetailBillBatchDetails extends BaseModel{
	
	private Long recordId;
	private Long billBatchDetailId;
	private RetailBillBatches retailBillBatches;
	private String prcFlag;
	private String gstFlag;
	private String paidFlag;
	private String sspFlag;
	private Date toPickupDt;
	private Date toDeliveryDt;
	private String status;
	private String message;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="record_id")
	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	@Column(name="bill_batch_detail_id")
	public Long getBillBatchDetailId() {
		return billBatchDetailId;
	}

	public void setBillBatchDetailId(Long billBatchDetailId) {
		this.billBatchDetailId = billBatchDetailId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bill_batch_id")
	public RetailBillBatches getRetailBillBatches() {
		return retailBillBatches;
	}

	public void setRetailBillBatches(RetailBillBatches retailBillBatches) {
		this.retailBillBatches = retailBillBatches;
	}

	@Column(name="prc_flag")
	public String getPrcFlag() {
		return prcFlag;
	}

	public void setPrcFlag(String prcFlag) {
		this.prcFlag = prcFlag;
	}

	@Column(name="gst_flag")
	public String getGstFlag() {
		return gstFlag;
	}

	public void setGstFlag(String gstFlag) {
		this.gstFlag = gstFlag;
	}
	
	@Column(name="paid_flag")
	public String getPaidFlag() {
		return paidFlag;
	}

	public void setPaidFlag(String paidFlag) {
		this.paidFlag = paidFlag;
	}

	@Column(name="ssp_flag")
	public String getSspFlag() {
		return sspFlag;
	}

	public void setSspFlag(String sspFlag) {
		this.sspFlag = sspFlag;
	}

	@Column(name="to_pickup_dt")
	public Date getToPickupDt() {
		return toPickupDt;
	}

	public void setToPickupDt(Date toPickupDt) {
		this.toPickupDt = toPickupDt;
	}

	@Column(name="to_delivery_dt")
	public Date getToDeliveryDt() {
		return toDeliveryDt;
	}

	public void setToDeliveryDt(Date toDeliveryDt) {
		this.toDeliveryDt = toDeliveryDt;
	}

	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	@Column(name="message")
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
