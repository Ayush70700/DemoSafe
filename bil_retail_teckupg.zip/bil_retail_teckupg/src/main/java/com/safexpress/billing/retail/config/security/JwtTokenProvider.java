package com.safexpress.billing.retail.config.security;

/******************************************************************
* <h1>JwtTokenProvider</h1>
* The JwtTokenProvider contains all the  methods required for JWT Token generation and validation.
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-08-27 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         27-Aug-2020   KPMG      Initial version . 
******************************************************************/

import java.util.Base64;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;

@Component
public class JwtTokenProvider {
	@Value("${app.jwtSecret}")
	private String jwtSecret;
	@Value("${app.jwtExpirationInMs}")
    private int jwtExpirationInMs;
	
	/**
	 * This method is to perform base64 encoding of the JWT Secret
	 * @param Nothing
	 * @return Nothing
	 */
	
	@PostConstruct
    protected void init() {
    	jwtSecret = Base64.getEncoder().encodeToString(jwtSecret.getBytes());
    }
	
	
   
	/**
	 * This method is to get the user-name from JWT token
	 * @param token
	 * @return String
	 */
    public String getUsernameFromJWT(String token) {
        return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody().getSubject();
    }
    
     
    /**
	 * This method is to validate the jwt token
	 * @param String
	 * @return boolean
	 */
    public boolean validateToken(String authToken)  {
    Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(authToken);
    return true;
    }
	

}
