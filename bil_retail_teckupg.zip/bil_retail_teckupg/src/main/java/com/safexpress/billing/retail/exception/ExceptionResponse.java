package com.safexpress.billing.retail.exception;
/******************************************************************
* <h1>ExceptionResponse</h1>
* Custom Exception Response.
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
import org.springframework.stereotype.Component;

@Component
public class ExceptionResponse {

	private String errorCode;
    private String errorMessage;
    private String errorDetails;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public ExceptionResponse() {
		super();
	}
	public ExceptionResponse(String errorCode, String errorMessage, String errorDetails) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorDetails = errorDetails;
	}
    
}
