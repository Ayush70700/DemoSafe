package com.safexpress.billing.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.safexpress.billing.retail.model.RetailGLEvents;

public interface IRetailGLEventsRepository extends JpaRepository<RetailGLEvents, Long> {

	@Query("SELECT RGL FROM RetailGLEvents RGL WHERE RGL.eventType = ?1 AND RGL.custType = ?2")
	List<RetailGLEvents> findGLSegments(String retailWriteoffStatus, String billType);

}
