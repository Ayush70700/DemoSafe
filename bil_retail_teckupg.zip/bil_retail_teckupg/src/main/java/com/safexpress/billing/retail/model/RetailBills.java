package com.safexpress.billing.retail.model;
/**
 * <h1>RetailBills</h1>
 * <P>
 * The RetailBills is entity for retail_bills
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name="retail_bills", schema = "bil_retail")
public class RetailBills extends BaseModel{
	
	private Long billId;
	private RetailBillBatches retailBillBatches;
	private Date billDt;
	private Long billBatchDetailId;
	private Long billCtgyId;
	private String billCtgy;
	private Long prcId;
	private String billToCustName;
	private String billToAddr;
	private Long billToAddrId;
	private String billToAddrLine1;
	private String billToAddrLine2;
	private String billToAddrLine3;
	private String billToLocation;
	private String billToPincode;
	private String placeOfSupply;
	private String stateCode;
	private String gstNum;
	private Long consignerId;
	private String blngCycle;
	private Long blngBrId;
	private String billNum;
	private String billPeriod;
	private Date billFromDt;
	private Date billToDt;
	private String billToEmail;
	private String billType;
	private String pymtTerm;
	private Double baseAmt;
	private Long consigneeId;
	private String consigneeName;
	private String prcCode;
	private Long oraclePartyId;	
	private Long oraclePartyCustId;
	private Long oracleCustSiteId;
	private Long sfdcAccId;
	private String state;
	private String consignerName;
	private String blngBr;
	private Long collBrId;
	private String collBr;
	private Long altCollBrId;
	private String altCollBr;
	private Long submsnBrId;
	private String submsnBr;
	private Date lastDevDt;
	private Double outstandingAmt;
	private Double actualOutstandingAmt;
	private Double ttlTaxAmt;
	private Double cgstAmt;
	private Double igstAmt;
	private Double sgstAmt;
	private String status;
	private String message;
	private String oracleTaxRate;
	private String oracleTaxRateCode;
	private Integer emailSentCount;
	private Integer acknowledgeCount;
	private Integer sendingFailedCount;
	private String s3DocumentKey;
	private String irn;
	private String ackNo;
	private String ackDt;
	private String signedQrCode;
	private String irnFlag;
	private String billToCity;
	private String billToState;
	private String billingBrGstNum;
	private String billingBrAddress;
	private String billingBrLocation;
	private String billingBrCity;
	private String billingBrState;
	private String billingBrPincode;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="bill_id")
	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bill_batch_id")
	public RetailBillBatches getRetailBillBatches() {
		return retailBillBatches;
	}

	public void setRetailBillBatches(RetailBillBatches retailBillBatches) {
		this.retailBillBatches = retailBillBatches;
	}
	
	@Column(name = "bill_batch_detail_id")
	public Long getBillBatchDetailId() {
		return billBatchDetailId;
	}

	public void setBillBatchDetailId(Long billBatchDetailId) {
		this.billBatchDetailId = billBatchDetailId;
	}

	
	@Column(name="bill_dt")
	public Date getBillDt() {
		return billDt;
	}
	public void setBillDt(Date billDt) {
		this.billDt = billDt;
	}

	@Column(name="bill_ctgy_id")
	public Long getBillCtgyId() {
		return billCtgyId;
	}

	public void setBillCtgyId(Long billCtgyId) {
		this.billCtgyId = billCtgyId;
	}
	
	@Column(name="bill_ctgy")
	public String getBillCtgy() {
		return billCtgy;
	}

	public void setBillCtgy(String billCtgy) {
		this.billCtgy = billCtgy;
	}
	
	@Column(name="prc_id")
	public Long getPrcId() {
		return prcId;
	}

	public void setPrcId(Long prcId) {
		this.prcId = prcId;
	}
	
	@Column(name="bill_to_cust_name")
	public String getBillToCustName() {
		return billToCustName;
	}

	public void setBillToCustName(String billToCustName) {
		this.billToCustName = billToCustName;
	}
	
	@Column(name="bill_to_addr")
	public String getBillToAddr() {
		return billToAddr;
	}

	public void setBillToAddr(String billToAddr) {
		this.billToAddr = billToAddr;
	}

	@Column(name="bill_to_addr_id")
	public Long getBillToAddrId() {
		return billToAddrId;
	}

	public void setBillToAddrId(Long billToAddrId) {
		this.billToAddrId = billToAddrId;
	}
	
	@Column(name="bill_to_addr_line1")
	public String getBillToAddrLine1() {
		return billToAddrLine1;
	}

	public void setBillToAddrLine1(String billToAddrLine1) {
		this.billToAddrLine1 = billToAddrLine1;
	}

	@Column(name="bill_to_addr_line2")
	public String getBillToAddrLine2() {
		return billToAddrLine2;
	}

	public void setBillToAddrLine2(String billToAddrLine2) {
		this.billToAddrLine2 = billToAddrLine2;
	}

	@Column(name="bill_to_addr_line3")
	public String getBillToAddrLine3() {
		return billToAddrLine3;
	}

	public void setBillToAddrLine3(String billToAddrLine3) {
		this.billToAddrLine3 = billToAddrLine3;
	}

	@Column(name="bill_to_location")
	public String getBillToLocation() {
		return billToLocation;
	}

	public void setBillToLocation(String billToLocation) {
		this.billToLocation = billToLocation;
	}

	
	@Column(name="bill_to_pincode")
	public String getBillToPincode() {
		return billToPincode;
	}

	public void setBillToPincode(String billToPincode) {
		this.billToPincode = billToPincode;
	}

	
	@Column(name="place_of_supply")
	public String getPlaceOfSupply() {
		return placeOfSupply;
	}

	public void setPlaceOfSupply(String placeOfSupply) {
		this.placeOfSupply = placeOfSupply;
	}

	@Column(name="state_code")
	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	
	@Column(name="gst_num")
	public String getGstNum() {
		return gstNum;
	}

	public void setGstNum(String gstNum) {
		this.gstNum = gstNum;
	}

	@Column(name="consigner_id")
	public Long getConsignerId() {
		return consignerId;
	}

	public void setConsignerId(Long consignerId) {
		this.consignerId = consignerId;
	}

	
	@Column(name="blng_cycle")
	public String getBlngCycle() {
		return blngCycle;
	}

	public void setBlngCycle(String blngCycle) {
		this.blngCycle = blngCycle;
	}


	
	@Column(name="bill_num")
	public String getBillNum() {
		return billNum;
	}

	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}

	
	@Column(name="billPeriod")
	public String getBillPeriod() {
		return billPeriod;
	}

	public void setBillPeriod(String billPeriod) {
		this.billPeriod = billPeriod;
	}

	
	@Column(name="bill_from_dt")
	public Date getBillFromDt() {
		return billFromDt;
	}

	public void setBillFromDt(Date billFromDt) {
		this.billFromDt = billFromDt;
	}

	
	@Column(name="bill_to_dt")
	public Date getBillToDt() {
		return billToDt;
	}

	public void setBillToDt(Date billToDt) {
		this.billToDt = billToDt;
	}

	
	@Column(name="bill_type")
	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	
	@Column(name="pymt_term")
	public String getPymtTerm() {
		return pymtTerm;
	}

	public void setPymtTerm(String pymtTerm) {
		this.pymtTerm = pymtTerm;
	}

	
	@Column(name="consignee_id")
	public Long getConsigneeId() {
		return consigneeId;
	}

	public void setConsigneeId(Long consigneeId) {
		this.consigneeId = consigneeId;
	}

	
	@Column(name="consignee_name")
	public String getConsigneeName() {
		return consigneeName;
	}

	public void setConsigneeName(String consigneeName) {
		this.consigneeName = consigneeName;
	}

	
	@Column(name="prc_code")
	public String getPrcCode() {
		return prcCode;
	}

	public void setPrcCode(String prcCode) {
		this.prcCode = prcCode;
	}

	
	@Column(name="oracle_party_id")
	public Long getOraclePartyId() {
		return oraclePartyId;
	}

	public void setOraclePartyId(Long oraclePartyId) {
		this.oraclePartyId = oraclePartyId;
	}

	@Column(name="oracle_party_cust_id")
	public Long getOraclePartyCustId() {
		return oraclePartyCustId;
	}

	public void setOraclePartyCustId(Long oraclePartyCustId) {
		this.oraclePartyCustId = oraclePartyCustId;
	}

	
	@Column(name="oracle_cust_site_id")
	public Long getOracleCustSiteId() {
		return oracleCustSiteId;
	}

	public void setOracleCustSiteId(Long oracleCustSiteId) {
		this.oracleCustSiteId = oracleCustSiteId;
	}

	
	@Column(name="sfdc_acc_id")
	public Long getSfdcAccId() {
		return sfdcAccId;
	}

	public void setSfdcAccId(Long sfdcAccId) {
		this.sfdcAccId = sfdcAccId;
	}

	
	@Column(name="state")
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
	@Column(name="consigner_name")
	public String getConsignerName() {
		return consignerName;
	}

	public void setConsignerName(String consignerName) {
		this.consignerName = consignerName;
	}

	
	@Column(name="blng_br_id")
	public Long getBlngBrId() {
		return blngBrId;
	}

	public void setBlngBrId(Long blngBrId) {
		this.blngBrId = blngBrId;
	}

	
	@Column(name="blng_br")
	public String getBlngBr() {
		return blngBr;
	}

	public void setBlngBr(String blngBr) {
		this.blngBr = blngBr;
	}

	
	@Column(name="coll_br_id")
	public Long getCollBrId() {
		return collBrId;
	}

	public void setCollBrId(Long collBrId) {
		this.collBrId = collBrId;
	}

	
	@Column(name="coll_br")
	public String getCollBr() {
		return collBr;
	}

	public void setCollBr(String collBr) {
		this.collBr = collBr;
	}

	
	@Column(name="alt_coll_br_id")
	public Long getAltCollBrId() {
		return altCollBrId;
	}

	public void setAltCollBrId(Long altCollBrId) {
		this.altCollBrId = altCollBrId;
	}

	
	@Column(name="alt_coll_br")
	public String getAltCollBr() {
		return altCollBr;
	}

	public void setAltCollBr(String altCollBr) {
		this.altCollBr = altCollBr;
	}

	
	@Column(name="submsn_br_id")
	public Long getSubmsnBrId() {
		return submsnBrId;
	}

	public void setSubmsnBrId(Long submsnBrId) {
		this.submsnBrId = submsnBrId;
	}

	
	@Column(name="submsn_br")
	public String getSubmsnBr() {
		return submsnBr;
	}

	public void setSubmsnBr(String submsnBr) {
		this.submsnBr = submsnBr;
	}

	
	@Column(name="last_dev_dt")
	public Date getLastDevDt() {
		return lastDevDt;
	}

	public void setLastDevDt(Date lastDevDt) {
		this.lastDevDt = lastDevDt;
	}

	
	@Column(name="base_amt")
	public Double getBaseAmt() {
		return baseAmt;
	}

	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}

	
	@Column(name="outstanding_amt")
	public Double getOutstandingAmt() {
		return outstandingAmt;
	}

	public void setOutstandingAmt(Double outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}

	
	@Column(name="actual_outstanding_amt")
	public Double getActualOutstandingAmt() {
		return actualOutstandingAmt;
	}

	public void setActualOutstandingAmt(Double actualOutstandingAmt) {
		this.actualOutstandingAmt = actualOutstandingAmt;
	}

	
	@Column(name="ttl_tax_amt")
	public Double getTtlTaxAmt() {
		return ttlTaxAmt;
	}

	public void setTtlTaxAmt(Double ttlTaxAmt) {
		this.ttlTaxAmt = ttlTaxAmt;
	}

	
	@Column(name="cgst_amt")
	public Double getCgstAmt() {
		return cgstAmt;
	}

	public void setCgstAmt(Double cgstAmt) {
		this.cgstAmt = cgstAmt;
	}

	
	@Column(name="igst_amt")
	public Double getIgstAmt() {
		return igstAmt;
	}

	public void setIgstAmt(Double igstAmt) {
		this.igstAmt = igstAmt;
	}

	
	@Column(name="sgst_amt")
	public Double getSgstAmt() {
		return sgstAmt;
	}

	public void setSgstAmt(Double sgstAmt) {
		this.sgstAmt = sgstAmt;
	}

	
	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	@Column(name="message")
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	@Column(name="oracle_tax_rate")
	public String getOracleTaxRate() {
		return oracleTaxRate;
	}

	public void setOracleTaxRate(String oracleTaxRate) {
		this.oracleTaxRate = oracleTaxRate;
	}

	
	@Column(name="oracle_tax_rate_code")
	public String getOracleTaxRateCode() {
		return oracleTaxRateCode;
	}

	public void setOracleTaxRateCode(String oracleTaxRateCode) {
		this.oracleTaxRateCode = oracleTaxRateCode;
	}

	
	@Column(name="bill_to_email")
	public String getBillToEmail() {
		return billToEmail;
	}

	public void setBillToEmail(String billToEmail) {
		this.billToEmail = billToEmail;
	}

	
	@Column(name="email_sent_count")
	public Integer getEmailSentCount() {
		return emailSentCount;
	}

	public void setEmailSentCount(Integer emailSentCount) {
		this.emailSentCount = emailSentCount;
	}

	
	@Column(name="acknowledge_count")
	public Integer getAcknowledgeCount() {
		return acknowledgeCount;
	}

	public void setAcknowledgeCount(Integer acknowledgeCount) {
		this.acknowledgeCount = acknowledgeCount;
	}

	
	@Column(name="sending_failed_count")
	public Integer getSendingFailedCount() {
		return sendingFailedCount;
	}

	public void setSendingFailedCount(Integer sendingFailedCount) {
		this.sendingFailedCount = sendingFailedCount;
	}

	
	@Column(name="s3_document_key")
	public String getS3DocumentKey() {
		return s3DocumentKey;
	}

	public void setS3DocumentKey(String s3DocumentKey) {
		this.s3DocumentKey = s3DocumentKey;
	}

	
	@Column(name="irn")
	public String getIrn() {
		return irn;
	}

	public void setIrn(String irn) {
		this.irn = irn;
	}

	
	@Column(name="ack_no")
	public String getAckNo() {
		return ackNo;
	}

	public void setAckNo(String ackNo) {
		this.ackNo = ackNo;
	}

	
	@Column(name="ack_dt")
	public String getAckDt() {
		return ackDt;
	}

	public void setAckDt(String ackDt) {
		this.ackDt = ackDt;
	}

	
	@Column(name="signed_qr_code")
	public String getSignedQrCode() {
		return signedQrCode;
	}

	public void setSignedQrCode(String signedQrCode) {
		this.signedQrCode = signedQrCode;
	}

	
	@Column(name="irn_flag")
	public String getIrnFlag() {
		return irnFlag;
	}

	public void setIrnFlag(String irnFlag) {
		this.irnFlag = irnFlag;
	}

	@Column(name = "bill_to_city")
	public String getBillToCity() {
		return billToCity;
	}

	public void setBillToCity(String billToCity) {
		this.billToCity = billToCity;
	}
	
	@Column(name = "bill_to_state")
	public String getBillToState() {
		return billToState;
	}

	public void setBillToState(String billToState) {
		this.billToState = billToState;
	}
	
	@Column(name = "blng_br_gst_num")
	public String getBillingBrGstNum() {
		return billingBrGstNum;
	}

	public void setBillingBrGstNum(String billingBrGstNum) {
		this.billingBrGstNum = billingBrGstNum;
	}
	
	@Column(name = "blng_br_addr")
	public String getBillingBrAddress() {
		return billingBrAddress;
	}

	public void setBillingBrAddress(String billingBrAddress) {
		this.billingBrAddress = billingBrAddress;
	}
	
	@Column(name = "blng_br_location")
	public String getBillingBrLocation() {
		return billingBrLocation;
	}

	public void setBillingBrLocation(String billingBrLocation) {
		this.billingBrLocation = billingBrLocation;
	}
	
	@Column(name = "blng_br_city")
	public String getBillingBrCity() {
		return billingBrCity;
	}

	public void setBillingBrCity(String billingBrCity) {
		this.billingBrCity = billingBrCity;
	}

	@Column(name = "blng_br_state")
	public String getBillingBrState() {
		return billingBrState;
	}

	public void setBillingBrState(String billingBrState) {
		this.billingBrState = billingBrState;
	}

	@Column(name = "blng_br_pincode")
	public String getBillingBrPincode() {
		return billingBrPincode;
	}

	public void setBillingBrPincode(String billingBrPincode) {
		this.billingBrPincode = billingBrPincode;
	}
	
}
