package com.safexpress.billing.retail.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BillInformationDTO {

	@JsonProperty
	private List<String> billNum;

	public List<String> getBillNum() {
		return billNum;
	}

	public void setBillNum(List<String> billNum) {
		this.billNum = billNum;
	}


//	public String getBillNum() {
//		return billNum;
//	}
//
//	public void setBillNum(String billNum) {
//		this.billNum = billNum;
//	}
	
}
