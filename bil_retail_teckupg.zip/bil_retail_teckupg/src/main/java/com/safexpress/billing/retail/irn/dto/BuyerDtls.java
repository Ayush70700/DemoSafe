package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BuyerDtls {

	@JsonProperty("Gstin") 
    public String gstin;
    @JsonProperty("LglNm") 
    public String lglNm;
    @JsonProperty("TrdNm") 
    public String trdNm;
    @JsonProperty("Pos") 
    public String pos;
    @JsonProperty("Addr1") 
    public String addr1;
    @JsonProperty("Addr2") 
    public String addr2;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("Addr3")
    public String addr3;
    @JsonProperty("Loc") 
    public String loc;
    @JsonProperty("Pin") 
    public int pin;
    @JsonProperty("Stcd") 
    public String stcd;
    @JsonProperty("Ph") 
    public Object ph;
    @JsonProperty("Em") 
    public Object em;
	public String getGstin() {
		return gstin;
	}
	public String getLglNm() {
		return lglNm;
	}
	public String getTrdNm() {
		return trdNm;
	}
	public String getPos() {
		return pos;
	}
	public String getAddr1() {
		return addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public String getLoc() {
		return loc;
	}
	public int getPin() {
		return pin;
	}
	public String getStcd() {
		return stcd;
	}
	public Object getPh() {
		return ph;
	}
	public Object getEm() {
		return em;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public void setLglNm(String lglNm) {
		this.lglNm = lglNm;
	}
	public void setTrdNm(String trdNm) {
		this.trdNm = trdNm;
	}
	public void setPos(String pos) {
		this.pos = pos;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public void setStcd(String stcd) {
		this.stcd = stcd;
	}
	public void setPh(Object ph) {
		this.ph = ph;
	}
	public void setEm(Object em) {
		this.em = em;
	}
	public String getAddr3() {
		return addr3;
	}
	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}   
    
}
