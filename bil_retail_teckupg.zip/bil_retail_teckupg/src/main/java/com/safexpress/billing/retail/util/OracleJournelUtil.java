package com.safexpress.billing.retail.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.safexpress.billing.retail.config.OracleFusionConfig;
import com.safexpress.billing.retail.config.SoapRequestHeaderConfig;
import com.safexpress.billing.retail.dto.GLInterfaceLine;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.journal.wsdl.AmountType;
import com.safexpress.billing.retail.journal.wsdl.GlInterface;
import com.safexpress.billing.retail.journal.wsdl.GlInterfaceTransHeader;
import com.safexpress.billing.retail.journal.wsdl.ImportJournals;
import com.safexpress.billing.retail.journal.wsdl.ObjectFactory;
import com.safexpress.billing.retail.model.RetailBills;
import com.safexpress.billing.retail.model.RetailGLEvents;
import com.safexpress.billing.retail.repository.IRetailBillIntegrationsRepository;

@Component
public class OracleJournelUtil {

	private static final Logger log = LoggerFactory.getLogger(OracleJournelUtil.class);

	/** The soap request header config. */
	@Autowired
	SoapRequestHeaderConfig soapRequestHeaderConfig;

	@Autowired
	OracleFusionConfig oracleFusionConfig;

	@Value("${cloud.oracle.taxRateCode.cgst}")
	private String oracleCgst;
	@Value("${cloud.oracle.taxRateCode.igst}")
	private String oracleIgst;
	@Value("${cloud.oracle.taxRateCode.sgst}")
	private String oracleSgst;
	
	@Autowired
	IRetailBillIntegrationsRepository iRetailBillIntegrationsRepository;

	/** The web service template. */
	@Autowired
	@Qualifier("webServiceTemplateJournalService")
	WebServiceTemplate webServiceTemplate;

	public void createJournal(String batchName, String batchDescr, List<GLInterfaceLine> lines) throws CustomException {
		log.info("Start: createJournal");
		ObjectFactory objectFactory = new ObjectFactory();
		GlInterfaceTransHeader glHeader = new GlInterfaceTransHeader();
		// create GL Header
		Long ledgerId = new Long(oracleFusionConfig.getOraLedgerId());
		glHeader.setBatchName(objectFactory.createGlInterfaceTransHeaderBatchName(batchName));
		glHeader.setBatchDescription(objectFactory.createGlInterfaceTransHeaderBatchDescription(batchDescr));
		glHeader.setLedgerId(objectFactory.createGlInterfaceTransHeaderLedgerId(ledgerId));
		glHeader.setUserCategoryName(
				objectFactory.createGlInterfaceTransHeaderUserCategoryName(Constants.USER_CATEGORY_NAME));
		glHeader.setUserSourceName(
				objectFactory.createGlInterfaceTransHeaderUserSourceName(Constants.USER_SOURCE_NAME));
		glHeader.setImportDescriptiveFlexField(
				objectFactory.createGlInterfaceTransHeaderImportDescriptiveFlexField("N"));
		log.info("Header Initialization Completed");
		List<GlInterface> interfaceLines = glHeader.getGlInterface();
		Long groupId = iRetailBillIntegrationsRepository.getNextGroupId();
		for (GLInterfaceLine glLine : lines) {
			GlInterface row = new GlInterface();
			row.setLedgerId(ledgerId);
			row.setAccountingDate(covertDateToXmlGregorianCalendar(glLine.getAccountingDate()));
			row.setUserJeSourceName(Constants.USER_JE_SOURCE_NAME);
			row.setUserJeCategoryName(Constants.USER_CATEGORY_NAME);
			row.setBalanceType("A");
			row.setGroupId(groupId);
			row.setSegment1(objectFactory.createGlInterfaceSegment1(glLine.getSegment1()));
			row.setSegment2(objectFactory.createGlInterfaceSegment2(glLine.getSegment2()));
			row.setSegment3(objectFactory.createGlInterfaceSegment3(glLine.getSegment3()));
			row.setSegment4(objectFactory.createGlInterfaceSegment4(glLine.getSegment4()));
			row.setSegment5(objectFactory.createGlInterfaceSegment5(glLine.getSegment5()));
			row.setSegment6(objectFactory.createGlInterfaceSegment6(glLine.getSegment6()));
			row.setSegment7(objectFactory.createGlInterfaceSegment7(glLine.getSegment7()));
			row.setSegment8(objectFactory.createGlInterfaceSegment8(glLine.getSegment8()));
			row.setCurrencyCode(glLine.getCurrencyCode());
			AmountType enteredAmt = objectFactory.createAmountType();
			enteredAmt.setCurrencyCode(glLine.getCurrencyCode());
			if (glLine.getEnteredCrAmount().compareTo(BigDecimal.valueOf(0.00)) != 0) {
				enteredAmt.setValue(glLine.getEnteredCrAmount());
				row.setEnteredCrAmount(objectFactory.createGlInterfaceEnteredCrAmount(enteredAmt));
				row.setAccountedCr(objectFactory.createGlInterfaceAccountedCr(glLine.getAccountedCr()));
			}
			if (glLine.getEnteredDrAmount().compareTo(BigDecimal.valueOf(0.00)) != 0) {
				enteredAmt.setValue(glLine.getEnteredDrAmount());
				row.setEnteredDrAmount(objectFactory.createGlInterfaceEnteredDrAmount(enteredAmt));
				row.setAccountedDr(objectFactory.createGlInterfaceAccountedDr(glLine.getAccountedDr()));
			}
			log.info("LineReference:"+glLine.getReference1()+"<row cr:"+row.getEnteredCrAmount()+ "<RowDr:"+row.getEnteredDrAmount());
			log.info("LineReference:"+glLine.getReference1()+"<row cr:"+row.getAccountedCr()+ "<RowDr:"+row.getAccountedDr());
			row.setReference21(objectFactory.createGlInterfaceReference21(glLine.getReference1()));
			interfaceLines.add(row);
		}
		ImportJournals importJournal = new ImportJournals();
		importJournal.setInterfaceRows(glHeader);
		webServiceTemplate.marshalSendAndReceive(importJournal, soapRequestHeaderConfig);
	}

	/**
	 * @Description To create journal lines for writeoff
	 * @param List<AlliedRetailGLEvents>
	 * @param reference1
	 * @param amount
	 * @param accDate
	 * @return List<GLInterfaceLine>
	 */
	public List<GLInterfaceLine> createJournalLinesforWriteoff(List<RetailGLEvents> glEvents, String reference1, BigDecimal amount,
			Date accDate) {
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		for (RetailGLEvents accData : glEvents) {
			GLInterfaceLine line = new GLInterfaceLine();
			line.setSegment1(accData.getSegment1());
			line.setSegment2(accData.getSegment2());
			line.setSegment3(accData.getSegment3());
			line.setSegment4(accData.getSegment4());
			line.setSegment5(accData.getSegment5());
			line.setSegment6(accData.getSegment6());
			line.setSegment7(accData.getSegment7());
			line.setSegment8(accData.getSegment8());
			if (accData.getAccType().equalsIgnoreCase("CR")) {
				line.setAccountedCr(amount);
				line.setAccountedDr(BigDecimal.valueOf(0.00));
				line.setEnteredCrAmount(amount);
				line.setEnteredDrAmount(BigDecimal.valueOf(0.00));
			} else {
				line.setAccountedCr(BigDecimal.valueOf(0.00));
				line.setAccountedDr(amount);
				line.setEnteredDrAmount(amount);
				line.setEnteredCrAmount(BigDecimal.valueOf(0.00));
			}
			line.setAccountingDate(accDate);
			line.setCurrencyCode(oracleFusionConfig.getOraCurrency());
			line.setReference1(reference1);
			interfaceLines.add(line);
		}
		return interfaceLines;
	}

	/**
	 * @Description To create journal lines
	 * @param List<AlliedRetailGLEvents>
	 * @param reference1
	 * @param amount
	 * @param accDate
	 * @return List<GLInterfaceLine>
	 */
	public List<GLInterfaceLine> createJournalLines(List<RetailGLEvents> glEvents, RetailBills retailBills) {
		List<GLInterfaceLine> interfaceLines = new ArrayList<GLInterfaceLine>();
		for (RetailGLEvents accData : glEvents) {
			log.info("Processing ORACLEGL Bill Number",retailBills.getBillNum());
			if(accData.getEventSubType().equals(Constants.RETAIL_BILL_CREATION)) {
				GLInterfaceLine line = new GLInterfaceLine();
				line.setSegment1(accData.getSegment1());
				line.setSegment2(accData.getSegment2());
				line.setSegment3(accData.getSegment3());
				line.setSegment4(accData.getSegment4());
				line.setSegment5(accData.getSegment5());
				line.setSegment6(accData.getSegment6());
				line.setSegment7(accData.getSegment7());
				line.setSegment8(accData.getSegment8());
				if (accData.getAccType().equalsIgnoreCase("CR")) {
					line.setAccountedCr(BigDecimal.valueOf(retailBills.getBaseAmt()));
					line.setAccountedDr(BigDecimal.valueOf(0.00));
					line.setEnteredCrAmount(BigDecimal.valueOf(retailBills.getBaseAmt()));
					line.setEnteredDrAmount(BigDecimal.valueOf(0.00));
				} else {
					line.setAccountedCr(BigDecimal.valueOf(0.00));
					line.setAccountedDr(BigDecimal.valueOf(retailBills.getActualOutstandingAmt()));
					line.setEnteredDrAmount(BigDecimal.valueOf(retailBills.getActualOutstandingAmt()));
					line.setEnteredCrAmount(BigDecimal.valueOf(0.00));
				}
				line.setAccountingDate(retailBills.getBillDt());
				line.setCurrencyCode(oracleFusionConfig.getOraCurrency());
				line.setReference1(retailBills.getBillNum());
				interfaceLines.add(line);
			}
			else if("IGST".equalsIgnoreCase(accData.getEventSubType()) && oracleIgst.equals(retailBills.getOracleTaxRateCode())){
				GLInterfaceLine line = new GLInterfaceLine();
				line.setSegment1(accData.getSegment1());
				line.setSegment2(accData.getSegment2());
				line.setSegment3(accData.getSegment3());
				line.setSegment4(accData.getSegment4());
				line.setSegment5(accData.getSegment5());
				line.setSegment6(accData.getSegment6());
				line.setSegment7(accData.getSegment7());
				line.setSegment8(accData.getSegment8());
				line.setAccountedCr(BigDecimal.valueOf(retailBills.getIgstAmt()));
				line.setAccountedDr(BigDecimal.valueOf(0.00));
				line.setEnteredCrAmount(BigDecimal.valueOf(retailBills.getIgstAmt()));
				line.setEnteredDrAmount(BigDecimal.valueOf(0.00));
				line.setAccountingDate(retailBills.getBillDt());
				line.setCurrencyCode(oracleFusionConfig.getOraCurrency());
				line.setReference1(retailBills.getBillNum());
				interfaceLines.add(line);
			}
			else if("SGST".equalsIgnoreCase(accData.getEventSubType()) && oracleCgst.equals(retailBills.getOracleTaxRateCode())){
				GLInterfaceLine line = new GLInterfaceLine();
				line.setSegment1(accData.getSegment1());
				line.setSegment2(accData.getSegment2());
				line.setSegment3(accData.getSegment3());
				line.setSegment4(accData.getSegment4());
				line.setSegment5(accData.getSegment5());
				line.setSegment6(accData.getSegment6());
				line.setSegment7(accData.getSegment7());
				line.setSegment8(accData.getSegment8());
				line.setAccountedCr(BigDecimal.valueOf(retailBills.getSgstAmt()));
				line.setAccountedDr(BigDecimal.valueOf(0.00));
				line.setEnteredCrAmount(BigDecimal.valueOf(retailBills.getSgstAmt()));
				line.setEnteredDrAmount(BigDecimal.valueOf(0.00));
				line.setAccountingDate(retailBills.getBillDt());
				line.setCurrencyCode(oracleFusionConfig.getOraCurrency());
				line.setReference1(retailBills.getBillNum());
				interfaceLines.add(line);
			}
			else if("CGST".equalsIgnoreCase(accData.getEventSubType()) && oracleCgst.equals(retailBills.getOracleTaxRateCode())){
				GLInterfaceLine line = new GLInterfaceLine();
				line.setSegment1(accData.getSegment1());
				line.setSegment2(accData.getSegment2());
				line.setSegment3(accData.getSegment3());
				line.setSegment4(accData.getSegment4());
				line.setSegment5(accData.getSegment5());
				line.setSegment6(accData.getSegment6());
				line.setSegment7(accData.getSegment7());
				line.setSegment8(accData.getSegment8());
				line.setAccountedCr(BigDecimal.valueOf(retailBills.getCgstAmt()));
				line.setAccountedDr(BigDecimal.valueOf(0.00));
				line.setEnteredCrAmount(BigDecimal.valueOf(retailBills.getCgstAmt()));
				line.setEnteredDrAmount(BigDecimal.valueOf(0.00));
				line.setAccountingDate(retailBills.getBillDt());
				line.setCurrencyCode(oracleFusionConfig.getOraCurrency());
				line.setReference1(retailBills.getBillNum());
				interfaceLines.add(line);
			}
			
		}
		return interfaceLines;
	}
	/**
	 * This method is to convert util date to XML GregorianCalendar
	 * 
	 * @param Date
	 * @return XMLGregorianCalendar
	 */
	public XMLGregorianCalendar covertDateToXmlGregorianCalendar(Date utilDate) throws CustomException {
		try {
			TimeZone utc = TimeZone.getTimeZone("UTC");
			// convert the document format to yyyy-MM-dd
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			format.setTimeZone(utc);
			utilDate = format.parse(format.format(utilDate));
			GregorianCalendar cal = new GregorianCalendar(utc);
			cal.setTime(utilDate);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new CustomException(
					"covertDateToXmlGregorianCalendar: Error converting util date to Gregorian Cal :" + ex.getMessage(),
					HttpStatus.BAD_REQUEST);
		}

	}
}
