package com.safexpress.billing.retail.irn.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DocDtls {
	
	@JsonProperty("Typ")
	public String typ;
	@JsonProperty("No")
	public String no;
	@JsonProperty("Dt")
	public String dt;
	public String getTyp() {
		return typ;
	}
	public String getNo() {
		return no;
	}
	public String getDt() {
		return dt;
	}
	public void setTyp(String typ) {
		this.typ = typ;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public void setDt(String dt) {
		this.dt = dt;
	}	
	

}
