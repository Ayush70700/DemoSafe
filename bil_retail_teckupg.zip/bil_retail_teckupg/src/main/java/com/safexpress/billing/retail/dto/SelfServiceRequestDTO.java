package com.safexpress.billing.retail.dto;

import java.util.List;

public class SelfServiceRequestDTO {
	private String documentType ;
	private String gstin;
	private String emailId;
	private List<String> documentNums;
	
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public List<String> getDocumentNums() {
		return documentNums;
	}
	public void setDocumentNums(List<String> documentNums) {
		this.documentNums = documentNums;
	}
	
}
