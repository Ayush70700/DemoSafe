package com.safexpress.billing.retail.model;

/******************************************************************
* <h1>CreditBillIntegrations</h1>
* This is the entity object created for table - credit_bill_integrations .
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
*******************************************************************/
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "retail_bill_integrations", schema = "bil_retail")
public class RetailBillIntegrations extends BaseModel {

	private Long integrationId;
	private Long sourceRefId;
	private String event;
	private String source;
	private String dest;
	private String billType;
	private String sourceDocAmt;
	private String destRefId;
	private String status;
	private String message;
	private String ver;
	private Integer retryCount;
	private Long devId;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "integration_id")
	public Long getIntegrationId() {
		return integrationId;
	}

	public void setIntegrationId(Long integrationId) {
		this.integrationId = integrationId;
	}

	@Column(name = "source_ref_id")
	public Long getSourceRefId() {
		return sourceRefId;
	}

	public void setSourceRefId(Long sourceRefId) {
		this.sourceRefId = sourceRefId;
	}

	@Column(name = "event")
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	@Column(name = "source")
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Column(name = "dest")
	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	@Column(name = "bill_type")
	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	@Column(name = "source_doc_amt")
	public String getSourceDocAmt() {
		return sourceDocAmt;
	}

	public void setSourceDocAmt(String sourceDocAmt) {
		this.sourceDocAmt = sourceDocAmt;
	}

	@Column(name = "dest_ref_id")
	public String getDestRefId() {
		return destRefId;
	}

	public void setDestRefId(String destRefId) {
		this.destRefId = destRefId;
	}

	@Column(name = "status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "message")
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Column(name = "ver")
	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}
	
	@Column(name = "retry_count")
	@ColumnDefault("0")
	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	@Column(name = "dev_id")
	public Long getDevId() {
		return devId;
	}

	public void setDevId(Long devId) {
		this.devId = devId;
	}
	
	

}
