package com.safexpress.billing.retail.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RetailBillDetailsDTO {
	private Long billId;
//	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
	private Date billDt;
	private String billCtgy;
	private Long billToCustId;
	private String billToCustName;
	private String billToAddr;
	private String billToAddrLine1;
	private String billToAddrLine2;
	private String billToAddrLine3;
	private String billToLocation;
	private String billToPincode;
	private String gstNum;
	private String billNum;
	private String billType;
	private String baseAmt;
	private String prcId;
	private String prcCode;
	private Long collBrId;
	private String collBr;
	private Long altCollBrId;
	private String altCollBr;
	private Long submsnBrId;
	private String submsnBr;
	private Long blngBrId;
	private String blngBr;
	private String outstandingAmt;
	private String actualoutstandingAmt;
	private String ttlTaxAmt;
	private String cgstAmt;
	private String igstAmt;
	private String sgstAmt;
	private String oracleArTrasactionId;
	private Long oracleTaxRate;
	private String oracleTaxRateCode;
	private Integer emailSentCount;
	private Integer acknowledgeCount;
	private Integer sendingFailedCount;
	private String s3DocumentKey;
	private List<WBDataforCMDMDTO> waybills;
	
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	public Date getBillDt() {
		return billDt;
	}
	public void setBillDt(Date billDt) {
		this.billDt = billDt;
	}
	public String getBillCtgy() {
		return billCtgy;
	}
	public void setBillCtgy(String billCtgy) {
		this.billCtgy = billCtgy;
	}
	public String getBillToCustName() {
		return billToCustName;
	}
	public void setBillToCustName(String billToCustName) {
		this.billToCustName = billToCustName;
	}
	public String getBillToAddr() {
		return billToAddr;
	}
	public void setBillToAddr(String billToAddr) {
		this.billToAddr = billToAddr;
	}
	public String getBillToAddrLine1() {
		return billToAddrLine1;
	}
	public void setBillToAddrLine1(String billToAddrLine1) {
		this.billToAddrLine1 = billToAddrLine1;
	}
	public String getBillToAddrLine2() {
		return billToAddrLine2;
	}
	public void setBillToAddrLine2(String billToAddrLine2) {
		this.billToAddrLine2 = billToAddrLine2;
	}
	public String getBillToAddrLine3() {
		return billToAddrLine3;
	}
	public void setBillToAddrLine3(String billToAddrLine3) {
		this.billToAddrLine3 = billToAddrLine3;
	}
	public String getBillToLocation() {
		return billToLocation;
	}
	public void setBillToLocation(String billToLocation) {
		this.billToLocation = billToLocation;
	}
	public String getBillToPincode() {
		return billToPincode;
	}
	public void setBillToPincode(String billToPincode) {
		this.billToPincode = billToPincode;
	}
	public String getGstNum() {
		return gstNum;
	}
	public void setGstNum(String gstNum) {
		this.gstNum = gstNum;
	}
	public String getBillNum() {
		return billNum;
	}
	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public String getBaseAmt() {
		return baseAmt;
	}
	public void setBaseAmt(String baseAmt) {
		this.baseAmt = baseAmt;
	}
	public String getPrcId() {
		return prcId;
	}
	public void setPrcId(String prcId) {
		this.prcId = prcId;
	}
	public String getPrcCode() {
		return prcCode;
	}
	public void setPrcCode(String prcCode) {
		this.prcCode = prcCode;
	}
	public Long getCollBrId() {
		return collBrId;
	}
	public void setCollBrId(Long collBrId) {
		this.collBrId = collBrId;
	}
	public String getCollBr() {
		return collBr;
	}
	public void setCollBr(String collBr) {
		this.collBr = collBr;
	}
	public Long getAltCollBrId() {
		return altCollBrId;
	}
	public void setAltCollBrId(Long altCollBrId) {
		this.altCollBrId = altCollBrId;
	}
	public String getAltCollBr() {
		return altCollBr;
	}
	public void setAltCollBr(String altCollBr) {
		this.altCollBr = altCollBr;
	}
	public Long getSubmsnBrId() {
		return submsnBrId;
	}
	public void setSubmsnBrId(Long submsnBrId) {
		this.submsnBrId = submsnBrId;
	}
	public String getSubmsnBr() {
		return submsnBr;
	}
	public void setSubmsnBr(String submsnBr) {
		this.submsnBr = submsnBr;
	}
	public Long getBlngBrId() {
		return blngBrId;
	}
	public void setBlngBrId(Long blngBrId) {
		this.blngBrId = blngBrId;
	}
	public String getBlngBr() {
		return blngBr;
	}
	public void setBlngBr(String blngBr) {
		this.blngBr = blngBr;
	}
	public String getOutstandingAmt() {
		return outstandingAmt;
	}
	public void setOutstandingAmt(String outstandingAmt) {
		this.outstandingAmt = outstandingAmt;
	}
	public String getActualoutstandingAmt() {
		return actualoutstandingAmt;
	}
	public void setActualoutstandingAmt(String actualoutstandingAmt) {
		this.actualoutstandingAmt = actualoutstandingAmt;
	}
	public String getTtlTaxAmt() {
		return ttlTaxAmt;
	}
	public void setTtlTaxAmt(String ttlTaxAmt) {
		this.ttlTaxAmt = ttlTaxAmt;
	}
	public String getCgstAmt() {
		return cgstAmt;
	}
	public void setCgstAmt(String cgstAmt) {
		this.cgstAmt = cgstAmt;
	}
	public String getIgstAmt() {
		return igstAmt;
	}
	public void setIgstAmt(String igstAmt) {
		this.igstAmt = igstAmt;
	}
	public String getSgstAmt() {
		return sgstAmt;
	}
	public void setSgstAmt(String sgstAmt) {
		this.sgstAmt = sgstAmt;
	}
	public String getOracleArTrasactionId() {
		return oracleArTrasactionId;
	}
	public void setOracleArTrasactionId(String oracleArTrasactionId) {
		this.oracleArTrasactionId = oracleArTrasactionId;
	}
	public Long getOracleTaxRate() {
		return oracleTaxRate;
	}
	public void setOracleTaxRate(Long oracleTaxRate) {
		this.oracleTaxRate = oracleTaxRate;
	}
	public String getOracleTaxRateCode() {
		return oracleTaxRateCode;
	}
	public void setOracleTaxRateCode(String oracleTaxRateCode) {
		this.oracleTaxRateCode = oracleTaxRateCode;
	}
	public Integer getEmailSentCount() {
		return emailSentCount;
	}
	public void setEmailSentCount(Integer emailSentCount) {
		this.emailSentCount = emailSentCount;
	}
	public Integer getAcknowledgeCount() {
		return acknowledgeCount;
	}
	public void setAcknowledgeCount(Integer acknowledgeCount) {
		this.acknowledgeCount = acknowledgeCount;
	}
	public Integer getSendingFailedCount() {
		return sendingFailedCount;
	}
	public void setSendingFailedCount(Integer sendingFailedCount) {
		this.sendingFailedCount = sendingFailedCount;
	}
	public String getS3DocumentKey() {
		return s3DocumentKey;
	}
	public void setS3DocumentKey(String s3DocumentKey) {
		this.s3DocumentKey = s3DocumentKey;
	}
	public List<WBDataforCMDMDTO> getWaybills() {
		return waybills;
	}
	public void setWaybills(List<WBDataforCMDMDTO> waybills) {
		this.waybills = waybills;
	}
	public Long getBillToCustId() {
		return billToCustId;
	}
	public void setBillToCustId(Long billToCustId) {
		this.billToCustId = billToCustId;
	}
	
	
}
