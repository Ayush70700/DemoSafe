package com.safexpress.billing.retail.dto;

import java.util.Date;

public class EwaybillInvoiceDetail {
	private int bookingReqId;
    private int consolidationNum;
    private int docTransId;
    private int docTypeLookupId;
    private int errorStatus;
    private String ewaybillApiFromGstinNum;
    private String ewaybillApiFromTraderName;
    private String ewaybillApiRejectStatus;
    private String ewaybillApiStatus;
    private String ewaybillApiToGstinNum;
    private String ewaybillApiToTraderName;
    private String ewaybillApiUserGstinNum;
    private Date ewaybillDate;
    private String ewaybillNumber;
    private String ewaybillStatusId;
    private String ewayblApiDlvryPincode;
    private String ewayblApiDlvryPlace;
    private String ewayblApiDlvryStateCode;
    private Date ewayblApiDocDate;
    private String ewayblApiDocNum;
    private int ewayblApiExtendedTime;
    private String ewayblApiGeneralGstinNum;
    private int ewayblApiTotInvoiceVal;
    private Date ewayblApiUpdatedDate;
    private Date extensionDate;
    private Date extnUpdatedDate;
    private int fromPincode;
    private String getStatus;
    private Date getStatusDate;
    private String getStatusError;
    private int id;
    private int invoiceId;
    private int reDocTypeLookupId;
    private String reDocumentNum;
    private int reEwaybillCnsolNum;
    private int taxableAmount;
    private int totalAmount;
    private int validKM;
    private int waybillCessAmount;
    private int waybillCgstAmount;
    private int waybillId;
    private int waybillIgstAmount;
    private int waybillSgstAmount;
	public int getBookingReqId() {
		return bookingReqId;
	}
	public void setBookingReqId(int bookingReqId) {
		this.bookingReqId = bookingReqId;
	}
	public int getConsolidationNum() {
		return consolidationNum;
	}
	public void setConsolidationNum(int consolidationNum) {
		this.consolidationNum = consolidationNum;
	}
	public int getDocTransId() {
		return docTransId;
	}
	public void setDocTransId(int docTransId) {
		this.docTransId = docTransId;
	}
	public int getDocTypeLookupId() {
		return docTypeLookupId;
	}
	public void setDocTypeLookupId(int docTypeLookupId) {
		this.docTypeLookupId = docTypeLookupId;
	}
	public int getErrorStatus() {
		return errorStatus;
	}
	public void setErrorStatus(int errorStatus) {
		this.errorStatus = errorStatus;
	}
	public String getEwaybillApiFromGstinNum() {
		return ewaybillApiFromGstinNum;
	}
	public void setEwaybillApiFromGstinNum(String ewaybillApiFromGstinNum) {
		this.ewaybillApiFromGstinNum = ewaybillApiFromGstinNum;
	}
	public String getEwaybillApiFromTraderName() {
		return ewaybillApiFromTraderName;
	}
	public void setEwaybillApiFromTraderName(String ewaybillApiFromTraderName) {
		this.ewaybillApiFromTraderName = ewaybillApiFromTraderName;
	}
	public String getEwaybillApiRejectStatus() {
		return ewaybillApiRejectStatus;
	}
	public void setEwaybillApiRejectStatus(String ewaybillApiRejectStatus) {
		this.ewaybillApiRejectStatus = ewaybillApiRejectStatus;
	}
	public String getEwaybillApiStatus() {
		return ewaybillApiStatus;
	}
	public void setEwaybillApiStatus(String ewaybillApiStatus) {
		this.ewaybillApiStatus = ewaybillApiStatus;
	}
	public String getEwaybillApiToGstinNum() {
		return ewaybillApiToGstinNum;
	}
	public void setEwaybillApiToGstinNum(String ewaybillApiToGstinNum) {
		this.ewaybillApiToGstinNum = ewaybillApiToGstinNum;
	}
	public String getEwaybillApiToTraderName() {
		return ewaybillApiToTraderName;
	}
	public void setEwaybillApiToTraderName(String ewaybillApiToTraderName) {
		this.ewaybillApiToTraderName = ewaybillApiToTraderName;
	}
	public String getEwaybillApiUserGstinNum() {
		return ewaybillApiUserGstinNum;
	}
	public void setEwaybillApiUserGstinNum(String ewaybillApiUserGstinNum) {
		this.ewaybillApiUserGstinNum = ewaybillApiUserGstinNum;
	}
	public Date getEwaybillDate() {
		return ewaybillDate;
	}
	public void setEwaybillDate(Date ewaybillDate) {
		this.ewaybillDate = ewaybillDate;
	}
	public String getEwaybillNumber() {
		return ewaybillNumber;
	}
	public void setEwaybillNumber(String ewaybillNumber) {
		this.ewaybillNumber = ewaybillNumber;
	}
	public String getEwaybillStatusId() {
		return ewaybillStatusId;
	}
	public void setEwaybillStatusId(String ewaybillStatusId) {
		this.ewaybillStatusId = ewaybillStatusId;
	}
	public String getEwayblApiDlvryPincode() {
		return ewayblApiDlvryPincode;
	}
	public void setEwayblApiDlvryPincode(String ewayblApiDlvryPincode) {
		this.ewayblApiDlvryPincode = ewayblApiDlvryPincode;
	}
	public String getEwayblApiDlvryPlace() {
		return ewayblApiDlvryPlace;
	}
	public void setEwayblApiDlvryPlace(String ewayblApiDlvryPlace) {
		this.ewayblApiDlvryPlace = ewayblApiDlvryPlace;
	}
	public String getEwayblApiDlvryStateCode() {
		return ewayblApiDlvryStateCode;
	}
	public void setEwayblApiDlvryStateCode(String ewayblApiDlvryStateCode) {
		this.ewayblApiDlvryStateCode = ewayblApiDlvryStateCode;
	}
	public Date getEwayblApiDocDate() {
		return ewayblApiDocDate;
	}
	public void setEwayblApiDocDate(Date ewayblApiDocDate) {
		this.ewayblApiDocDate = ewayblApiDocDate;
	}
	public String getEwayblApiDocNum() {
		return ewayblApiDocNum;
	}
	public void setEwayblApiDocNum(String ewayblApiDocNum) {
		this.ewayblApiDocNum = ewayblApiDocNum;
	}
	public int getEwayblApiExtendedTime() {
		return ewayblApiExtendedTime;
	}
	public void setEwayblApiExtendedTime(int ewayblApiExtendedTime) {
		this.ewayblApiExtendedTime = ewayblApiExtendedTime;
	}
	public String getEwayblApiGeneralGstinNum() {
		return ewayblApiGeneralGstinNum;
	}
	public void setEwayblApiGeneralGstinNum(String ewayblApiGeneralGstinNum) {
		this.ewayblApiGeneralGstinNum = ewayblApiGeneralGstinNum;
	}
	public int getEwayblApiTotInvoiceVal() {
		return ewayblApiTotInvoiceVal;
	}
	public void setEwayblApiTotInvoiceVal(int ewayblApiTotInvoiceVal) {
		this.ewayblApiTotInvoiceVal = ewayblApiTotInvoiceVal;
	}
	public Date getEwayblApiUpdatedDate() {
		return ewayblApiUpdatedDate;
	}
	public void setEwayblApiUpdatedDate(Date ewayblApiUpdatedDate) {
		this.ewayblApiUpdatedDate = ewayblApiUpdatedDate;
	}
	public Date getExtensionDate() {
		return extensionDate;
	}
	public void setExtensionDate(Date extensionDate) {
		this.extensionDate = extensionDate;
	}
	public Date getExtnUpdatedDate() {
		return extnUpdatedDate;
	}
	public void setExtnUpdatedDate(Date extnUpdatedDate) {
		this.extnUpdatedDate = extnUpdatedDate;
	}
	public int getFromPincode() {
		return fromPincode;
	}
	public void setFromPincode(int fromPincode) {
		this.fromPincode = fromPincode;
	}
	public String getGetStatus() {
		return getStatus;
	}
	public void setGetStatus(String getStatus) {
		this.getStatus = getStatus;
	}
	public Date getGetStatusDate() {
		return getStatusDate;
	}
	public void setGetStatusDate(Date getStatusDate) {
		this.getStatusDate = getStatusDate;
	}
	public String getGetStatusError() {
		return getStatusError;
	}
	public void setGetStatusError(String getStatusError) {
		this.getStatusError = getStatusError;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}
	public int getReDocTypeLookupId() {
		return reDocTypeLookupId;
	}
	public void setReDocTypeLookupId(int reDocTypeLookupId) {
		this.reDocTypeLookupId = reDocTypeLookupId;
	}
	public String getReDocumentNum() {
		return reDocumentNum;
	}
	public void setReDocumentNum(String reDocumentNum) {
		this.reDocumentNum = reDocumentNum;
	}
	public int getReEwaybillCnsolNum() {
		return reEwaybillCnsolNum;
	}
	public void setReEwaybillCnsolNum(int reEwaybillCnsolNum) {
		this.reEwaybillCnsolNum = reEwaybillCnsolNum;
	}
	public int getTaxableAmount() {
		return taxableAmount;
	}
	public void setTaxableAmount(int taxableAmount) {
		this.taxableAmount = taxableAmount;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	public int getValidKM() {
		return validKM;
	}
	public void setValidKM(int validKM) {
		this.validKM = validKM;
	}
	public int getWaybillCessAmount() {
		return waybillCessAmount;
	}
	public void setWaybillCessAmount(int waybillCessAmount) {
		this.waybillCessAmount = waybillCessAmount;
	}
	public int getWaybillCgstAmount() {
		return waybillCgstAmount;
	}
	public void setWaybillCgstAmount(int waybillCgstAmount) {
		this.waybillCgstAmount = waybillCgstAmount;
	}
	public int getWaybillId() {
		return waybillId;
	}
	public void setWaybillId(int waybillId) {
		this.waybillId = waybillId;
	}
	public int getWaybillIgstAmount() {
		return waybillIgstAmount;
	}
	public void setWaybillIgstAmount(int waybillIgstAmount) {
		this.waybillIgstAmount = waybillIgstAmount;
	}
	public int getWaybillSgstAmount() {
		return waybillSgstAmount;
	}
	public void setWaybillSgstAmount(int waybillSgstAmount) {
		this.waybillSgstAmount = waybillSgstAmount;
	}
}
