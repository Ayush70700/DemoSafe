package com.safexpress.billing.retail.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.safexpress.billing.retail.irn.dto.BuyerDtls;
import com.safexpress.billing.retail.irn.dto.SellerDtls;

public class EInvoiceUpdateRequestDTO {

	@JsonProperty("documentId")
	Long documentId;
	
	@JsonProperty("documentNumber")
	String documentNumber;
	
	@JsonProperty("documentDate")
	Date documentDate;
	
	@JsonProperty("buyerDetails")
	BuyerDtls buyerDetails;
	
	@JsonProperty("sellerDetails")
	SellerDtls sellerDetails;
	
	@JsonProperty("b2C")
	Boolean b2C;
	

	public Boolean getB2C() {
		return b2C;
	}

	public void setB2C(Boolean b2c) {
		b2C = b2c;
	}

	public Long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public BuyerDtls getBuyerDetails() {
		return buyerDetails;
	}

	public void setBuyerDetails(BuyerDtls buyerDetails) {
		this.buyerDetails = buyerDetails;
	}

	public SellerDtls getSellerDetails() {
		return sellerDetails;
	}

	public void setSellerDetails(SellerDtls sellerDetails) {
		this.sellerDetails = sellerDetails;
	}
}
