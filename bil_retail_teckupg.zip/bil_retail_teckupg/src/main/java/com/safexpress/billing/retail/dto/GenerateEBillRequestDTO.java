package com.safexpress.billing.retail.dto;

public class GenerateEBillRequestDTO {

	Long documentId;
	String documentNumber;
	String documentType;
	String outputFormat;
	public Long getDocumentId() {
		return documentId;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public String getDocumentType() {
		return documentType;
	}
	public String getOutputFormat() {
		return outputFormat;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public void setOutputFormat(String outputFormat) {
		this.outputFormat = outputFormat;
	}
	
}
