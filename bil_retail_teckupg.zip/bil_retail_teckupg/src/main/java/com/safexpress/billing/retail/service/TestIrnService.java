package com.safexpress.billing.retail.service;

import java.util.List;

import com.safexpress.billing.retail.dto.TestDTO;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;

public interface TestIrnService {

	List<IrnHeaderDTO> getB2bTestBills(TestDTO tesDTO,String errorFlag);

}
