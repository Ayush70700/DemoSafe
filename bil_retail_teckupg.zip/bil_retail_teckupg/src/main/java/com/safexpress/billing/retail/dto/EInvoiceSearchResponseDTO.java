package com.safexpress.billing.retail.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.safexpress.billing.retail.irn.dto.BuyerDtls;
import com.safexpress.billing.retail.irn.dto.SellerDtls;

public class EInvoiceSearchResponseDTO {
	
	@JsonProperty("documentId")
	Long documentId;
	
	@JsonProperty("documentNumber")
	String documentNumber;
	
	@JsonProperty("documentDate")
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSSZ")
	Date documentDate;
	
	@JsonProperty("parentBillNumber")
	String parentBillNumber;
	
	@JsonProperty("customerName")
	String customerName;
	
	@JsonProperty("customerMsaCode")
	String customerMsaCode;
	
	@JsonProperty("address1")
	String address1;
	
	@JsonProperty("address2")
	String address2;
	
	@JsonProperty("address3")
	String address3;
	
	@JsonProperty("location")
	String location;
	
	@JsonProperty("pincode")
	String pincode;
	
	@JsonProperty("stateCode")
	String stateCode;
	
	@JsonProperty("irnStatus")
	String irnStatus;
	
	@JsonProperty("igst")
	Double igst;
	
	@JsonProperty("cgst")
	Double cgst;
	
	@JsonProperty("sgst")
	Double sgst;
	
	@JsonProperty("errorMessage")
	String errorMessage;
	
	
	@JsonProperty("sellerDetails")
	SellerDtls sellerDetails;
	
	@JsonProperty("buyerDetails")
	BuyerDtls buyerDetails;
	
	@JsonProperty("baseAmount")
	Double baseAmt;
	
	public Double getBaseAmt() {
		return baseAmt;
	}
	public void setBaseAmt(Double baseAmt) {
		this.baseAmt = baseAmt;
	}
	public SellerDtls getSellerDetails() {
		return sellerDetails;
	}
	public void setSellerDetails(SellerDtls sellerDetails) {
		this.sellerDetails = sellerDetails;
	}
	public BuyerDtls getBuyerDetails() {
		return buyerDetails;
	}
	public void setBuyerDetails(BuyerDtls buyerDetails) {
		this.buyerDetails = buyerDetails;
	}
	public Long getDocumentId() {
		return documentId;
	}
	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getParentBillNumber() {
		return parentBillNumber;
	}
	public Date getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}
	public void setParentBillNumber(String parentBillNumber) {
		this.parentBillNumber = parentBillNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMsaCode() {
		return customerMsaCode;
	}
	public void setCustomerMsaCode(String customerMsaCode) {
		this.customerMsaCode = customerMsaCode;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getIrnStatus() {
		return irnStatus;
	}
	public void setIrnStatus(String irnStatus) {
		this.irnStatus = irnStatus;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public Double getIgst() {
		return igst;
	}
	public void setIgst(Double igst) {
		this.igst = igst;
	}
	public Double getCgst() {
		return cgst;
	}
	public void setCgst(Double cgst) {
		this.cgst = cgst;
	}
	public Double getSgst() {
		return sgst;
	}
	public void setSgst(Double sgst) {
		this.sgst = sgst;
	}

}