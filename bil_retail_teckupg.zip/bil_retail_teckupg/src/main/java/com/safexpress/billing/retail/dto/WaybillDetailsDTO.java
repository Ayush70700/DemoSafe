package com.safexpress.billing.retail.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class WaybillDetailsDTO {

	private String wayBillNum;
	private String mopId;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "Asia/Kolkata")
	private Date pickupDate;
	@JsonFormat(pattern="yyyy-MM-dd", timezone = "Asia/Kolkata")
	private Date dlvrtDate;
	public String getWayBillNum() {
		return wayBillNum;
	}
	public void setWayBillNum(String wayBillNum) {
		this.wayBillNum = wayBillNum;
	}
	public String getMopId() {
		return mopId;
	}
	public void setMopId(String mopId) {
		this.mopId = mopId;
	}
	public Date getPickupDate() {
		return pickupDate;
	}
	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}
	public Date getDlvrtDate() {
		return dlvrtDate;
	}
	public void setDlvrtDate(Date dlvrtDate) {
		this.dlvrtDate = dlvrtDate;
	}	
	
}
