package com.safexpress.billing.retail.dto;
import java.util.List;

public class PostRetailBillRequestDTO {
	private Long batchDetailId;
	private Long batchId;
	private String billId;
	private String billNumber;
	private List<Long> waybillIds;
	public Long getBatchDetailId() {
		return batchDetailId;
	}
	public void setBatchDetailId(Long batchDetailId) {
		this.batchDetailId = batchDetailId;
	}
	public Long getBatchId() {
		return batchId;
	}
	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}
	public List<Long> getWaybillIds() {
		return waybillIds;
	}
	public void setWaybillIds(List<Long> waybillIds) {
		this.waybillIds = waybillIds;
	}
	
	
}
