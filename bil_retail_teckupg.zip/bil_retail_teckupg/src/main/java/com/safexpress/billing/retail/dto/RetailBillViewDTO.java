package com.safexpress.billing.retail.dto;

import java.util.List;

public class RetailBillViewDTO {
	private List<WbDataDTO> waybillValResp;

	public List<WbDataDTO> getWaybillValResp() {
		return waybillValResp;
	}

	public void setWaybillValResp(List<WbDataDTO> waybillValResp) {
		this.waybillValResp = waybillValResp;
	}
}
