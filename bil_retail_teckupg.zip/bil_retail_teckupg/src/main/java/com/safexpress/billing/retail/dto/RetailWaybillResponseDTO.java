package com.safexpress.billing.retail.dto;

import java.util.List;

public class RetailWaybillResponseDTO {
	
	Long batchId;
	Long batchDetailId;
	Long waybillsCount;
	List<RetailWaybillDTO> waybills;
	RetailErrorDTO[] error;
	
	public Long getBatchId() {
		return batchId;
	}
	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}
	public Long getBatchDetailId() {
		return batchDetailId;
	}
	public void setBatchDetailId(Long batchDetailId) {
		this.batchDetailId = batchDetailId;
	}
	public Long getWaybillsCount() {
		return waybillsCount;
	}
	public void setWaybillsCount(Long waybillsCount) {
		this.waybillsCount = waybillsCount;
	}
	public List<RetailWaybillDTO> getWaybills() {
		return waybills;
	}
	public void setWaybills(List<RetailWaybillDTO> waybills) {
		this.waybills = waybills;
	}
	public RetailErrorDTO[] getError() {
		return error;
	}
	public void setError(RetailErrorDTO[] error) {
		this.error = error;
	}
	
	
}
