package com.safexpress.billing.retail.config;

import java.util.TimeZone;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

/**
 * 
 * @author hansnath singh
 * Created on : 31/03/2021
 * 
 */
@Configuration
public class MapperConfiguration {
	
	/**
	 * This bean is created for Time zone issue mismatch.
	 * Purpose of this is to set default time zone same as EKS cluster and pod time zone.
	 * Bean name microMapper is added to distinct with other beans. 
	 * @Primary is added to give higher preference.
	 * Not to be changed or removed without concern to the authorized person.
	 * 
	 * @return
	 */
	@Bean("microMapper")
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
        mapper.setTimeZone(TimeZone.getDefault());
        return mapper;
    }
}
