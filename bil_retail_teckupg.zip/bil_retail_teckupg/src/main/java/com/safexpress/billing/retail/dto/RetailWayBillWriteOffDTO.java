package com.safexpress.billing.retail.dto;

import java.util.Date;

public class RetailWayBillWriteOffDTO {

	private Long documentId;
	private String documentNum;
	private String documentType;
	private String writeOffReason;
	private Double writeOffAmt;
	private Date documentDt;
	private Double outStandingAmt;
	private String remarks;
	private String status;
	private String message;

	public Long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public String getDocumentNum() {
		return documentNum;
	}

	public void setDocumentNum(String documentNum) {
		this.documentNum = documentNum;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getWriteOffReason() {
		return writeOffReason;
	}

	public void setWriteOffReason(String writeOffReason) {
		this.writeOffReason = writeOffReason;
	}

	public Double getWriteOffAmt() {
		return writeOffAmt;
	}

	public void setWriteOffAmt(Double writeOffAmt) {
		this.writeOffAmt = writeOffAmt;
	}

	public Date getDocumentDt() {
		return documentDt;
	}

	public void setDocumentDt(Date documentDt) {
		this.documentDt = documentDt;
	}

	public Double getOutStandingAmt() {
		return outStandingAmt;
	}

	public void setOutStandingAmt(Double outStandingAmt) {
		this.outStandingAmt = outStandingAmt;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
