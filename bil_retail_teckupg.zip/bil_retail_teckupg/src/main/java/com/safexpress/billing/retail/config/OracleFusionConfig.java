package com.safexpress.billing.retail.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OracleFusionConfig {

	@Value("${cloud.oracle.currency}")
	private String oraCurrency;

	@Value("${oracle.ledger.id}")
	private String oraLedgerId;

	public String getOraCurrency() {
		return oraCurrency;
	}

	public String getOraLedgerId() {
		return oraLedgerId;
	}

}
