package com.safexpress.billing.retail.dto;

public class RetailWaybillByBillsRespDTO {
	private RetailBillViewDTO data;
	private String status;
	private String message;
	private ErrorResponseDTO errors;
	
	public RetailBillViewDTO getData() {
		return data;
	}
	public void setData(RetailBillViewDTO data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ErrorResponseDTO getErrors() {
		return errors;
	}
	public void setErrors(ErrorResponseDTO errors) {
		this.errors = errors;
	}
	
}
