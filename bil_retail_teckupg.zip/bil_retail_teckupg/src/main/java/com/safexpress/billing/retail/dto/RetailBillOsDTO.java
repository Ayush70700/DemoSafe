package com.safexpress.billing.retail.dto;

/******************************************************************
* <h1>CreditBillOsDTO</h1>
* DTO for Credit Bill Outstanding
* <p>
*
* @author  KPMG
* @version 1.0
* @since   2020-06-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jun-2020   KPMG      Initial version . 
******************************************************************/
public class RetailBillOsDTO {

	private Long receiptId;
	private Long receiptApplnId;
	private Long documentId;
	private String documentNumber;
	private String status;
	private Double appliedFreightAmt;
	private Double tdsAppliedAmount;
	private Double gstTdsAmount;

	public Long getReceiptId() {
		return receiptId;
	}

	public void setReceiptId(Long receiptId) {
		this.receiptId = receiptId;
	}

	public Long getReceiptApplnId() {
		return receiptApplnId;
	}

	public void setReceiptApplnId(Long receiptApplnId) {
		this.receiptApplnId = receiptApplnId;
	}

	public Long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Long documentId) {
		this.documentId = documentId;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Double getAppliedFreightAmt() {
		return appliedFreightAmt;
	}

	public Double getTdsAppliedAmount() {
		return tdsAppliedAmount;
	}

	public Double getGstTdsAmount() {
		return gstTdsAmount;
	}

	public void setAppliedFreightAmt(Double appliedFreightAmt) {
		this.appliedFreightAmt = appliedFreightAmt;
	}

	public void setTdsAppliedAmount(Double tdsAppliedAmount) {
		this.tdsAppliedAmount = tdsAppliedAmount;
	}

	public void setGstTdsAmount(Double gstTdsAmount) {
		this.gstTdsAmount = gstTdsAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
