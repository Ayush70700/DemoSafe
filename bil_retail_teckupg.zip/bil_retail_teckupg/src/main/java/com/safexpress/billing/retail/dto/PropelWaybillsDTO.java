package com.safexpress.billing.retail.dto;

import java.util.Date;
import java.util.List;

public class PropelWaybillsDTO {
	    private int actualWeight;
	    private int bookingBranchId;
	    private int bookingReqId;
	    private int branchMOPLookupId;
	    private int businessTypeLookupId;
	    private int cgstAmount;
	    private int chargeWeight;
	    private int commercialId;
	    private int consigneeId;
	    private int consignorId;
	    private Date createdDate;
	    private int custTypeLookupId;
	    private Date deliveryDate;
	    private int deliveryGatewayBranchId;
	    private int deliveryPackage;
	    private int destPincodeId;
	    private int dodAmount;
	    private int dodDaccFlag;
	    private String dodInFavourOf;
	    private String dodRemarks;
	    private int dodTypeId;
	    private int ewaybillAvailableFlag;
	    private int ewaybillRequirementFlag;
	    private int exZoneLookupId;
	    private int gstAmount;
	    private String gstId;
	    private int gttlAmount;
	    private int hubDeliveryBranchId;
	    private int hubDeliveryFlag;
	    private int igstAmount;
	    private List<PropelInvoiceList> invoiceList;
	    private int lbhUomLookupId;
	    private int lkpBkgPickupTimeslotId;
	    private int lkpChannelId;
	    private int msaCustId;
	    private int ncvFlag;
	    private List<PropelPackageList> packageList;
	    private String payeeName;
	    private int paymentMethodLookupId;
	    private Date pdcDate;
	    private int pickupBranchId;
	    private Date pickupDate;
	    private int pickupStatusLookupId;
	    private int pickupTypeLookupId;
	    private String pkgSaidToContain;
	    private String policyCompanyName;
	    private Date policyExpiryDate;
	    private String policyNumber;
	    private int prcCntrId;
	    private int rateCardId;
	    private int rateCardTypeLookupId;
	    private int safextTypeLookupId;
	    private int serviceOfferingId;
	    private String sfxPrcContractcode;
	    private int sgstAmount;
	    private Date shipmentDate;
	    private int toZoneLookupId;
	    private int totalAmount;
	    private int totalPackageCount;
	    private String userId;
	    private String userType;
	    private int valueDeclarationFlag;
	    private int volumeWeight;
	    private int waybillId;
	    private String waybillNumber;
	    private int waybillSubStatusLookupId;
	    private int wayblCurrStatusLookupId;
	    private int zoneMatrixLookupId;
		public int getActualWeight() {
			return actualWeight;
		}
		public void setActualWeight(int actualWeight) {
			this.actualWeight = actualWeight;
		}
		public int getBookingBranchId() {
			return bookingBranchId;
		}
		public void setBookingBranchId(int bookingBranchId) {
			this.bookingBranchId = bookingBranchId;
		}
		public int getBookingReqId() {
			return bookingReqId;
		}
		public void setBookingReqId(int bookingReqId) {
			this.bookingReqId = bookingReqId;
		}
		public int getBranchMOPLookupId() {
			return branchMOPLookupId;
		}
		public void setBranchMOPLookupId(int branchMOPLookupId) {
			this.branchMOPLookupId = branchMOPLookupId;
		}
		public int getBusinessTypeLookupId() {
			return businessTypeLookupId;
		}
		public void setBusinessTypeLookupId(int businessTypeLookupId) {
			this.businessTypeLookupId = businessTypeLookupId;
		}
		public int getCgstAmount() {
			return cgstAmount;
		}
		public void setCgstAmount(int cgstAmount) {
			this.cgstAmount = cgstAmount;
		}
		public int getChargeWeight() {
			return chargeWeight;
		}
		public void setChargeWeight(int chargeWeight) {
			this.chargeWeight = chargeWeight;
		}
		public int getCommercialId() {
			return commercialId;
		}
		public void setCommercialId(int commercialId) {
			this.commercialId = commercialId;
		}
		public int getConsigneeId() {
			return consigneeId;
		}
		public void setConsigneeId(int consigneeId) {
			this.consigneeId = consigneeId;
		}
		public int getConsignorId() {
			return consignorId;
		}
		public void setConsignorId(int consignorId) {
			this.consignorId = consignorId;
		}
		public Date getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}
		public int getCustTypeLookupId() {
			return custTypeLookupId;
		}
		public void setCustTypeLookupId(int custTypeLookupId) {
			this.custTypeLookupId = custTypeLookupId;
		}
		public Date getDeliveryDate() {
			return deliveryDate;
		}
		public void setDeliveryDate(Date deliveryDate) {
			this.deliveryDate = deliveryDate;
		}
		public int getDeliveryGatewayBranchId() {
			return deliveryGatewayBranchId;
		}
		public void setDeliveryGatewayBranchId(int deliveryGatewayBranchId) {
			this.deliveryGatewayBranchId = deliveryGatewayBranchId;
		}
		public int getDeliveryPackage() {
			return deliveryPackage;
		}
		public void setDeliveryPackage(int deliveryPackage) {
			this.deliveryPackage = deliveryPackage;
		}
		public int getDestPincodeId() {
			return destPincodeId;
		}
		public void setDestPincodeId(int destPincodeId) {
			this.destPincodeId = destPincodeId;
		}
		public int getDodAmount() {
			return dodAmount;
		}
		public void setDodAmount(int dodAmount) {
			this.dodAmount = dodAmount;
		}
		public int getDodDaccFlag() {
			return dodDaccFlag;
		}
		public void setDodDaccFlag(int dodDaccFlag) {
			this.dodDaccFlag = dodDaccFlag;
		}
		public String getDodInFavourOf() {
			return dodInFavourOf;
		}
		public void setDodInFavourOf(String dodInFavourOf) {
			this.dodInFavourOf = dodInFavourOf;
		}
		public String getDodRemarks() {
			return dodRemarks;
		}
		public void setDodRemarks(String dodRemarks) {
			this.dodRemarks = dodRemarks;
		}
		public int getDodTypeId() {
			return dodTypeId;
		}
		public void setDodTypeId(int dodTypeId) {
			this.dodTypeId = dodTypeId;
		}
		public int getEwaybillAvailableFlag() {
			return ewaybillAvailableFlag;
		}
		public void setEwaybillAvailableFlag(int ewaybillAvailableFlag) {
			this.ewaybillAvailableFlag = ewaybillAvailableFlag;
		}
		public int getEwaybillRequirementFlag() {
			return ewaybillRequirementFlag;
		}
		public void setEwaybillRequirementFlag(int ewaybillRequirementFlag) {
			this.ewaybillRequirementFlag = ewaybillRequirementFlag;
		}
		public int getExZoneLookupId() {
			return exZoneLookupId;
		}
		public void setExZoneLookupId(int exZoneLookupId) {
			this.exZoneLookupId = exZoneLookupId;
		}
		public int getGstAmount() {
			return gstAmount;
		}
		public void setGstAmount(int gstAmount) {
			this.gstAmount = gstAmount;
		}
		public String getGstId() {
			return gstId;
		}
		public void setGstId(String gstId) {
			this.gstId = gstId;
		}
		public int getGttlAmount() {
			return gttlAmount;
		}
		public void setGttlAmount(int gttlAmount) {
			this.gttlAmount = gttlAmount;
		}
		public int getHubDeliveryBranchId() {
			return hubDeliveryBranchId;
		}
		public void setHubDeliveryBranchId(int hubDeliveryBranchId) {
			this.hubDeliveryBranchId = hubDeliveryBranchId;
		}
		public int getHubDeliveryFlag() {
			return hubDeliveryFlag;
		}
		public void setHubDeliveryFlag(int hubDeliveryFlag) {
			this.hubDeliveryFlag = hubDeliveryFlag;
		}
		public int getIgstAmount() {
			return igstAmount;
		}
		public void setIgstAmount(int igstAmount) {
			this.igstAmount = igstAmount;
		}
		public List<PropelInvoiceList> getInvoiceList() {
			return invoiceList;
		}
		public void setInvoiceList(List<PropelInvoiceList> invoiceList) {
			this.invoiceList = invoiceList;
		}
		public int getLbhUomLookupId() {
			return lbhUomLookupId;
		}
		public void setLbhUomLookupId(int lbhUomLookupId) {
			this.lbhUomLookupId = lbhUomLookupId;
		}
		public int getLkpBkgPickupTimeslotId() {
			return lkpBkgPickupTimeslotId;
		}
		public void setLkpBkgPickupTimeslotId(int lkpBkgPickupTimeslotId) {
			this.lkpBkgPickupTimeslotId = lkpBkgPickupTimeslotId;
		}
		public int getLkpChannelId() {
			return lkpChannelId;
		}
		public void setLkpChannelId(int lkpChannelId) {
			this.lkpChannelId = lkpChannelId;
		}
		public int getMsaCustId() {
			return msaCustId;
		}
		public void setMsaCustId(int msaCustId) {
			this.msaCustId = msaCustId;
		}
		public int getNcvFlag() {
			return ncvFlag;
		}
		public void setNcvFlag(int ncvFlag) {
			this.ncvFlag = ncvFlag;
		}
		public List<PropelPackageList> getPackageList() {
			return packageList;
		}
		public void setPackageList(List<PropelPackageList> packageList) {
			this.packageList = packageList;
		}
		public String getPayeeName() {
			return payeeName;
		}
		public void setPayeeName(String payeeName) {
			this.payeeName = payeeName;
		}
		public int getPaymentMethodLookupId() {
			return paymentMethodLookupId;
		}
		public void setPaymentMethodLookupId(int paymentMethodLookupId) {
			this.paymentMethodLookupId = paymentMethodLookupId;
		}
		public Date getPdcDate() {
			return pdcDate;
		}
		public void setPdcDate(Date pdcDate) {
			this.pdcDate = pdcDate;
		}
		public int getPickupBranchId() {
			return pickupBranchId;
		}
		public void setPickupBranchId(int pickupBranchId) {
			this.pickupBranchId = pickupBranchId;
		}
		public Date getPickupDate() {
			return pickupDate;
		}
		public void setPickupDate(Date pickupDate) {
			this.pickupDate = pickupDate;
		}
		public int getPickupStatusLookupId() {
			return pickupStatusLookupId;
		}
		public void setPickupStatusLookupId(int pickupStatusLookupId) {
			this.pickupStatusLookupId = pickupStatusLookupId;
		}
		public int getPickupTypeLookupId() {
			return pickupTypeLookupId;
		}
		public void setPickupTypeLookupId(int pickupTypeLookupId) {
			this.pickupTypeLookupId = pickupTypeLookupId;
		}
		public String getPkgSaidToContain() {
			return pkgSaidToContain;
		}
		public void setPkgSaidToContain(String pkgSaidToContain) {
			this.pkgSaidToContain = pkgSaidToContain;
		}
		public String getPolicyCompanyName() {
			return policyCompanyName;
		}
		public void setPolicyCompanyName(String policyCompanyName) {
			this.policyCompanyName = policyCompanyName;
		}
		public Date getPolicyExpiryDate() {
			return policyExpiryDate;
		}
		public void setPolicyExpiryDate(Date policyExpiryDate) {
			this.policyExpiryDate = policyExpiryDate;
		}
		public String getPolicyNumber() {
			return policyNumber;
		}
		public void setPolicyNumber(String policyNumber) {
			this.policyNumber = policyNumber;
		}
		public int getPrcCntrId() {
			return prcCntrId;
		}
		public void setPrcCntrId(int prcCntrId) {
			this.prcCntrId = prcCntrId;
		}
		public int getRateCardId() {
			return rateCardId;
		}
		public void setRateCardId(int rateCardId) {
			this.rateCardId = rateCardId;
		}
		public int getRateCardTypeLookupId() {
			return rateCardTypeLookupId;
		}
		public void setRateCardTypeLookupId(int rateCardTypeLookupId) {
			this.rateCardTypeLookupId = rateCardTypeLookupId;
		}
		public int getSafextTypeLookupId() {
			return safextTypeLookupId;
		}
		public void setSafextTypeLookupId(int safextTypeLookupId) {
			this.safextTypeLookupId = safextTypeLookupId;
		}
		public int getServiceOfferingId() {
			return serviceOfferingId;
		}
		public void setServiceOfferingId(int serviceOfferingId) {
			this.serviceOfferingId = serviceOfferingId;
		}
		public String getSfxPrcContractcode() {
			return sfxPrcContractcode;
		}
		public void setSfxPrcContractcode(String sfxPrcContractcode) {
			this.sfxPrcContractcode = sfxPrcContractcode;
		}
		public int getSgstAmount() {
			return sgstAmount;
		}
		public void setSgstAmount(int sgstAmount) {
			this.sgstAmount = sgstAmount;
		}
		public Date getShipmentDate() {
			return shipmentDate;
		}
		public void setShipmentDate(Date shipmentDate) {
			this.shipmentDate = shipmentDate;
		}
		public int getToZoneLookupId() {
			return toZoneLookupId;
		}
		public void setToZoneLookupId(int toZoneLookupId) {
			this.toZoneLookupId = toZoneLookupId;
		}
		public int getTotalAmount() {
			return totalAmount;
		}
		public void setTotalAmount(int totalAmount) {
			this.totalAmount = totalAmount;
		}
		public int getTotalPackageCount() {
			return totalPackageCount;
		}
		public void setTotalPackageCount(int totalPackageCount) {
			this.totalPackageCount = totalPackageCount;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public String getUserType() {
			return userType;
		}
		public void setUserType(String userType) {
			this.userType = userType;
		}
		public int getValueDeclarationFlag() {
			return valueDeclarationFlag;
		}
		public void setValueDeclarationFlag(int valueDeclarationFlag) {
			this.valueDeclarationFlag = valueDeclarationFlag;
		}
		public int getVolumeWeight() {
			return volumeWeight;
		}
		public void setVolumeWeight(int volumeWeight) {
			this.volumeWeight = volumeWeight;
		}
		public int getWaybillId() {
			return waybillId;
		}
		public void setWaybillId(int waybillId) {
			this.waybillId = waybillId;
		}
		public String getWaybillNumber() {
			return waybillNumber;
		}
		public void setWaybillNumber(String waybillNumber) {
			this.waybillNumber = waybillNumber;
		}
		public int getWaybillSubStatusLookupId() {
			return waybillSubStatusLookupId;
		}
		public void setWaybillSubStatusLookupId(int waybillSubStatusLookupId) {
			this.waybillSubStatusLookupId = waybillSubStatusLookupId;
		}
		public int getWayblCurrStatusLookupId() {
			return wayblCurrStatusLookupId;
		}
		public void setWayblCurrStatusLookupId(int wayblCurrStatusLookupId) {
			this.wayblCurrStatusLookupId = wayblCurrStatusLookupId;
		}
		public int getZoneMatrixLookupId() {
			return zoneMatrixLookupId;
		}
		public void setZoneMatrixLookupId(int zoneMatrixLookupId) {
			this.zoneMatrixLookupId = zoneMatrixLookupId;
		}
}
