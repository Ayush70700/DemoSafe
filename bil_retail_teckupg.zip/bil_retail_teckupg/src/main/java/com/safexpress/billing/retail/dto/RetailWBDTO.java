package com.safexpress.billing.retail.dto;

import java.util.Date;

public class RetailWBDTO {
	Long waybillId;
	String waybillNumber;
	float baseAmount;
	float ttlTaxAmount;
	float igstAmount;
	float cgstAmount;
	float sgstAmount;
	Date delieveryDate;
	Long outstandingAmount;
	Date creationDate;
	
	
	public Long getWaybillId() {
		return waybillId;
	}
	public void setWaybillId(Long waybillId) {
		this.waybillId = waybillId;
	}
	public String getWaybillNumber() {
		return waybillNumber;
	}
	public void setWaybillNumber(String waybillNumber) {
		this.waybillNumber = waybillNumber;
	}
	public float getBaseAmount() {
		return baseAmount;
	}
	public void setBaseAmount(float baseAmount) {
		this.baseAmount = baseAmount;
	}
	public float getTtlTaxAmount() {
		return ttlTaxAmount;
	}
	public void setTtlTaxAmount(float ttlTaxAmount) {
		this.ttlTaxAmount = ttlTaxAmount;
	}
	public float getIgstAmount() {
		return igstAmount;
	}
	public void setIgstAmount(float igstAmount) {
		this.igstAmount = igstAmount;
	}
	public float getCgstAmount() {
		return cgstAmount;
	}
	public void setCgstAmount(float cgstAmount) {
		this.cgstAmount = cgstAmount;
	}
	public float getSgstAmount() {
		return sgstAmount;
	}
	public void setSgstAmount(float sgstAmount) {
		this.sgstAmount = sgstAmount;
	}
	public Date getDelieveryDate() {
		return delieveryDate;
	}
	public void setDelieveryDate(Date delieveryDate) {
		this.delieveryDate = delieveryDate;
	}
	public Long getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(Long outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
}
