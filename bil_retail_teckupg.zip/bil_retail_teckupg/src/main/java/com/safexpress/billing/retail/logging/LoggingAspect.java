package com.safexpress.billing.retail.logging;
/******************************************************************
* LoggingAspect
* Logging using AOP Advices
*
* @author  KPMG
* @version 1.0
* @since   2020-07-22 
* CHANGE HISTORY        :  
   VERSION       DATE        AUTHOR       DESCRIPTION
   -------      --------     --------     ---------------
   1.0         22-Jul-2020   KPMG      Initial version . 
******************************************************************/
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	/**
     * Advice that logs methods before executing a method
     *
     * @param joinPoint join point for advice
     */
    @Before(value="execution(*  com.safexpress.billing.retail.service.RetailServiceImpl.*(..))"
    		+ "|| execution(*  com.safexpress.billing.retail.controller.RetailBillingController.*(..))"
    		+ "|| execution(*  com.safexpress.billing.retail.util..*.*(..))")
    public void logBefore(JoinPoint joinPoint) {
        Logger lgr = getLog(joinPoint);
        lgr.info("Entering {}()",joinPoint.getSignature().getName());
    }
    
    /**
     * Advice that logs methods after executing a method
     *
     * @param joinPoint join point for advice
     * @param result    method result
     */
    @AfterReturning(value="execution(*  com.safexpress.billing.retail.service.RetailServiceImpl.*(..))"
    		+ "|| execution(*  com.safexpress.billing.retail.controller.RetailBillingController.*(..))"
    		+ "|| execution(*  com.safexpress.billing.retail.util..*.*(..))", returning = "result")
    public void logAfter(JoinPoint joinPoint, Object result) {
        Logger lgr = getLog(joinPoint);
        lgr.info("Exiting {}()",joinPoint.getSignature().getName());
    }
    /**
     * Pointcut that matches all repositories, services and Web REST endpoints.
     */
    @Pointcut("within(@org.springframework.stereotype.Repository *)" +
        " || within(@org.springframework.stereotype.Service *)" +
        " || within(@org.springframework.web.bind.annotation.RestController *)")
    public void springBeanPointcut() {
        // Method is empty as this is just a Pointcut, the implementations are in the advices.
    }
 
     /**
     * Pointcut that matches all Spring beans in the application's main packages.
     */
    @Pointcut("within(com.safexpress.billing.retail..*)")
    public void applicationPackagePointcut() {
        // Method is empty as this is just a Pointcut, the implementations are in the advices.
    }
    
    /**
     * Advice that logs methods throwing exceptions.
     *
     * @param joinPoint join point for advice
     * @param e exception
     */
    @AfterThrowing(pointcut = "applicationPackagePointcut() && springBeanPointcut()", throwing = "e")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable e) {
    	Logger lgr = getLog(joinPoint);
    	lgr.info("Exception in {}() with message = {}",joinPoint.getSignature().getName(), e.getMessage() != null ? e.getMessage() : "NULL");
    }
    
    /**
     * To get the logger object
     */
    protected Logger getLog(final JoinPoint joinPoint) {
        final Object target = joinPoint.getTarget();
        if (target != null) {
            return LoggerFactory.getLogger(target.getClass());
        }

        return LoggerFactory.getLogger(getClass());
    }
}
