package com.safexpress.billing.retail.dto;

import java.util.List;

public class BillResponseDTO {

	private String status;
	private String message;
	private List<BillSourceDTO> billRes;
	private List<String> invalidBillNum;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<BillSourceDTO> getBillRes() {
		return billRes;
	}
	public void setBillRes(List<BillSourceDTO> billRes) {
		this.billRes = billRes;
	}
	public List<String> getInvalidBillNum() {
		return invalidBillNum;
	}
	public void setInvalidBillNum(List<String> invalidBillNum) {
		this.invalidBillNum = invalidBillNum;
	}


}
