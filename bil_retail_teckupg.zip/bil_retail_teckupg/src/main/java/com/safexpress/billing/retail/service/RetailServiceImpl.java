package com.safexpress.billing.retail.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
/**
 * <h1>IRetailService</h1>
 * <P>
 * The IRetailService contains all the service methods required for Retail Billing.
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.safexpress.billing.retail.dto.BasicApiResponseDTO;
import com.safexpress.billing.retail.dto.BillAdditionalInfoDTO;
import com.safexpress.billing.retail.dto.BillInformationDTO;
import com.safexpress.billing.retail.dto.BillResponseDTO;
import com.safexpress.billing.retail.dto.BillSourceDTO;
import com.safexpress.billing.retail.dto.BranchDataDto;
import com.safexpress.billing.retail.dto.BranchResponseDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceBulkSearchDTO;
import com.safexpress.billing.retail.dto.EInvoiceSearchResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceUpdateRequestDTO;
import com.safexpress.billing.retail.dto.ErrorDTO;
import com.safexpress.billing.retail.dto.ErrorResponse;
import com.safexpress.billing.retail.dto.ErrorResponseDTO;
import com.safexpress.billing.retail.dto.GenerateEBillRequestDTO;
import com.safexpress.billing.retail.dto.RetailBillDetailsDTO;
import com.safexpress.billing.retail.dto.RetailBillOsDTO;
import com.safexpress.billing.retail.dto.RetailBillViewDTO;
import com.safexpress.billing.retail.dto.RetailBillsDTO;
import com.safexpress.billing.retail.dto.RetailBillsDetailsforReceiptDTO;
import com.safexpress.billing.retail.dto.RetailErrorDTO;
import com.safexpress.billing.retail.dto.RetailWayBillWriteOffDTO;
import com.safexpress.billing.retail.dto.RetailWaybillByBillsRespDTO;
import com.safexpress.billing.retail.dto.RetailWaybillDTO;
import com.safexpress.billing.retail.dto.RetailWaybillResponseDTO;
import com.safexpress.billing.retail.dto.SelfServiceRequestDTO;
import com.safexpress.billing.retail.dto.SelfServiceResponseDTO;
import com.safexpress.billing.retail.dto.WBDataforCMDMDTO;
import com.safexpress.billing.retail.dto.WaybillDetailsDTO;
import com.safexpress.billing.retail.dto.WbDataDTO;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.irn.dto.BuyerDtls;
import com.safexpress.billing.retail.irn.dto.DocDtls;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;
import com.safexpress.billing.retail.irn.dto.ItemList;
import com.safexpress.billing.retail.irn.dto.SellerDtls;
import com.safexpress.billing.retail.irn.dto.TranDtls;
import com.safexpress.billing.retail.irn.dto.ValDtls;
import com.safexpress.billing.retail.model.RetailBillBatchDetails;
import com.safexpress.billing.retail.model.RetailBillBatches;
import com.safexpress.billing.retail.model.RetailBillIntegrations;
import com.safexpress.billing.retail.model.RetailBills;
import com.safexpress.billing.retail.model.RetailDocDeviationHistory;
import com.safexpress.billing.retail.repository.IRetailBillBatchDetailsRepository;
import com.safexpress.billing.retail.repository.IRetailBillBatchesRepository;
import com.safexpress.billing.retail.repository.IRetailBillIntegrationsRepository;
import com.safexpress.billing.retail.repository.IRetailBillsRepository;
import com.safexpress.billing.retail.repository.IRetailDocDeviationHistoryRepository;
import com.safexpress.billing.retail.util.ApiUtil;
import com.safexpress.billing.retail.util.Constants;
import com.safexpress.billing.retail.util.NotificationUtility;
import com.safexpress.billing.retail.util.PropelAuthUtil;
import com.safexpress.billing.retail.util.RetailBillingUtil;

@Service
public class RetailServiceImpl implements IRetailService {

	public static final Logger logger = LoggerFactory.getLogger(RetailServiceImpl.class);

	@Autowired
	private RetailBillingUtil retailBillingUtil;

	@Autowired
	PropelAuthUtil propelAuthUti;

	@Autowired
	ApiUtil apiUtil;

	@Autowired
	private IRetailBillsRepository retailBillsRepository;

	@Autowired
	IReatilOracleFusionService iReatilOracleFusionService;

	@Autowired
	private IRetailBillBatchesRepository retailBillBatchesRepository;

	@Autowired
	private IRetailBillBatchDetailsRepository retailBillBatchDetailsRepository;

	@Autowired
	IRetailDocDeviationHistoryRepository iRetailDocDeviationHistoryRepository;

	@Autowired
	IRetailBillIntegrationsRepository iRetailBillIntegrationsRepository;

	@Autowired
	NotificationUtility notificationUtility;

	@Autowired
	RestTemplate restTemplate;

	@PersistenceContext
	private EntityManager entityManager;

	@Value("${cloud.oracle.taxRateCode.cgst}")
	private String oracleCgst;
	@Value("${cloud.oracle.taxRateCode.igst}")
	private String oracleIgst;
	@Value("${cloud.oracle.taxRateCode.sgst}")
	private String oracleSgst;

	@Value("${cloud.oracle.taxRateVal.cgst}")
	private String oracleCgstVal;
	@Value("${cloud.oracle.taxRateVal.igst}")
	private String oracleIgstVal;
	@Value("${cloud.oracle.taxRateVal.sgst}")
	private String oracleSgstVal;
	@Value("${billing.ebill.api}")
	private String eBillServiceUrl;

	@Value("${einvoice.seller.gstin}")
	private String sellerGstin;
	@Value("${einvoice.seller.legalName}")
	private String sellerLegalName;
	@Value("${einvoice.seller.tradeName}")
	private String sellerTradeName;
	@Value("${einvoice.seller.addr1}")
	private String sellerAddr1;
	@Value("${einvoice.seller.addr2}")
	private String sellerAddr2;
	@Value("${einvoice.seller.addr3}")
	private String sellerAddr3;
	@Value("${einvoice.seller.location}")
	private String sellerLocation;
	@Value("${einvoice.seller.pincode}")
	private Integer sellerPincode;
	@Value("${einvoice.seller.stateCode}")
	private String sellerStateCode;
	@Value("${einvoice.product.desc}")
	private String productDesc;
	@Value("${einvoice.isService}")
	private String productIsService;
	@Value("${einvoice.hsnCode}")
	private String productHsnCode;
	@Value("${einvoice.seller.phone}")
	private String sellerPhone;
	@Value("${einvoice.seller.email}")
	private String sellerEmail;

	@Value("${billing.admin.user}")
	private String billingAdminUser;

	@Value("${ssp.start.time}")
	private String startTime;

	@Value("${ssp.end.time}")
	private String endTime;

	@Value("${ssp.retailb2b.days}")
	private long retailb2bDays;

	/**
	 * method to Initiate B2B Retail Invoice Creation
	 * 
	 * @return Nothing
	 * @param Nothing
	 * @throws URISyntaxException
	 * @throws CustomException
	 */

	@Override
	// @Scheduled(fixedDelay = 12000)
	@Transactional
	public List<RetailBillBatchDetails> initateB2BBatchCreation() {
		logger.info("=== RetailBatch:: RetailServiceImpl:: RetailServiceImpl:: initateB2BBatchCreation ===");
		try {
			RetailBillBatches retailBillBatch = retailBillingUtil
					.createRetailBillBatch(Constants.getRetailBillingSources());
			RetailBillBatches retailBillBatches = retailBillBatchesRepository.save(retailBillBatch);
			logger.info("=== RetailBatch:: RetailServiceImpl:: Batch and Batch Details created: Batch Id: {} ",
					retailBillBatch.getBillBatchId());
			return this.generateB2BBillBatchDetails(retailBillBatches);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("=== RetailBatch:: RetailServiceImpl:: Something wrong here getting exception === {} ",
					e.getMessage());
		}
		return null;

	}

	@Override
	public void fetchWaybillsForBatchDetails(List<RetailBillBatchDetails> rbDetailList)
			throws URISyntaxException, CustomException {
		for (RetailBillBatchDetails rbDetail : rbDetailList) {
			RetailWaybillResponseDTO retWBResp = retailBillingUtil.callGetWaybillsService(
					Constants.RETAIL_BILLING_SRC_FOR_WB, rbDetail.getRetailBillBatches(), rbDetail,
					Collections.emptyList());
			List<String> errMsgs = new ArrayList<>();
			if (retWBResp != null) {
				RetailErrorDTO[] errArr = retWBResp.getError();
				if (errArr.length > 0) {
					for (int i = 0; i < errArr.length; i++) {
						errMsgs.add(errArr[i].getWaybillNumber() + " : " + errArr[i].getErrorMessage());
					}
				} else {
					this.processWaybillResponse(retWBResp, rbDetail, rbDetail.getRetailBillBatches());
				}
			}
		}
	}

	/**
	 * method to Initiate B2C Retail Invoice Creation
	 * 
	 * @return Nothing
	 * @param Nothing
	 * @throws URISyntaxException
	 * @throws CustomException
	 */
	@Override
	public List<RetailBillBatchDetails> initateB2CBatchCreation() throws URISyntaxException, CustomException {
		RetailBillBatches retailBillBatch = retailBillingUtil
				.createRetailBillBatch(Constants.getRetailBillingSources());
		RetailBillBatches retailBillBatches = retailBillBatchesRepository.save(retailBillBatch);
		return this.generateB2CBillBatchDetails(retailBillBatches);

	}

	/**
	 * Method to create bill as request from self service portal
	 * 
	 * @throws CustomException
	 */
	@Override
	public SelfServiceResponseDTO initateSSPBillCreation(SelfServiceRequestDTO sspRequestDto)
			throws URISyntaxException, CustomException {

		SelfServiceResponseDTO ssResp = new SelfServiceResponseDTO();
		if (sspRequestDto != null) {
			String bIllNumber = null;

			boolean isWaybillsValid = retailBillingUtil.vldSSPAPINonAvailTime(startTime, endTime);
			if (isWaybillsValid) {

				RetailBillBatches retailBillBatch = retailBillingUtil
						.createRetailBillBatch(Constants.getRetailSelfServiceSources());
				logger.info("RetailServiceImpl - initateSSPBillCreation - Retail Bill Batch Initiated");
				RetailBillBatches retailBillBatches = retailBillBatchesRepository.save(retailBillBatch);
				logger.info(
						"RetailServiceImpl - initateSSPBillCreation - Retail Bill Batch Data Saved -- BillBatchId -- {}",
						retailBillBatch.getBillBatchId());
				RetailBillBatchDetails rbDetailstoSave = retailBillingUtil
						.generateSSPBillBatchDetails(retailBillBatches);
				logger.info("RetailServiceImpl - initateSSPBillCreation - Retail Bill Batch Details Data Generated");
				RetailBillBatchDetails rbDetails = retailBillBatchDetailsRepository.save(rbDetailstoSave);
				logger.info(
						"RetailServiceImpl - initateSSPBillCreation - Retail Bill Batch Details Data Saved -- BillBatchDetailsId -- {}",
						rbDetails.getBillBatchDetailId());
				RetailWaybillResponseDTO retWBResp = retailBillingUtil.callGetWaybillsService(
						Constants.getRetailSelfServiceSources(), retailBillBatches, rbDetails,
						sspRequestDto.getDocumentNums());
				logger.info("RetailServiceImpl - initateSSPBillCreation - Waybill Integration Service Called");

				for (int i = 0; i < retWBResp.getWaybills().size(); i++) {
					logger.info("RetailServiceImpl - initateSSPBillCreation -- Index: {} -- Waybill: {}", i,
							retWBResp.getWaybills().get(i).getWaybillNumber());
				}

				if (retWBResp != null) {
					RetailErrorDTO[] errArr = retWBResp.getError();
					if (errArr != null) {
						List<String> errList = new ArrayList<>();
						for (int i = 0; i < errArr.length; i++) {
							if (errArr[i].getWaybillNumber() != null) {
								errList.add(errArr[i].getWaybillNumber() + "" + errArr[i].getErrorMessage());
								logger.info(
										"RetailServiceImpl - initateSSPBillCreation - WaybillNo: {} -- ErrorMessage: {}",
										errArr[i].getWaybillNumber(), errArr[i].getErrorMessage());
							}
						}
						if (!errList.isEmpty()) {
							logger.info("RetailServiceImpl - initateSSPBillCreation - Error List Size -- {}",
									errList.size());
							throw new CustomException(errList.toString());
						}
					}

					logger.info("RetailServiceImpl - initateSSPBillCreation - calling processWaybillResponseforSSP");
					bIllNumber = this.processWaybillResponseforSSP(retailBillBatches, rbDetails, retWBResp,
							sspRequestDto.getGstin(), sspRequestDto.getEmailId());
					logger.info("RetailServiceImpl - initateSSPBillCreation -- BillNumber : {}", bIllNumber);

					if (bIllNumber != null) {

						logger.info("RetailBillingController - saveSSPBills - BillNumber {} Successfully Generated",
								bIllNumber);
						ssResp.setData(bIllNumber);
						ssResp.setStatus(Constants.SUCCESS);
						ssResp.setMessage("Bill generated");
					} else {

						logger.info("RetailBillingController - saveSSPBills - Error -- Bill Not Generated");
						List<ErrorResponseDTO> eRespList = new ArrayList<>();
						ErrorResponseDTO eRest = new ErrorResponseDTO();
						ErrorDTO errDto = new ErrorDTO();
						errDto.setCode("ERR-SSP");
						errDto.setDescription("Bill Not Generated");
						List<ErrorDTO> errList = new ArrayList<>();
						errList.add(errDto);
						eRest.setError(errList);
						eRespList.add(eRest);
						ssResp.setErrors(eRespList);
						ssResp.setStatus(Constants.ERROR);
						ssResp.setMessage("Bill not generated");
					}
				}

			} else {
				// service not available

				logger.info(
						"RetailBillingController - saveSSPBills - Error --Service Not available - Bill Not Generated");
				List<ErrorResponseDTO> eRespList = new ArrayList<>();
				ErrorResponseDTO eRest = new ErrorResponseDTO();
				ErrorDTO errDto = new ErrorDTO();
				errDto.setCode("ERR-SSP");
				errDto.setDescription("Bill Not Generated");
				List<ErrorDTO> errList = new ArrayList<>();
				errList.add(errDto);
				eRest.setError(errList);
				eRespList.add(eRest);
				ssResp.setErrors(eRespList);
				ssResp.setStatus("ERROR");
				ssResp.setMessage("This service is not available between : " + startTime + "PM - " + endTime
						+ "PM. Please try after: " + endTime + "PM");
			}
		}

		return ssResp;
	}

	/**
	 * Method to get retail bill Detail Bill Number
	 * 
	 * @throws CustomException
	 */
	@Override
	public List<RetailBillDetailsDTO> getBillDetailsByDocNum(String documentNumber, String documentWise,
			String sameBilingLevel) throws CustomException {

		logger.info("RetailServiceImpl:: getBillDetailsByDocNum -- documentNumber : {}", documentNumber);
		List<RetailBillDetailsDTO> docList = new ArrayList<>();
		String[] docNumsArray = null;
		if (documentNumber != null && documentNumber != "") {
			docNumsArray = documentNumber.split(",");
		}
		List<RetailBills> rbList = new ArrayList<>();
		for (String docNum : docNumsArray) {
			RetailBills rb = this.retailBillsRepository.getBillsByDocNums(docNum);
			if (rb != null) {
				rbList.add(rb);
			}
		}
		for (RetailBills rb : rbList) {
			RetailBillDetailsDTO docResp = new RetailBillDetailsDTO();
			docResp.setBillId(rb.getBillId());
			docResp.setGstNum(rb.getGstNum());
			docResp.setBillCtgy(rb.getBillCtgy());
			String baseAmt = (null != rb.getBaseAmt()) ? rb.getBaseAmt().toString() : "0";
			String outStanding = (null != rb.getOutstandingAmt()) ? rb.getOutstandingAmt().toString() : "0";
			String igst = (null != rb.getIgstAmt()) ? rb.getIgstAmt().toString() : "0";
			String cgst = (null != rb.getCgstAmt()) ? rb.getCgstAmt().toString() : "0";
			String sgst = (null != rb.getSgstAmt()) ? rb.getSgstAmt().toString() : "0";
			String ttltax = (null != rb.getTtlTaxAmt()) ? rb.getTtlTaxAmt().toString() : "0";
			docResp.setBaseAmt(baseAmt);
			docResp.setOutstandingAmt(outStanding);
			docResp.setActualoutstandingAmt(
					rb.getActualOutstandingAmt() == null ? "0" : rb.getActualOutstandingAmt().toString());
			docResp.setIgstAmt(igst);
			docResp.setCgstAmt(cgst);
			docResp.setSgstAmt(sgst);
			docResp.setTtlTaxAmt(ttltax);
			docResp.setBillDt(rb.getBillDt());
			docResp.setBillNum(rb.getBillNum());
			docResp.setBillToAddr(rb.getBillToAddr());
			docResp.setBillToAddrLine1(rb.getBillToAddrLine1());
			docResp.setBillToAddrLine2(rb.getBillToAddrLine2());
			docResp.setBillToAddrLine3(rb.getBillToAddrLine3());
			docResp.setBillToLocation(rb.getBillToLocation());
			docResp.setBillToPincode(rb.getBillToPincode());
			docResp.setBillToCustName(rb.getBillToCustName());
			docResp.setBillType(rb.getBillType());
			if (rb.getPrcId() != null) {
				docResp.setBillToCustId(rb.getPrcId());
			} else if ("PAID".equals(rb.getBillType())) {
				docResp.setBillToCustId(rb.getConsignerId());
			} else {
				docResp.setBillToCustId(rb.getConsigneeId());
			}
			docResp.setBlngBrId(rb.getBlngBrId());
			docResp.setBlngBr(rb.getBlngBr());
			docResp.setSubmsnBrId(rb.getSubmsnBrId());
			docResp.setSubmsnBr(rb.getSubmsnBr());
			docResp.setCollBrId(rb.getCollBrId());
			docResp.setCollBr(rb.getCollBr());
			if (rb.getPrcId() != null) {
				docResp.setPrcId(rb.getPrcId().toString());
			} else {
				docResp.setPrcId(null);
			}
			docResp.setPrcCode(rb.getPrcCode());
			docResp.setAltCollBr(rb.getAltCollBr());
			docResp.setAltCollBrId(rb.getAltCollBrId());
			if (rb.getOracleTaxRate() != null) {
				docResp.setOracleTaxRate(Long.parseLong(rb.getOracleTaxRate()));
			}
			docResp.setOracleTaxRateCode(rb.getOracleTaxRateCode());
			docResp.setEmailSentCount(rb.getEmailSentCount());
			docResp.setAcknowledgeCount(rb.getAcknowledgeCount());
			docResp.setSendingFailedCount(rb.getSendingFailedCount());
			docResp.setS3DocumentKey(rb.getS3DocumentKey());

			List<WBDataforCMDMDTO> waybillsList = new ArrayList<>();
			if ("WAYBILL".equals(documentWise)) {
				String billId = rb.getBillId().toString();
				RetailWaybillByBillsRespDTO wbs = retailBillingUtil.getWayBillsByBillId(billId);
				RetailBillViewDTO wbresp = wbs.getData();
				if (wbresp != null) {
					List<WbDataDTO> wbList = wbresp.getWaybillValResp();
					for (WbDataDTO waybil : wbList) {
						WBDataforCMDMDTO respWb = new WBDataforCMDMDTO();
						respWb.setWaybillId(waybil.getDocumentid());
						respWb.setWaybillNum(waybil.getDocumentNumber());
						respWb.setBillType("WAYBILL");
						respWb.setTtlTaxAmt(waybil.getTtlTaxAmount());
						respWb.setAmount(waybil.getOutstandingAmount());
						respWb.setOutstandingAmount(waybil.getOutstandingAmount());
						respWb.setCgstAmt(waybil.getCgstAmount());
						respWb.setSgstAmt(waybil.getSgstAmount());
						respWb.setIgstAmt(waybil.getIgstAmount());
						waybillsList.add(respWb);
					}
				}
			}
			docResp.setWaybills(waybillsList);
			docList.add(docResp);

		}

		if ("true".equalsIgnoreCase(sameBilingLevel) && !docList.isEmpty()) {
			Map<Long, List<RetailBillDetailsDTO>> groupBillsMap = new HashMap<>();
			groupBillsMap = docList.stream().collect(Collectors.groupingBy(RetailBillDetailsDTO::getBillToCustId));

			if (groupBillsMap.size() > 1) {
				throw new CustomException("Cust ID for all Bills are not same");
			}

			Iterator<Entry<Long, List<RetailBillDetailsDTO>>> hmIterator = groupBillsMap.entrySet().iterator();
			while (hmIterator.hasNext()) {
				Map.Entry<Long, List<RetailBillDetailsDTO>> mapElement = (Entry<Long, List<RetailBillDetailsDTO>>) hmIterator
						.next();
				List<RetailBillDetailsDTO> groupedByBlngLvl = mapElement.getValue();
				Long nullKeyCount = groupedByBlngLvl.stream().filter(item -> item.getOracleTaxRateCode() == null)
						.count();
				Map<String, List<RetailBillDetailsDTO>> groupTaxCodeBillsMap = groupedByBlngLvl.stream()
						.filter(item -> item.getOracleTaxRateCode() != null)
						.collect(Collectors.groupingBy(RetailBillDetailsDTO::getOracleTaxRateCode));
				if (groupBillsMap.size() > 1) {
					logger.info(
							"RetailServiceImpl:: getBillDetailsByDocNum: groupBillsMap: Tax Rate Code for all Bills are not same");
					throw new CustomException("Tax Rate Code for all Bills are not same");
				}
				if (!nullKeyCount.equals(new Long(groupedByBlngLvl.size())) && nullKeyCount > new Long(0)) {
					logger.info(
							"RetailServiceImpl:: getBillDetailsByDocNum: groupedByBlngLvl: Exception : Tax Rate Code for all Bills are not same ");
					throw new CustomException("Tax Rate Code for all Bills are not same");
				}
			}

		}
		return docList;
	}

	/**
	 * Method to update bill outstanding
	 */
	@Override
	public String updateBillOutstanding(List<RetailBillOsDTO> retailBillReq) {
		for (RetailBillOsDTO reqData : retailBillReq) {
			if (reqData.getDocumentId() != null) {
				/**
				 * Below code is commented because of could not initialize proxy error
				 **/
//				RetailBills retailBill = retailBillsRepository.getOne(reqData.getDocumentId());
				RetailBills retailBill = retailBillsRepository.getNewBillsById(reqData.getDocumentId());
				if (retailBillsRepository.findById(reqData.getDocumentId()).isPresent()) {
					double appliedAmt = reqData.getAppliedFreightAmt() + reqData.getTdsAppliedAmount()
							+ reqData.getGstTdsAmount();
					appliedAmt = retailBill.getOutstandingAmt() - appliedAmt;
					retailBill.setOutstandingAmt(appliedAmt);
					retailBill.setCrBy(Constants.getUserName());
					retailBill.setUpdBy(Constants.getUserName());
					retailBillsRepository.save(retailBill);
				}
			}
		}
		return "Outstanding Amount updated successfully";

	}

	@Override
	public List<RetailBillsDetailsforReceiptDTO> getRetailBillDetails(String documentType, String documentNumber,
			Long custId, String fromDate, String toDate, String branchId) throws CustomException {
		List<RetailBillsDetailsforReceiptDTO> retailsBillList = new ArrayList<>();
		List<Object[]> objectArray = retailBillsRepository.getRetailDetails(documentType, documentNumber, fromDate,
				toDate);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for (Object[] obj : objectArray) {
			if (obj[0] != null) {
				String billId = obj[0].toString();
				RetailWaybillByBillsRespDTO wbs = retailBillingUtil.getWayBillsByBillId(billId);
				RetailBillViewDTO wbresp = wbs.getData();
				List<WbDataDTO> wbList = wbresp.getWaybillValResp();
				for (WbDataDTO waybil : wbList) {
					RetailBillsDetailsforReceiptDTO respWb = new RetailBillsDetailsforReceiptDTO();
					respWb.setDocumentType(waybil.getDocumentType());
					respWb.setDocumentNumber(waybil.getDocumentNumber());
					respWb.setCustomerName((String) obj[2]);
					respWb.setDocumentId(waybil.getDocumentid());
					try {
						if ("TO-PAY".equals(waybil.getDocumentType())) {
							respWb.setDocumentDate(format.parse(waybil.getDeliveryDate()));
						} else if ("PAID".equals(waybil.getDocumentType())) {
							respWb.setDocumentDate(format.parse(waybil.getPickupDate()));
						} else {
							respWb.setDocumentDate(format.parse(waybil.getCreatedDate()));
						}
					} catch (ParseException pe) {
						throw new CustomException("Exceoption While converting String to Date");
					}
					respWb.setOutstandingAmount(waybil.getOutstandingAmount());
					respWb.setActualAmount(waybil.getBaseAmount() + waybil.getTtlTaxAmount());
					retailsBillList.add(respWb);
				}

			}
		}
		return retailsBillList;

	}

	/**
	 * Method to get applied bills by document ids
	 */
	@Override
	public List<RetailBillsDetailsforReceiptDTO> getAppliedBills(String documentIds) {
		String[] billIds = documentIds.split(",");
		List<RetailBillsDetailsforReceiptDTO> retailBillList = new ArrayList<>();
		for (String billId : billIds) {
			Optional<RetailBills> retailBill = retailBillsRepository.findById(Long.valueOf(billId));
			if (retailBill.isPresent()) {
				RetailBillsDetailsforReceiptDTO retailBillsDetailsforReceiptDTO = new RetailBillsDetailsforReceiptDTO();
				retailBillsDetailsforReceiptDTO.setDocumentId(retailBill.get().getBillId());
				retailBillsDetailsforReceiptDTO.setDocumentType(retailBill.get().getBillType());
				retailBillsDetailsforReceiptDTO.setCustomerName(retailBill.get().getBillToCustName());
				retailBillsDetailsforReceiptDTO.setDocumentNumber(retailBill.get().getBillNum());
				if (retailBill.get().getActualOutstandingAmt() != null) {
					retailBillsDetailsforReceiptDTO.setActualAmount(retailBill.get().getActualOutstandingAmt());
				}
				if (retailBill.get().getBillDt() != null) {
					retailBillsDetailsforReceiptDTO.setDocumentDate(retailBill.get().getBillDt());
				}
				if (retailBill.get().getOutstandingAmt() != null) {
					retailBillsDetailsforReceiptDTO.setOutstandingAmount(retailBill.get().getOutstandingAmt());
				}
				retailBillList.add(retailBillsDetailsforReceiptDTO);
			}

		}
		return retailBillList;
	}

	/**
	 * method to generate B2B Bill Batch Details
	 * 
	 * @param RetailBillBatches retailBillBatches
	 */
	public List<RetailBillBatchDetails> generateB2BBillBatchDetails(RetailBillBatches retailBillBatches) {
		logger.info("=== RetailServiceImpl:: generateB2BBillBatchDetails:: BillBatchId === {} ",
				retailBillBatches.getBillBatchId());
		List<RetailBillBatchDetails> batchDetailList = new ArrayList<>();
		Date currentDate = new Date();
		LocalDate ldate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		/**
		 * Changes due to Booking DB lock issue -- schedule the retail billing job for
		 * execute every 3 days at night time
		 */
		LocalDate elDate = ldate.minusDays(retailb2bDays);

		Date calculatedDt = java.util.Date.from(elDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		RetailBillBatchDetails retailBillBatchDetails1 = new RetailBillBatchDetails();
		retailBillBatchDetails1.setGstFlag("Y");
		retailBillBatchDetails1.setPaidFlag("Y");
		retailBillBatchDetails1.setPrcFlag("Y");
		retailBillBatchDetails1.setToDeliveryDt(null);
		retailBillBatchDetails1.setToPickupDt(calculatedDt);
		retailBillBatchDetails1.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails1.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails1));

		RetailBillBatchDetails retailBillBatchDetails2 = new RetailBillBatchDetails();
		retailBillBatchDetails2.setGstFlag("Y");
		retailBillBatchDetails2.setPaidFlag("Y");
		retailBillBatchDetails2.setPrcFlag("N");
		retailBillBatchDetails2.setToDeliveryDt(null);
		retailBillBatchDetails2.setToPickupDt(calculatedDt);
		retailBillBatchDetails2.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails2.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails2));

		RetailBillBatchDetails retailBillBatchDetails3 = new RetailBillBatchDetails();
		retailBillBatchDetails3.setGstFlag("Y");
		retailBillBatchDetails3.setPaidFlag("N");
		retailBillBatchDetails3.setPrcFlag("Y");
		retailBillBatchDetails3.setToDeliveryDt(calculatedDt);
		retailBillBatchDetails3.setToPickupDt(null);
		retailBillBatchDetails3.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails3.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails3));

		RetailBillBatchDetails retailBillBatchDetails4 = new RetailBillBatchDetails();
		retailBillBatchDetails4.setGstFlag("Y");
		retailBillBatchDetails4.setPaidFlag("N");
		retailBillBatchDetails4.setPrcFlag("N");
		retailBillBatchDetails4.setToDeliveryDt(calculatedDt);
		retailBillBatchDetails4.setToPickupDt(null);
		retailBillBatchDetails4.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails4.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails4));

		return batchDetailList;

	}

	/**
	 * method to generate B2B Bill Batch Details
	 * 
	 * @param RetailBillBatches retailBillBatches
	 */
	public List<RetailBillBatchDetails> generateB2CBillBatchDetails(RetailBillBatches retailBillBatches) {
		logger.info("=== RetailServiceImpl:: generateB2CBillBatchDetails:: BillBatchId === ");

		List<RetailBillBatchDetails> batchDetailList = new ArrayList<>();
//		Calendar calendar = Calendar.getInstance();
		Date currentDate = new Date();
//		Calendar calendar = Calendar.getInstance();
//		calendar.setTime(currentDate);
//        calendar.add(Calendar.MONTH, -1);
//        int max = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
//        calendar.set(Calendar.DAY_OF_MONTH, max);
//        Date calculatedDt = calendar.getTime();

		LocalDate lDate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		LocalDate elDate = lDate.minusDays(lDate.getDayOfMonth());
		Date calculatedDt = java.util.Date.from(elDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());

		RetailBillBatchDetails retailBillBatchDetails1 = new RetailBillBatchDetails();
		retailBillBatchDetails1.setGstFlag("N");
		retailBillBatchDetails1.setPaidFlag("Y");
		retailBillBatchDetails1.setPrcFlag("Y");
		retailBillBatchDetails1.setToDeliveryDt(null);
		retailBillBatchDetails1.setToPickupDt(calculatedDt);
		retailBillBatchDetails1.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails1.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails1));

		RetailBillBatchDetails retailBillBatchDetails2 = new RetailBillBatchDetails();
		retailBillBatchDetails2.setGstFlag("N");
		retailBillBatchDetails2.setPaidFlag("Y");
		retailBillBatchDetails2.setPrcFlag("N");
		retailBillBatchDetails2.setToDeliveryDt(null);
		retailBillBatchDetails2.setToPickupDt(calculatedDt);
		retailBillBatchDetails2.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails2.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails2));

		RetailBillBatchDetails retailBillBatchDetails3 = new RetailBillBatchDetails();
		retailBillBatchDetails3.setGstFlag("N");
		retailBillBatchDetails3.setPaidFlag("N");
		retailBillBatchDetails3.setPrcFlag("Y");
		retailBillBatchDetails3.setToDeliveryDt(calculatedDt);
		retailBillBatchDetails3.setToPickupDt(null);
		retailBillBatchDetails3.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails3.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails3));

		RetailBillBatchDetails retailBillBatchDetails4 = new RetailBillBatchDetails();
		retailBillBatchDetails4.setGstFlag("N");
		retailBillBatchDetails4.setPaidFlag("N");
		retailBillBatchDetails4.setPrcFlag("N");
		retailBillBatchDetails4.setToDeliveryDt(calculatedDt);
		retailBillBatchDetails4.setToPickupDt(null);
		retailBillBatchDetails4.setRetailBillBatches(retailBillBatches);
		retailBillBatchDetails4.setBillBatchDetailId(retailBillBatchDetailsRepository.getNextBillBatchDetailId());
		batchDetailList.add(retailBillBatchDetailsRepository.save(retailBillBatchDetails4));

		return batchDetailList;
	}

	/**
	 * method to group waybills at paid and to pay level
	 * 
	 * @param groupedGSTWayBillList
	 * @param batchDetail
	 * @param billCatgory
	 * @throws CustomException
	 */
	private void groupPaidToPayLevel(List<RetailWaybillDTO> groupedGSTWayBillList, RetailBillBatchDetails batchDetail,
			RetailBillBatches retailBillBatches, Long batchDetailId, String billCatgory) throws CustomException {
		String paidFlag = batchDetail.getPaidFlag();
		logger.info(
				"=== RetailBatch:: RetailServiceImpl:: groupPaidToPayLevel:: paidFlag === {} -- BillBatchDetailId: {} ",
				paidFlag, batchDetailId);
		logger.info(
				"=== RetailBatch:: RetailServiceImpl:: groupPaidToPayLevel:: billCatgory === {} -- BillBatchDetailId: {} ",
				billCatgory, batchDetailId);
		if ("Y".equals(paidFlag)) {
			Map<Long, List<RetailWaybillDTO>> groupedBBrWayBillMap = retailBillingUtil
					.groupByBookingBr(groupedGSTWayBillList);
			Iterator<Entry<Long, List<RetailWaybillDTO>>> bBrHmIterator = groupedBBrWayBillMap.entrySet().iterator();
			while (bBrHmIterator.hasNext()) {
				Map.Entry<Long, List<RetailWaybillDTO>> bBrMapElement = bBrHmIterator.next();
				List<RetailWaybillDTO> groupedbBrWayBillList = bBrMapElement.getValue();
				if (Constants.getRetailBillB2BCtgy().equals(billCatgory)) {
					Map<Date, List<RetailWaybillDTO>> groupedPDtWayBillMap = retailBillingUtil
							.groupByPickupDate(groupedbBrWayBillList);
					Iterator<Entry<Date, List<RetailWaybillDTO>>> pDtHmIterator = groupedPDtWayBillMap.entrySet()
							.iterator();
					while (pDtHmIterator.hasNext()) {
						Map.Entry<Date, List<RetailWaybillDTO>> pDtMapElement = pDtHmIterator.next();
						List<RetailWaybillDTO> groupedPDtWayBillList = pDtMapElement.getValue();
						this.createRetailBill(retailBillBatches, batchDetailId, batchDetail, groupedPDtWayBillList,
								Constants.getRetailBillB2BCtgy());
					}
				} else {

					/** New Code - Grouping added in B2C */
					Map<Date, List<RetailWaybillDTO>> groupedPDtWayBillMap = retailBillingUtil
							.groupByPickupDate(groupedbBrWayBillList);
					Iterator<Entry<Date, List<RetailWaybillDTO>>> pDtHmIterator = groupedPDtWayBillMap.entrySet()
							.iterator();
					while (pDtHmIterator.hasNext()) {
						Map.Entry<Date, List<RetailWaybillDTO>> pDtMapElement = pDtHmIterator.next();
						List<RetailWaybillDTO> groupedPDtWayBillList = pDtMapElement.getValue();

						/** Consignor Mapping */
						Map<Long, List<RetailWaybillDTO>> groupedConsgWayBillMap = retailBillingUtil
								.groupByCnorId(groupedPDtWayBillList);
						Iterator<Entry<Long, List<RetailWaybillDTO>>> cnorIdHmIterator = groupedConsgWayBillMap
								.entrySet().iterator();
						while (cnorIdHmIterator.hasNext()) {
							Map.Entry<Long, List<RetailWaybillDTO>> cnorIdMapElement = cnorIdHmIterator.next();
							List<RetailWaybillDTO> groupedCnorIdWayBillList = cnorIdMapElement.getValue();
							/**/

							this.createRetailBill(retailBillBatches, batchDetailId, batchDetail,
									groupedCnorIdWayBillList, Constants.getRetailBillB2CCtgy());
						}

					}

					/** Old Code */
					// this.createRetailBill(retailBillBatches, batchDetailId, batchDetail,
					// groupedbBrWayBillList,
					// Constants.getRetailBillB2CCtgy());
				}
			}
		} else {
			this.groupToPayLevel(retailBillBatches, batchDetailId, batchDetail, groupedGSTWayBillList, billCatgory);
		}

	}

	/**
	 * Method to Group waybills By Delivery Branch
	 * 
	 * @param groupedGSTWayBillList
	 * @param batchDetail
	 * @param batchId
	 * @param batchDetailId
	 * @param billCatgory
	 * @throws CustomException
	 */
//	private void groupByDelBr(List<RetailWaybillDTO> groupedGSTWayBillList, RetailBillBatchDetails batchDetail,
//			Long batchId, Long batchDetailId, String billCatgory) throws CustomException
//	{}
//	/**
//	 * Method to Group waybills By Pickup Branch 
//	 * @param groupedGSTWayBillList
//	 * @param batchDetail
//	 * @param batchId
//	 * @param batchDetailId
//	 * @param billCatgory
//	 * @throws CustomException
//	 */
//	private void groupByPickBr(List<RetailWaybillDTO> groupedGSTWayBillList, RetailBillBatchDetails batchDetail,
//			Long batchId, Long batchDetailId, String billCatgory) throws CustomException
//	{}
	/**
	 * method to perform Waybills grouping response for billing
	 * 
	 * @param RetailWaybillDTO[], Long
	 * @return Nothing
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	private void groupRetailWaybills(List<RetailWaybillDTO> waybillList, RetailBillBatchDetails batchDetail,
			RetailBillBatches retailBillBatches) throws CustomException {
		String prcFlag = batchDetail.getPrcFlag();
		logger.info(
				"=== RetailBatch:: RetailServiceImpl:: groupRetailWaybills:: prcFlag === {} -- BillBatchDetailId: {} ",
				prcFlag, batchDetail.getBillBatchDetailId());
		if ("Y".equalsIgnoreCase(prcFlag)) {
			Map<Long, List<RetailWaybillDTO>> groupedPRCWayBillMap = retailBillingUtil.groupByPrcId(waybillList);
			Iterator<Entry<Long, List<RetailWaybillDTO>>> prcHmIterator = groupedPRCWayBillMap.entrySet().iterator();
			while (prcHmIterator.hasNext()) {
				Map.Entry<Long, List<RetailWaybillDTO>> prcMapElement = prcHmIterator.next();
				List<RetailWaybillDTO> groupedPRCWayBillList = prcMapElement.getValue();
				this.groupRetailGSTLevel(groupedPRCWayBillList, batchDetail, retailBillBatches,
						batchDetail.getBillBatchDetailId());
			}
		} else {
			this.groupRetailGSTLevel(waybillList, batchDetail, retailBillBatches, batchDetail.getBillBatchDetailId());
		}
	}

	/**
	 * method to process Waybills Service response for billing
	 * 
	 * @param RetailWaybillResponseDTO
	 * @return Nothing
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Override
	public String processWaybillResponse(RetailWaybillResponseDTO retWBResp, RetailBillBatchDetails rbDetail,
			RetailBillBatches retailBillBatches) {
		String respStr = Constants.FAILURE;
		try {
			if (retWBResp.getWaybillsCount() != null && retWBResp.getWaybillsCount() > 0) {
				List<RetailWaybillDTO> waybills = retWBResp.getWaybills();
				if (waybills.size() == retWBResp.getWaybillsCount()) {
					this.groupRetailWaybills(waybills, rbDetail, retailBillBatches);
				} else {
					logger.info("RetailBatch:: RetailServiceImpl:: Waybill Count Does not match");
				}
				respStr = Constants.SUCCESS;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(
					"RetailBatch:: RetailServiceImpl:: processWaybillResponse: BillBatchDetailId: {} --- Exception: {} ",
					rbDetail.getBillBatchDetailId(), e.getMessage());
		}
		logger.info(
				"RetailBatch:: RetailServiceImpl:: processWaybillResponse: BillBatchDetailId: {} ---  Process Satus: {} ",
				rbDetail.getBillBatchDetailId(), respStr);
		return respStr;
	}

	/**
	 * method to group waybill at ToPay Level
	 * 
	 * @param groupedGSTWayBillList
	 * @param billCatgory
	 * @throws CustomException
	 */
	private void groupToPayLevel(RetailBillBatches retailBillBatches, Long batchDetailId,
			RetailBillBatchDetails batchDetail, List<RetailWaybillDTO> groupedGSTWayBillList, String billCatgory)
			throws CustomException {
		logger.info("=== RetailServiceImpl:: groupToPayLevel:-- BillBatchDetailId: {} ", batchDetailId);
		Map<Long, List<RetailWaybillDTO>> groupedDBrWayBillMap = retailBillingUtil
				.groupByDestinationBr(groupedGSTWayBillList);
		Iterator<Entry<Long, List<RetailWaybillDTO>>> dBrHmIterator = groupedDBrWayBillMap.entrySet().iterator();
		while (dBrHmIterator.hasNext()) {
			Map.Entry<Long, List<RetailWaybillDTO>> dBrMapElement = dBrHmIterator.next();
			List<RetailWaybillDTO> groupedDBrWayBillList = dBrMapElement.getValue();
			if (Constants.getRetailBillB2BCtgy().equals(billCatgory)) {
				Map<Date, List<RetailWaybillDTO>> groupedDDtWayBillMap = retailBillingUtil
						.groupByDeliveryDate(groupedDBrWayBillList);
				Iterator<Entry<Date, List<RetailWaybillDTO>>> dDtHmIterator = groupedDDtWayBillMap.entrySet()
						.iterator();
				while (dDtHmIterator.hasNext()) {
					Map.Entry<Date, List<RetailWaybillDTO>> dDtMapElement = dDtHmIterator.next();
					List<RetailWaybillDTO> groupedDDtWayBillList = dDtMapElement.getValue();
					this.createRetailBill(retailBillBatches, batchDetailId, batchDetail, groupedDDtWayBillList,
							Constants.getRetailBillB2BCtgy());
				}
			} else {

				/** New Code - Grouping added in B2C */
				Map<Date, List<RetailWaybillDTO>> groupedDDtWayBillMap = retailBillingUtil
						.groupByDeliveryDate(groupedDBrWayBillList);
				Iterator<Entry<Date, List<RetailWaybillDTO>>> dDtHmIterator = groupedDDtWayBillMap.entrySet()
						.iterator();
				while (dDtHmIterator.hasNext()) {
					Map.Entry<Date, List<RetailWaybillDTO>> dDtMapElement = dDtHmIterator.next();
					List<RetailWaybillDTO> groupedDDtWayBillList = dDtMapElement.getValue();

					/** Consignee Grouping */

					Map<Long, List<RetailWaybillDTO>> groupedCneeIdWayBillMap = retailBillingUtil
							.groupByCneeId(groupedDDtWayBillList);
					Iterator<Entry<Long, List<RetailWaybillDTO>>> cneeIdHmIterator = groupedCneeIdWayBillMap.entrySet()
							.iterator();
					while (cneeIdHmIterator.hasNext()) {
						Map.Entry<Long, List<RetailWaybillDTO>> cneeIdMapElement = cneeIdHmIterator.next();
						List<RetailWaybillDTO> groupedCneeIdWayBillList = cneeIdMapElement.getValue();

						/** Consignee Grouping */

						/**/
						this.createRetailBill(retailBillBatches, batchDetailId, batchDetail, groupedCneeIdWayBillList,
								Constants.getRetailBillB2CCtgy());
					}
					/**/
				}

				/** Old Code */
				// this.createRetailBill(retailBillBatches, batchDetailId, batchDetail,
				// groupedDBrWayBillList,
				// Constants.getRetailBillB2CCtgy());
			}
		}
	}

	/**
	 * To Create Retail Bill for SelfService
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wbList
	 * @param billCtgy
	 * @param gstin
	 * @return
	 * @throws CustomException
	 */
	private String createRetailBillforSSP(RetailBillBatches retailBillBatches, RetailBillBatchDetails rbDetails,
			Long batchId, Long batchDetailId, List<RetailWaybillDTO> wbList, String billCtgy, String gstin,
			String billToMail) throws CustomException {

		RetailBills bills = new RetailBills();
		RetailBills newbill = new RetailBills();
		String newBillNumber = null;

		try {

			// String billNum = this.getNextBillNum();
			double sumOutStanding = 0;
			double sumBaseAmt = 0;
			double sumTtlTaxAmt = 0;
			double sumIgstAmt = 0;
			double sumCgstAmt = 0;
			double sumSgstAmt = 0;

			String rBillType = wbList.get(0).getDocumentType();
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- billToMail: {} ", billToMail);
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- rBillType: {} ", rBillType);
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- batchId: {} ", batchId);
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- batchDetailId: {} ", batchDetailId);
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- billCtgy: {} ", billCtgy);
			Long blngBrId;

			for (RetailWaybillDTO waybill : wbList) {
				sumOutStanding = sumOutStanding + waybill.getOutstandingAmount();
				sumBaseAmt = sumBaseAmt + waybill.getBaseAmount();
				sumTtlTaxAmt = sumTtlTaxAmt + waybill.getTtlTaxAmount();
				sumIgstAmt = sumIgstAmt + waybill.getIgstAmount();
				sumCgstAmt = sumCgstAmt + waybill.getCgstAmount();
				sumSgstAmt = sumSgstAmt + waybill.getSgstAmount();
			}
			// Rounded Double Values
			Double doubleSumOutStanding = Double.valueOf(Math.round(sumOutStanding * 100) / 100.0);
			Double doubleSumBaseAmt = Double.valueOf(Math.round(sumBaseAmt * 100) / 100.0);
			Double doubleSumTtlTaxAmt = Double.valueOf(Math.round(sumTtlTaxAmt * 100) / 100.0);
			Double doubleSumIgstAmt = Double.valueOf(Math.round(sumIgstAmt * 100) / 100.0);
			Double doubleSumCgstAmt = Double.valueOf(Math.round(sumCgstAmt * 100) / 100.0);
			Double doubleSumSgstAmt = Double.valueOf(Math.round(sumCgstAmt * 100) / 100.0);

			if ("PAID".equals(rBillType)) {
				blngBrId = wbList.get(0).getBkgBrId();
				bills.setBlngBrId(wbList.get(0).getBkgBrId());
				bills.setCollBrId(wbList.get(0).getBkgBrId());
				bills.setAltCollBrId(wbList.get(0).getBkgBrId());
				bills.setSubmsnBrId(wbList.get(0).getBkgBrId());
				bills.setBlngBr(wbList.get(0).getBkgBr());
				bills.setCollBr(wbList.get(0).getBkgBr());
				bills.setAltCollBr(wbList.get(0).getBkgBr());
				bills.setSubmsnBr(wbList.get(0).getBkgBr());
				bills.setBillDt(wbList.get(0).getPickupDate());

			} else {
				blngBrId = wbList.get(0).getDeliveryBrId();
				bills.setBlngBrId(wbList.get(0).getDeliveryBrId());
				bills.setCollBrId(wbList.get(0).getDeliveryBrId());
				bills.setAltCollBrId(wbList.get(0).getDeliveryBrId());
				bills.setSubmsnBrId(wbList.get(0).getDeliveryBrId());
				bills.setBlngBr(wbList.get(0).getDeliveryBr());
				bills.setCollBr(wbList.get(0).getDeliveryBr());
				bills.setAltCollBr(wbList.get(0).getDeliveryBr());
				bills.setSubmsnBr(wbList.get(0).getDeliveryBr());
				bills.setBillDt(wbList.get(0).getDelieveryDate());

			}
			BranchResponseDTO brResp = this.getBranchDetailById(blngBrId);
			String brGstin = this.sellerGstin;
			if (brResp != null) {
				BranchDataDto brData = brResp.getData();
				brGstin = brData.getBranchGstNum();
				bills.setBillingBrGstNum(brGstin);
			}
			bills.setBillToCustName(wbList.get(0).getBillToCustomer());
			bills.setBillToCustName(wbList.get(0).getBillToCustomer());
			bills.setBillToLocation(wbList.get(0).getBillToLocation());
			bills.setBillToPincode(wbList.get(0).getBillToPincode());
			bills.setBillToAddr(wbList.get(0).getBillToAddr());
			bills.setBillToAddrLine1(wbList.get(0).getBillToAddr());
			bills.setBillToEmail(billToMail);
			bills.setBillBatchDetailId(batchDetailId);
			bills.setRetailBillBatches(retailBillBatches);
			bills.setGstNum(gstin);

			/** New Changes SSP Bill date */
//			bills.setBillDt(new Date());
//			bills.setBillNum(this.getNextBillNum());

			bills.setBillNum(this.getNextSSPBillNum(bills.getBillDt()));

			bills.setBillFromDt(new Date());
			bills.setBillToDt(new Date());
			bills.setStatus("FINALIZED");
			bills.setState(wbList.get(0).getState());
			bills.setPrcId(wbList.get(0).getPrcId());
			bills.setPrcCode(wbList.get(0).getPrcCode());
			bills.setBillCtgy(billCtgy);
			bills.setBillType(rBillType);
			bills.setBlngCycle(wbList.get(0).getBlngCycle());
			bills.setConsigneeId(wbList.get(0).getConsigneeId());
			bills.setConsigneeName(wbList.get(0).getConsigneeName());
			bills.setConsignerId(wbList.get(0).getConsignerId());
			bills.setConsignerName(wbList.get(0).getConsignerName());
			bills.setBaseAmt(sumBaseAmt);
			String calculatedtaxRateCode = null;
//			if (brGstin != null && gstin != null) {
			if (!RetailBillingUtil.isNullOrEmpty(brGstin) && !RetailBillingUtil.isNullOrEmpty(gstin)) {
				String customerStateCode = gstin.substring(0, 2);
				bills.setStateCode(customerStateCode);
				String safexStateCode = brGstin.substring(0, 2);
				if (customerStateCode.equals(safexStateCode)) {
					calculatedtaxRateCode = oracleCgst;
				} else {
					calculatedtaxRateCode = oracleIgst;
				}
			}

			/** b2c *******************************/
			else {

				// Need to confirm gstin of safexpress
				String customerStateCode = sellerGstin.substring(0, 2);
				bills.setStateCode(customerStateCode);
				String safexStateCode = brGstin.substring(0, 2);
				if (customerStateCode.equals(safexStateCode)) {
					calculatedtaxRateCode = oracleCgst;
				} else {
					calculatedtaxRateCode = oracleIgst;
				}

			}

			/*************************************/

			if (oracleIgst.equals(calculatedtaxRateCode)) {
				bills.setIgstAmt(doubleSumIgstAmt);
				if (doubleSumIgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
					doubleSumOutStanding = doubleSumIgstAmt + doubleSumBaseAmt;
				}
			} else if (oracleCgst.equals(calculatedtaxRateCode)) {
				bills.setCgstAmt(doubleSumCgstAmt);
				bills.setSgstAmt(doubleSumSgstAmt);
				if (doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
					doubleSumOutStanding = doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt;
				}
			}
			bills.setTtlTaxAmt(doubleSumTtlTaxAmt);
			bills.setOracleTaxRate(this.getTaxRatebyCode(calculatedtaxRateCode));
			bills.setOracleTaxRateCode(calculatedtaxRateCode);
			bills.setOutstandingAmt(doubleSumOutStanding);
			bills.setActualOutstandingAmt(doubleSumOutStanding);
			// RetailBills newbill = retailBillsRepository.save(bills);

			/*
			 * New Code
			 ************************************************************************************************************************/

			logger.info("RetailServiceImpl -- createRetailBillforSSP -- Create Bill: BillNum: {} -- batchDetailId: {} ",
					bills.getBillNum(), batchDetailId);

			try {
				newbill = retailBillsRepository.save(bills);

			} catch (Exception e) {
				e.printStackTrace();
				TimeUnit.SECONDS.sleep(1);
				logger.info(
						"RetailServiceImpl -- createRetailBillforSSP --  Retry generating Bill when getting Constraint or other Exception: {} ",
						e.getMessage());
				newbill = retailBillsRepository.save(bills);
			}

			Long billid = newbill.getBillId();
			newBillNumber = newbill.getBillNum();

			newBillNumber = getUpdRetailBillNumberSSP(billid, newBillNumber);
			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- New Create Bill: BillNum: {} -- batchDetailId: {} ",
					newBillNumber, batchDetailId);

			newbill.setBillNum(newBillNumber);
			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- New Create Bill: BillNum1: {} -- batchDetailId: {} ",
					bills.getBillNum(), batchDetailId);

			/****************************************************************************************************************************/

			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- Data Saved in Retail Bills -- BillId: {} -- BillNumber: {}",
					newbill.getBillId(), newBillNumber);

			/**
			 * New
			 * Code///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 */

			BasicApiResponseDTO basicApiResponseDTO = retailBillingUtil.initiatePostSspBillId(newbill, wbList);

			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- initiatePostSspBillId Status {} -- BillId() : {} -- BillNum {} --  batchDetailId: {} ",
					basicApiResponseDTO.getStatus(), newbill.getBillId(), newbill.getBillNum(), batchDetailId);
			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- initiatePostSspBillId Message {} -- BillId() : {} -- BillNum {} --  batchDetailId: {}  ",
					basicApiResponseDTO.getMessage(), newbill.getBillId(), newbill.getBillNum(), batchDetailId);

//			String respn ="FAILURE"; //for Testing
//			if(respn.equalsIgnoreCase("SUCCESS")) {

			if (basicApiResponseDTO.getStatus().equalsIgnoreCase("SUCCESS")) {

				logger.info(
						"RetailServiceImpl -- createRetailBillforSSP -- initiatePostSspBillId Success --  newbill.getBillId() : {} ===  newbill.getBillNum() : {}",
						newbill.getBillId(), newbill.getBillNum());

			} else {

				// Mark Status CANCEL for this Retail Bill in Retail Bills table in DB
				logger.info(
						"RetailServiceImpl -- createRetailBillforSSP -- going to cancelRetailBill if Failure for Bill id: {} ",
						newbill.getBillId());
				newbill = this.cancelRetailBill(newbill);
				logger.info(
						"RetailServiceImpl -- createRetailBillforSSP -- cancelRetailBill due to Service Failure === Bill id: {} --- Bill Number: {} ",
						newbill.getBillId(), newbill.getBillNum());
				// Call Untag Service for Retail Bill Number
				String untagResp = retailBillingUtil.untagWaybillRetailBillNumber(wbList, newbill.getBillNum());
				logger.info("RetailServiceImpl -- createRetailBillforSSP -- Untag RetailBill Number: Response: {} ",
						untagResp);

				return null;
			}
			/**
			 * /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 */

			// retailBillingUtil.initiatePostBillId(newbill, wbList);

			/**
			 * Temporary Commented below code because Fusion Integration is closed for now
			 * RetailBillIntegrations rbintg =
			 * retailBillingUtil.mapCreationDataIntegration(newbill);
			 * iRetailBillIntegrationsRepository.save(rbintg);
			 * 
			 * logger.info( "RetailServiceImpl -- createRetailBillforSSP -- Data saved in
			 * RetailBillIntegrations -- BillId: {} -- BillNumber: {}", newbill.getBillId(),
			 * newBillNumber);
			 */

			/*
			 * New Code
			 *********************************************************************************************************************************/
		} catch (Exception e) {

			e.printStackTrace();
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- batchDetailId: {}: Exception {} ",
					batchDetailId, e.getMessage());

			newbill = this.cancelRetailBill(newbill);
			logger.info(
					"RetailServiceImpl -- createRetailBillforSSP -- cancelRetailBill due to Exception === Bill id: {} --- Bill Number: {} -- batchDetailId: {}",
					newbill.getBillId(), newbill.getBillNum(), batchDetailId);

			// Call Untag Service for Retail Bill Number
			String untagResp = retailBillingUtil.untagWaybillRetailBillNumber(wbList, newbill.getBillNum());
			logger.info("RetailServiceImpl -- createRetailBillforSSP -- Untag RetailBill Number: Response: {} ",
					untagResp);

			return null;
		}

		/********************************************************************************************************************************/

		return newBillNumber;
	}

	private void groupRetailGSTLevel(List<RetailWaybillDTO> groupedPRCWayBillList, RetailBillBatchDetails batchDetail,
			RetailBillBatches retailBillBatches, Long batchDetailId) throws CustomException {
		String gstFlag = batchDetail.getGstFlag();
		logger.info(
				"=== RetailBatch:: RetailServiceImpl:: groupRetailGSTLevel:: gstFlag === {}  -- BillBatchDetailId: {} ",
				gstFlag, batchDetailId);
		if ("Y".equals(gstFlag)) {
			Map<String, List<RetailWaybillDTO>> groupedGSTWayBillMap = retailBillingUtil
					.groupByGSTIN(groupedPRCWayBillList);
			Iterator<Entry<String, List<RetailWaybillDTO>>> gstHmIterator = groupedGSTWayBillMap.entrySet().iterator();
			while (gstHmIterator.hasNext()) {
				Map.Entry<String, List<RetailWaybillDTO>> gstMapElement = gstHmIterator.next();
				List<RetailWaybillDTO> groupedGSTWayBillList = gstMapElement.getValue();
				this.groupPaidToPayLevel(groupedGSTWayBillList, batchDetail, retailBillBatches, batchDetailId,
						Constants.getRetailBillB2BCtgy());
			}

		} else {
			this.groupPaidToPayLevel(groupedPRCWayBillList, batchDetail, retailBillBatches, batchDetailId,
					Constants.getRetailBillB2CCtgy());
		}

	}

	/**
	 * added new params
	 * 
	 * @param retWBResp
	 * @return
	 * @throws CustomException
	 */
	public String processWaybillResponseforSSP(RetailBillBatches retailBillBatches, RetailBillBatchDetails rbDetails,
			RetailWaybillResponseDTO retWBResp, String gstin, String billToMail) throws CustomException {
		String billNum = null;
		if (retWBResp.getWaybills() != null) {
			List<RetailWaybillDTO> wbList = retWBResp.getWaybills();
			logger.info("RetailServiceImpl - processWaybillResponseforSSP - BatchId -- {}", retWBResp.getBatchId());

			/*********************************************************
			 * B2B
			 ******************************************************/

			if (RetailBillingUtil.isNullOrEmpty(gstin)) {

				logger.info("RetailServiceImpl - processWaybillResponseforSSP - B2C -- Without GSTIN -- BatchId -- {}",
						retWBResp.getBatchId());

				billNum = this.createRetailBillforSSP(retailBillBatches, rbDetails, retWBResp.getBatchId(),
						retWBResp.getBatchDetailId(), wbList, "B2C", gstin, billToMail);

			} else {

				logger.info(
						"RetailServiceImpl - processWaybillResponseforSSP - B2B -- With GSTIN -- BatchId: {} -- gstin: {} ",
						retWBResp.getBatchId(), gstin);

				/******************************************************************************************************************/

				billNum = this.createRetailBillforSSP(retailBillBatches, rbDetails, retWBResp.getBatchId(),
						retWBResp.getBatchDetailId(), wbList, "B2B", gstin, billToMail);
			}
		}
		return billNum;
	}

	/**
	 * Method to Create Reatil Bills
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wayBillList
	 * @param billCtgy
	 * @throws CustomException
	 */
	private void createRetailBill(RetailBillBatches retailBillBatches, Long batchDetailId,
			RetailBillBatchDetails batchDetail, List<RetailWaybillDTO> wayBillList, String billCtgy)
			throws CustomException {

		logger.info("=== RetailBatch:: RetailServiceImpl:: createRetailBill billCtgy: === {} ", billCtgy);
		logger.info("RetailBatch:: RetailServiceImpl:: createRetailBill: batchDetailId: {} ", batchDetailId);

		RetailBills newbill = null;
		try {

			newbill = this.saveRetailBill(retailBillBatches, batchDetailId, batchDetail, wayBillList, billCtgy);

			if (newbill != null) {

				logger.info(
						"RetailBatch:: RetailServiceImpl:: createRetailBill: After Created BillId() : {} -- BillNum {} --  batchDetailId: {} ",
						newbill.getBillId(), newbill.getBillNum(), batchDetailId);

				BasicApiResponseDTO basicApiResponseDTO = retailBillingUtil.initiatePostBillId(newbill, wayBillList);

				logger.info(
						"RetailBatch:: RetailServiceImpl:: createRetailBill: initiatePostBillId Status {} -- BillId() : {} -- BillNum {} --  batchDetailId: {} ",
						basicApiResponseDTO.getStatus(), newbill.getBillId(), newbill.getBillNum(), batchDetailId);
				logger.info(
						"RetailBatch:: RetailServiceImpl:: createRetailBill: initiatePostBillId Message {} -- BillId() : {} -- BillNum {} --  batchDetailId: {}  ",
						basicApiResponseDTO.getMessage(), newbill.getBillId(), newbill.getBillNum(), batchDetailId);

//				String respn ="FAILURE"; //Testing
//				if(respn.equalsIgnoreCase("SUCCESS")) {

				if (basicApiResponseDTO.getStatus().equalsIgnoreCase("SUCCESS")) {

					/**
					 * Temporary Commented below code because Fusion Integration is closed for now
					 * // RetailBillIntegrations rbintg =
					 * retailBillingUtil.mapCreationDataIntegration(newbill); //
					 * iRetailBillIntegrationsRepository.save(rbintg);
					 **/

					logger.info(
							"=== RetailBatch:: RetailServiceImpl:: createRetailBill === newbill.getBillId() : {} ===  newbill.getBillNum() : {}  -- billCtgy: {} ",
							newbill.getBillId(), newbill.getBillNum(), billCtgy);
					/*
					 * if ("B2C".equals(billCtgy)) { logger.info(
					 * "=== RetailBatch:: RetailServiceImpl:: createRetailBill === sendEBill: newbill.getBillId() : {} ===  newbill.getBillNum() : {}"
					 * , newbill.getBillId(), newbill.getBillNum()); // In case of B2C: No need to
					 * send EBILL will send in seperate scheduler: 17-Jan-2023 //
					 * sendEBill(newbill.getBillId(), "RETAIL_BILL", newbill.getBillNum()); }
					 */
				} else {
					// Mark Status CANCEL for this Retail Bill in Retail Bills table in DB
					logger.info(
							"=== RetailBatch:: RetailServiceImpl:: going to cancelRetailBill if Failure for Bill id: {} -- billCtgy: {} ",
							newbill.getBillId(), billCtgy);
					newbill = this.cancelRetailBill(newbill);
					logger.info(
							"=== RetailBatch:: RetailServiceImpl:: cancelRetailBill due to Service Failure === Bill id: {} --- Bill Number: {} ",
							newbill.getBillId(), newbill.getBillNum());
					// Call Untag Service for Retail Bill Number
					// String untagResp =
					// retailBillingUtil.untagRetailBillNumber(newbill.getBillNum());
					String untagResp = retailBillingUtil.untagWaybillRetailBillNumber(wayBillList,
							newbill.getBillNum());
					logger.info("RetailBatch:: createRetailBill: Untag RetailBill Number: Response: {} ", untagResp);
				}
			} else {
				logger.info("RetailBatch:: RetailServiceImpl:: createRetailBill: inside else: batchDetailId: {} ",
						batchDetailId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(
					"=== RetailBatch:: RetailServiceImpl:: going to cancelRetailBill if Exception for Bill id: {} --batchDetailId: {} ",
					newbill.getBillId(), batchDetailId);

			newbill = this.cancelRetailBill(newbill);
			logger.info(
					"=== RetailBatch:: RetailServiceImpl:: cancelRetailBill due to Exception === Bill id: {} --- Bill Number: {} -- batchDetailId: {}",
					newbill.getBillId(), newbill.getBillNum(), batchDetailId);

			// Call Untag Service for Retail Bill Number
			// String untagResp =
			// retailBillingUtil.untagRetailBillNumber(newbill.getBillNum());
			String untagResp = retailBillingUtil.untagWaybillRetailBillNumber(wayBillList, newbill.getBillNum());
			logger.info("RetailBatch:: createRetailBill: Untag RetailBill Number: Response: {} ", untagResp);
		}

	}

	/**
	 * Method to generate tax rate value
	 * 
	 * @param taxRateCode
	 * @return
	 */
	private String getTaxRatebyCode(String taxRateCode) {
		String taxRate = null;
		if (taxRateCode != null && taxRateCode.equals(oracleIgst)) {
			taxRate = oracleIgstVal;
		} else {
			taxRate = oracleCgstVal;
		}
		return taxRate;
	}

	/**
	 * Method to Get Tax Rate Code
	 * 
	 * @param gstin
	 * @param blngBrId
	 * @return
	 * @throws CustomException
	 */
	private String getTaxRateCode(String gstin, Long blngBrId) {
		String taxRateCode = null;
		String brGstin = this.sellerGstin;
		BranchResponseDTO brResp = this.getBranchDetailById(blngBrId);

		if (brResp != null) {
			BranchDataDto brDataList = brResp.getData();
			brGstin = brDataList.getBranchGstNum();
		}
		if (gstin != null) {
			String customerStateCode = gstin.substring(0, 2);
			String safexStateCode = (brGstin != null) ? brGstin.substring(0, 2) : this.sellerStateCode;
			if (customerStateCode.equals(safexStateCode)) {
				taxRateCode = oracleCgst;
			} else {
				taxRateCode = oracleIgst;
			}
		}
		return taxRateCode;
	}

	/**
	 * Method to Get Tax Rate Code
	 * 
	 * @param gstin
	 * @param blngBrId
	 * @return
	 * @throws CustomException
	 */
	private String getTaxRateCodeB2C(Long blngBrId) {

		String taxRateCode = null;

		BranchResponseDTO brResp = this.getBranchDetailById(blngBrId);
		String brGstin = this.sellerGstin;
		if (brResp != null) {
			BranchDataDto brData = brResp.getData();
			brGstin = brData.getBranchGstNum();
		}

		String customerStateCode = sellerGstin.substring(0, 2);

		String safexStateCode = (brGstin != null) ? brGstin.substring(0, 2) : this.sellerStateCode;

		if (customerStateCode.equals(safexStateCode)) {
			taxRateCode = oracleCgst;
		} else {
			taxRateCode = oracleIgst;
		}

		return taxRateCode;
	}

	/**
	 * Method to get next Bill Number
	 * 
	 * @return
	 */
	private String getNextBillNumRetail(Calendar cal) {
		int month;
		int year;
//		String billNumber = null;
//		Calendar cal = Calendar.getInstance();
//		cal.setTime(new Date());
		month = cal.get(Calendar.MONTH);
		int advance = (month < 3) ? 0 : 1;
		year = cal.get(Calendar.YEAR) + advance;
		String monthStr = String.format("%02d", month + 1);
		String fisYearStr = String.valueOf(year).substring(2);
		return fisYearStr.concat("06").concat(monthStr);
//		return fisYearStr.concat("06").concat(monthStr).concat("1");   // for Feb fix - temp solution

//		billNumber = retailBillsRepository.getNextBillNum(month + 1).toString();
//		String billNumberSeq = String.format("%06d", Integer.parseInt(billNumber));
//		return fisYearStr.concat("06").concat(monthStr).concat(billNumberSeq);
	}

	/**
	 * Method to get next Bill Number
	 * 
	 * @return
	 */
	private String getNextBillNum() {
		int month;
		int year;
//		String billNumber = null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		month = cal.get(Calendar.MONTH);
		int advance = (month < 3) ? 0 : 1;
		year = cal.get(Calendar.YEAR) + advance;
		String monthStr = String.format("%02d", month + 1);
		String fisYearStr = String.valueOf(year).substring(2);
		return fisYearStr.concat("06").concat(monthStr);
//		return fisYearStr.concat("06").concat(monthStr).concat("1");   // for Feb fix - temp solution

//		billNumber = retailBillsRepository.getNextBillNum(month + 1).toString();
//		String billNumberSeq = String.format("%06d", Integer.parseInt(billNumber));
//		return fisYearStr.concat("06").concat(monthStr).concat(billNumberSeq);
	}
	
	/**
	 * Method to get next Bill Number
	 * 
	 * @return
	 */
	private String getNextSSPBillNum(Date billDt) {
		int month;
		int year;
//		String billNumber = null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(billDt);
		month = cal.get(Calendar.MONTH);
		int advance = (month < 3) ? 0 : 1;
		year = cal.get(Calendar.YEAR) + advance;
		String monthStr = String.format("%02d", month + 1);
		String fisYearStr = String.valueOf(year).substring(2);
		return fisYearStr.concat("06").concat(monthStr);
//		return fisYearStr.concat("06").concat(monthStr).concat("1");   // for Feb fix - temp solution

//		billNumber = retailBillsRepository.getNextBillNum(month + 1).toString();
//		String billNumberSeq = String.format("%06d", Integer.parseInt(billNumber));
//		return fisYearStr.concat("06").concat(monthStr).concat(billNumberSeq);
	}

	/**
	 * Method to Get Branch Details by br ID
	 * 
	 * @param brId
	 * @return
	 * @throws CustomException
	 */
	public BranchResponseDTO getBranchDetailById(Long brId) {

		try {
			String propelToken = propelAuthUti.getPropelToken();
			String url = Constants.getPropelBranchApi() + "branchId/" + brId;
			logger.info("RetailServiceImpl:: get Branch Data API=" + url);
			HttpEntity<Long> entity = new HttpEntity<>(
					PropelAuthUtil.createPropelBookingHeader(Constants.getUserName(), propelToken));
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<BranchResponseDTO> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,
					BranchResponseDTO.class);
			return responseEntity.getBody();
		} catch (Exception exception) {
			exception.printStackTrace();
			logger.info("RetailServiceImpl:: Branch API Errored Out: {} ", exception.getLocalizedMessage());
			return null;
		}
	}

	/**
	 * Method to perform waybill write off
	 */
	@Override
	public String retailBillWriteOff(List<RetailWayBillWriteOffDTO> retailBillReq) throws CustomException {
		logger.info("=== RetailServiceImpl: retailBillWriteOff ===");

		Gson gg = new Gson();
		System.out.println(gg.toJson(retailBillReq));
		for (RetailWayBillWriteOffDTO retailObj : retailBillReq) {
			// to save deviation history
			RetailDocDeviationHistory retailDocDeviationHistory = retailBillingUtil
					.mapDevaitionHistFromDtoForWriteoff(retailObj);
			RetailDocDeviationHistory updatedData = iRetailDocDeviationHistoryRepository
					.save(retailDocDeviationHistory);

			// to save records in integration table
			RetailBillIntegrations wmsBillsIntegrations = retailBillingUtil.mapWriteOffDataIntegration(retailObj,
					updatedData.getDevId());
			iRetailBillIntegrationsRepository.save(wmsBillsIntegrations);

		}
		return "History Updated In Billing";
	}

	/**
	 * added Method to Implement CMDM outstanding update
	 * 
	 */
	@Override
	public List<CMDMInvoiceUpdateResponseDTO> updateCMDMInvoiceDetails(List<CMDMInvoiceUpdateDTO> requestDataList) {

		logger.info("=== RetailServiceImpl:: updateCMDMInvoiceDetails ===");
		List<CMDMInvoiceUpdateResponseDTO> repSuccessList = new ArrayList<>();
		List<CMDMInvoiceUpdateResponseDTO> repErrorList = new ArrayList<>();
		Boolean isError = false;
		List<RetailBills> cbList = new ArrayList<>();
		List<RetailDocDeviationHistory> histList = new ArrayList<>();
		for (CMDMInvoiceUpdateDTO obj : requestDataList) {
			Optional<RetailBills> retailBillsList = retailBillsRepository.findById(obj.getDocumentId());
			if (retailBillsList.isPresent()) {
				RetailBills rbill = retailBillsList.get();
				Double amount = obj.getAmount().doubleValue();
				if (amount == null) {
					CMDMInvoiceUpdateResponseDTO response = retailBillingUtil.setCMDMInvoiceUpdateResponseDTO(obj,
							"FAILED", "Amount must not be null");
					repErrorList.add(response);
					isError = true;
					continue;
				}
				if (rbill.getOutstandingAmt() < Math.abs(amount)) {
					CMDMInvoiceUpdateResponseDTO response = retailBillingUtil.setCMDMInvoiceUpdateResponseDTO(obj,
							"FAILED", "Amount is greater than bill outstanding amount");
					repErrorList.add(response);
					isError = true;
				} else {
					if (rbill.getOutstandingAmt() <= amount) {
						rbill.setOutstandingAmt(Double.valueOf(0));
					} else {
						Double newOsAmount = rbill.getOutstandingAmt() + amount;
						rbill.setOutstandingAmt(roundToDecimals(newOsAmount, 2));
					}
					rbill.setUpdBy(Constants.getUserName());
					cbList.add(rbill);
					RetailDocDeviationHistory creditDocDeviationHistory = retailBillingUtil
							.mapDevaitionHistFromDtoForCmdm(rbill, obj);
					histList.add(creditDocDeviationHistory);
					CMDMInvoiceUpdateResponseDTO response = retailBillingUtil.setCMDMInvoiceUpdateResponseDTO(obj,
							"SUCCESS", "Successfully updated amount");
					repSuccessList.add(response);
				}
			} else {
				CMDMInvoiceUpdateResponseDTO response = retailBillingUtil.setCMDMInvoiceUpdateResponseDTO(obj, "FAILED",
						"No data found against given bill numbers.");
				repErrorList.add(response);
				isError = true;
			}
		}
		if (Boolean.FALSE.equals(isError)) {
			retailBillsRepository.saveAll(cbList);
			iRetailDocDeviationHistoryRepository.saveAll(histList);
			return repSuccessList;

		} else {
			return repErrorList;

		}
	}

	@Override
	public List<IrnHeaderDTO> getB2bBills(String errorFlag) {

		logger.info("=== RetailServiceImpl:: getB2bBills === {} ", errorFlag);
		List<IrnHeaderDTO> irnHeader = new ArrayList<>();

		// fetch the retail B2B bills without IRN number
		List<RetailBills> retailBillsList = null;
		if (errorFlag != null && "E".equals(errorFlag)) {
			retailBillsList = retailBillsRepository.getIrnErrorBills(errorFlag);
		} else {
			retailBillsList = retailBillsRepository.getB2BRetailBills();
		}
		for (RetailBills retailBill : retailBillsList) {
			logger.info("RetailServiceImpl:: Retail Bill Eligible for einvoice : {} ", retailBill.getBillNum());
			try {
				// create object
				DocDtls docDtls = new DocDtls();
				docDtls.setNo(retailBill.getBillNum());
				docDtls.setTyp(Constants.EINV_INV_TYPE);
				docDtls.setDt(retailBillingUtil.formatDateToString(retailBill.getBillDt()));

				// TranDtls
				TranDtls tranDtls = new TranDtls();
				tranDtls.setTaxSch(Constants.EINV_TAXSCH_GST);
				tranDtls.setSupTyp(Constants.EINV_SUPTYP_B2B);
				tranDtls.setRegRev("N");

				// seller details
				SellerDtls sellerDtls = new SellerDtls();
				sellerDtls.setGstin(this.sellerGstin);
				sellerDtls.setLglNm(this.sellerLegalName);
				sellerDtls.setTrdNm(this.sellerTradeName);
				sellerDtls.setAddr1(this.sellerAddr1);
				sellerDtls.setAddr2(this.sellerAddr2);
				sellerDtls.setLoc(this.sellerLocation);
				sellerDtls.setPin(this.sellerPincode);
				sellerDtls.setStcd(this.sellerStateCode);

				// buyer details
				BuyerDtls buyerDtls = new BuyerDtls();
				buyerDtls.setGstin(retailBill.getGstNum());
				buyerDtls.setLglNm(retailBill.getBillToCustName());
				buyerDtls.setTrdNm(retailBill.getBillToCustName());
				buyerDtls.setAddr1(retailBill.getBillToAddrLine1());
				buyerDtls.setAddr2(retailBill.getBillToAddrLine2());
				buyerDtls.setLoc(retailBill.getBillToLocation());
				buyerDtls.setPin(retailBill.getBillToPincode() != null && !"".equals(retailBill.getBillToPincode())
						? Integer.valueOf(retailBill.getBillToPincode().replace(" ", ""))
						: 0);
				buyerDtls.setStcd(retailBill.getGstNum().substring(0, 2));
				buyerDtls.setPos(retailBill.getGstNum().substring(0, 2));

				// Line items
				List<ItemList> itemList = new ArrayList<>();
				ItemList item = new ItemList();
				item.setSlNo("1");
				item.setPrdDesc(this.productDesc);
				item.setIsServc(this.productIsService);
				item.setHsnCd(this.productHsnCode);
				item.setQty(1);
				item.setUnitPrice(retailBill.getBaseAmt());
				item.setTotAmt(retailBill.getBaseAmt());
				item.setDiscount(0);
				item.setPreTaxVal(0);
				item.setAssAmt(retailBill.getBaseAmt());
				if ((retailBill.getIgstAmt() != null && retailBill.getIgstAmt() > 0)) {
					item.setGstRt(retailBill.getOracleTaxRate() != null ? Integer.valueOf(retailBill.getOracleTaxRate())
							: 18);
				} else if ((retailBill.getCgstAmt() != null && retailBill.getCgstAmt() > 0)) {
					item.setGstRt(
							retailBill.getOracleTaxRate() != null ? Integer.valueOf(retailBill.getOracleTaxRate()) * 2
									: 18);
				} else {
					item.setGstRt(0);
				}

				item.setIgstAmt(retailBill.getIgstAmt() != null ? (retailBill.getIgstAmt()) : 0);
				item.setCgstAmt(retailBill.getCgstAmt() != null ? (retailBill.getCgstAmt()) : 0);
				item.setSgstAmt(retailBill.getSgstAmt() != null ? (retailBill.getSgstAmt()) : 0);
				item.setTotItemVal((retailBill.getActualOutstandingAmt()));
				itemList.add(item);
				// set summary
				ValDtls valDtls = new ValDtls();
				valDtls.setAssVal((retailBill.getBaseAmt()));
				valDtls.setCgstVal(retailBill.getCgstAmt() != null ? (retailBill.getCgstAmt()) : 0);
				valDtls.setSgstVal(retailBill.getSgstAmt() != null ? (retailBill.getSgstAmt()) : 0);
				valDtls.setIgstVal(retailBill.getIgstAmt() != null ? (retailBill.getIgstAmt()) : 0);
				valDtls.setTotInvVal((retailBill.getActualOutstandingAmt()));
				valDtls.setTotInvValFc((retailBill.getActualOutstandingAmt()));

				// create invoice object
				IrnHeaderDTO invoice = new IrnHeaderDTO();
				invoice.setBuyerDtls(buyerDtls);
				invoice.setSellerDtls(sellerDtls);
				invoice.setDocDtls(docDtls);
				invoice.setItemList(itemList);
				invoice.setTranDtls(tranDtls);
				invoice.setValDtls(valDtls);
				invoice.setBillType(retailBill.getBillType());
				invoice.setBillId(retailBill.getBillId());
				irnHeader.add(invoice);
			} catch (Exception ex) {
				ex.printStackTrace();
				logger.info("Retail Bill:: " + retailBill.getBillNum() + " exception: " + ex.getMessage());
			}

		}
		return irnHeader;

	}

	@Override
	public String saveAdditionalDetails(List<BillAdditionalInfoDTO> additionalInfo) {
		logger.info("===== RetailServiceImpl:: saveAdditionalDetails ==========  ");

		for (BillAdditionalInfoDTO billInfo : additionalInfo) {

			try {
				// fetch the retail bill
				logger.info("===== RetailServiceImpl:: saveAdditionalDetails:: BillId: {}", billInfo.getBillId());
				logger.info("===== RetailServiceImpl:: saveAdditionalDetails:: Source: {}", billInfo.getSource());
				/**
				 * Below code is commented because of could not initialize proxy error
				 **/
//			RetailBills retailBill = retailBillsRepository.getOne(billInfo.getBillId());
				RetailBills retailBill = retailBillsRepository.getNewBillsById(billInfo.getBillId());

				if (retailBill != null) {
					if (billInfo.getSource() != null && billInfo.getSource().equals("EINV")) {
						retailBill.setAckDt(billInfo.getAckDt());
						retailBill.setAckNo(billInfo.getAckNo());
						retailBill.setIrn(billInfo.getIrn());
						retailBill.setSignedQrCode(billInfo.getSignedQrCode());
						retailBill.setMessage(billInfo.getErrorDetails());
						retailBill.setIrnFlag(billInfo.getStatus());
						retailBill.setBillToLocation(billInfo.getBuyerLoc());
						// if IRN is successfully generated then call eBill.
						logger.info("== RetailServiceImpl:: saveAdditionalDetails:: billInfo.getStatus(): {} ",
								billInfo.getStatus());

						// Commented: Remove S3DocumentKey check
//					if ((!RetailBillingUtil.isNullOrEmpty(billInfo.getIrn())) && billInfo.getS3DocumentKey() == null) {
						if (!RetailBillingUtil.isNullOrEmpty(billInfo.getIrn())) {
							logger.info(
									"== RetailServiceImpl:: saveAdditionalDetails:: before fusionRetailBillGlIntg: {} ",
									billInfo.getIrn());

							/**
							 * Comment Temporary because Oracle Fusion Integration is stop for now
							 * iReatilOracleFusionService.fusionRetailBillGlIntg();
							 */

							logger.info(
									"== RetailServiceImpl:: saveAdditionalDetails:: After fusionRetailBillGlIntg: {} ",
									billInfo.getIrn());
//						sendEBill(retailBill.getBillId(), "RETAIL_BILL", retailBill.getBillNum());
						} else {
							logger.info(
									"== RetailServiceImpl:: saveAdditionalDetails:: inside else: S3DocumentKey: {} ",
									billInfo.getS3DocumentKey());
						}

					} else {
						if (!RetailBillingUtil.isNullOrEmpty(billInfo.getS3DocumentKey())) {
							retailBill.setS3DocumentKey(billInfo.getS3DocumentKey());
							retailBill.setAttr1(billInfo.getS3BucketName());
							logger.info(
									"== RetailServiceImpl:: saveAdditionalDetails:: else - inside if: billInfo.getS3BucketName(): {} ",
									billInfo.getS3BucketName());
							logger.info("== RetailServiceImpl:: saveAdditionalDetails:: else - inside if: {} ",
									billInfo.getS3DocumentKey());
						}

						logger.info("== RetailServiceImpl:: saveAdditionalDetails:: else - status: {} ",
								billInfo.getStatus());

						Integer emailSentCount = retailBill.getEmailSentCount() != null ? retailBill.getEmailSentCount()
								: 0;
						retailBill.setEmailSentCount(billInfo.isEmailSent() ? emailSentCount + 1 : emailSentCount);
						Integer ackCount = retailBill.getAcknowledgeCount() != null ? retailBill.getAcknowledgeCount()
								: 0;
						retailBill.setAcknowledgeCount(billInfo.isAcknowledged() ? ackCount + 1 : ackCount);
						Integer sendingFailedCount = retailBill.getSendingFailedCount() != null
								? retailBill.getSendingFailedCount()
								: 0;
						retailBill.setSendingFailedCount(
								billInfo.isSendingFailed() ? sendingFailedCount + 1 : sendingFailedCount);
						if (!RetailBillingUtil.isNullOrEmpty(billInfo.getErrorDetails())) {
							retailBill.setMessage(retailBill.getMessage() + "|" + billInfo.getErrorDetails());
							logger.info("== RetailServiceImpl:: inside else: Retail Bill:: {} ",
									retailBill.getMessage());
						}
						logger.info("== RetailServiceImpl:: saveAdditionalDetails::EmailSentCount: {} ",
								retailBill.getEmailSentCount());
						logger.info("== RetailServiceImpl:: saveAdditionalDetails::AcknowledgeCount: {} ",
								retailBill.getAcknowledgeCount());
						logger.info("== RetailServiceImpl:: saveAdditionalDetails::SendingFailedCount: {} ",
								retailBill.getSendingFailedCount());
					}
					// save the details
					retailBillsRepository.save(retailBill);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info("===== RetailServiceImpl:: saveAdditionalDetails:: BillId: {} -- Exception: {} ",
						billInfo.getBillId(), e.getMessage());
				return Constants.FAILURE;
			}
		}
		logger.info("RetailServiceImpl:: saveAdditionalDetails:: SUCCESS");
		return Constants.SUCCESS;
	}

	/**
	 * to send ebill to customer
	 * 
	 * @param documentId     Retail Bill Id
	 * @param documentType   Retail Bill Type
	 * @param documentNumber Retail Bill Number
	 */
	@Async
	private void sendEBill(Long documentId, String documentType, String documentNumber) {
		logger.info("RetailServiceImpl:: Entering sendEBill() ");
		logger.info("RetailServiceImpl:: documentId: {}", documentId);
		logger.info("RetailServiceImpl:: documentType: {}", documentType);
		logger.info("RetailServiceImpl:: documentNumber: {}", documentNumber);
		GenerateEBillRequestDTO generateEBill = new GenerateEBillRequestDTO();
		generateEBill.setDocumentId(documentId);
		generateEBill.setDocumentNumber(documentNumber);
		generateEBill.setDocumentType(documentType);
		generateEBill.setOutputFormat("pdf");
		List<GenerateEBillRequestDTO> ebillList = new ArrayList<>();
		ebillList.add(generateEBill);
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				logger.info("RetailServiceImpl:: Post delay sendEBill() ");
				try {
					HttpEntity<List<GenerateEBillRequestDTO>> entity = new HttpEntity<>(ebillList,
							apiUtil.createBillingServiceHeader());
					// call e-bill API
					String url = eBillServiceUrl + "/reports/v1/generate";
					restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
					logger.info("RetailServiceImpl:: Ebill API called successfully.");
				} catch (Exception ex) {
					ex.printStackTrace();
					logger.info("RetailServiceImpl:: Unexpected exception sending the e-bill: {}",
							ex.getLocalizedMessage());
				}
			}
		}, 15000);

		logger.info("RetailServiceImpl:: Exiting sendEBill() ");

	}

	/*
	 * @Override public Map<String, String> validateInvoice(String invNum, String
	 * gstIn) { RetailBills rb = retailBillsRepository.getBillByNumberandGst(invNum,
	 * gstIn); if (rb != null && rb.getS3DocumentKey() != null) return
	 * Collections.singletonMap(rb.getS3DocumentKey(), rb.getAttr1()); return null;
	 * }
	 */

	/**
	 * New Code B2C & B2B Invoice Download
	 ******************************************************************************/
	@Override
	public Map<String, String> validateInvoice(String invNum, String gstIn) {

		RetailBills rb = new RetailBills();

		if (gstIn != null && gstIn.trim().length() > 0) {
			logger.info("InvoiceDownload -- B2B -- InvNum : {} -- gstIn : {}", invNum, gstIn);
			rb = retailBillsRepository.getBillByNumberWithGst(invNum, gstIn);

		} else {
			logger.info("InvoiceDownload -- B2C -- InvNum : {}", invNum);
			rb = retailBillsRepository.getBillByNumberWithoutGst(invNum);
		}

		if (rb != null && rb.getS3DocumentKey() != null) {
			logger.info("InvoiceDownload InvNum : {} -- S3 DocumentKey : {}", invNum, rb.getS3DocumentKey());
			return Collections.singletonMap(rb.getS3DocumentKey(), rb.getAttr1());
		}

		return null;
	}

	/******************************************************************************************/

	@Override
	@Async
	public void processBatchDetail(List<RetailBillBatchDetails> rbDetailList)
			throws URISyntaxException, CustomException {

		logger.info("RetailBatch:: processBatchDetail:: rbDetailList: size: {} ", rbDetailList.size());
		for (RetailBillBatchDetails rbDetail : rbDetailList) {
			try {
				RetailWaybillResponseDTO retWBResp = retailBillingUtil.callGetWaybillsService(
						Constants.RETAIL_BILLING_SRC_FOR_WB, rbDetail.getRetailBillBatches(), rbDetail,
						Collections.emptyList());
				logger.info("RetailBatch:: processBatchDetail:: BillBatchDetailId: {} ",
						rbDetail.getBillBatchDetailId());

				List<String> errMsgs = new ArrayList<>();
				if (retWBResp != null) {
					RetailErrorDTO[] errArr = retWBResp.getError();
					if (errArr.length > 0) {
						for (int i = 0; i < errArr.length; i++) {
							errMsgs.add(errArr[i].getWaybillNumber() + " : " + errArr[i].getErrorMessage());
							// for logging purpose
							logger.info("RetailBatch:: processBatchDetail: For Error: {} ",
									errArr[i].getWaybillNumber() + " : " + errArr[i].getErrorMessage());
						}
					}
					String processResp = this.processWaybillResponse(retWBResp, rbDetail,
							rbDetail.getRetailBillBatches());
					logger.info("RetailBatch:: processBatchDetail:: processResp: {} -- BillBatchDetailId: {} ",
							processResp, rbDetail.getBillBatchDetailId());
				}

				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				e.printStackTrace();
				logger.info("RetailBatch:: Something Went Wrong while sleep: {} ", e.getMessage());
			}
		}
	}

	@Override
	public List<EInvoiceSearchResponseDTO> getEInvoiceBills(String documentNumber, String billFromDt, String billToDt,
			String gstNumber, String irnFlag) throws CustomException {
		logger.info("RetailServiceImpl:: getEInvoiceBills: documentNumber:  {}", documentNumber);
		logger.info("RetailServiceImpl:: getEInvoiceBills: billFromDt:  {}", billFromDt);
		logger.info("RetailServiceImpl:: getEInvoiceBills: billToDt:  {}", billToDt);
		logger.info("RetailServiceImpl:: getEInvoiceBills: gstNumber:  {}", gstNumber);
		logger.info("RetailServiceImpl:: getEInvoiceBills: irnFlag:  {}", irnFlag);
		List<String> irnFlagList = new ArrayList<>();
		irnFlagList.add(irnFlag);

		if (irnFlagList.contains("ALL")) {
			irnFlagList = new ArrayList<>();
			irnFlagList.add("Y");
			irnFlagList.add("E");
		}
		if (irnFlagList.isEmpty()) {
			throw new CustomException("RetailServiceImpl:: IRN Flag is mandatory.");
		}
		List<RetailBills> data = retailBillsRepository.getInvoiceDetails(
				documentNumber.isEmpty() ? null : documentNumber, billFromDt, billToDt,
				gstNumber.isEmpty() ? null : gstNumber, irnFlagList);
		if (data.isEmpty()) {
			throw new CustomException("No Data Found");
		}
		List<EInvoiceSearchResponseDTO> response = new ArrayList<>();
		for (RetailBills bills : data) {
			String stateCode = "";
			// seller details for Update page
			SellerDtls sellerDtls = new SellerDtls();
			sellerDtls.setGstin(this.sellerGstin);
			sellerDtls.setLglNm(this.sellerLegalName);
			sellerDtls.setTrdNm(this.sellerTradeName);
			sellerDtls.setAddr1(this.sellerAddr1);
			sellerDtls.setAddr2(this.sellerAddr2);
			sellerDtls.setLoc(this.sellerLocation);
			sellerDtls.setPin(this.sellerPincode);
			sellerDtls.setStcd(this.sellerStateCode);
			sellerDtls.setPh(this.sellerPhone);
			sellerDtls.setEm(this.sellerEmail);

			// buyer details for Update page
			BuyerDtls buyerDtls = new BuyerDtls();
			if (bills.getGstNum().isEmpty()) {
				buyerDtls.setGstin("");
				buyerDtls.setStcd("");
			} else {
				buyerDtls.setStcd(bills.getGstNum().substring(0, 2));
				stateCode = bills.getGstNum().substring(0, 2);
				buyerDtls.setGstin(bills.getGstNum());
			}
			// Used the Customer Name as Buyer Legal and Trade Name
			buyerDtls.setLglNm(bills.getBillToCustName());
			buyerDtls.setTrdNm(bills.getBillToCustName());
			buyerDtls.setAddr1(bills.getBillToAddrLine1());
			buyerDtls.setAddr2(bills.getBillToAddrLine2() != null && !"".equals(bills.getBillToAddrLine2().trim())
					? bills.getBillToAddrLine2()
					: null);
			buyerDtls.setAddr3(bills.getBillToAddrLine3());
			buyerDtls.setLoc(bills.getBillToLocation());
			buyerDtls.setPin(bills.getBillToPincode() != null && !"".equals(bills.getBillToPincode())
					? Integer.valueOf(bills.getBillToPincode().replace(" ", ""))
					: 0);

			buyerDtls.setPos(bills.getPlaceOfSupply());
			buyerDtls.setPh("");

			// table response details
			EInvoiceSearchResponseDTO resp = new EInvoiceSearchResponseDTO();

			// these 2 to be used in both search and update page
			resp.setDocumentDate(bills.getBillDt());
			resp.setDocumentNumber(bills.getBillNum());

			resp.setAddress1(bills.getBillToAddrLine1());
			resp.setAddress2(bills.getBillToAddrLine2());
			resp.setAddress3(bills.getBillToAddrLine3());
			resp.setCgst(bills.getCgstAmt());
			resp.setIgst(bills.getIgstAmt());
			resp.setSgst(bills.getSgstAmt());
			resp.setCustomerName(bills.getBillToCustName());
			resp.setDocumentId(bills.getBillId());

			String message = bills.getMessage();
			StringBuffer sb = new StringBuffer();

			// Setting ErrorMessage only for 'E' IRN-flag
			if ("E".equalsIgnoreCase(bills.getIrnFlag())) {
				List<ErrorResponse> errors = retailBillingUtil.convertStringToJson(message);
				for (ErrorResponse err : errors) {
					if (sb.length() > 0)
						sb.append(", " + err.getErrorMessage());
					sb.append(err.getErrorMessage());
				}
				resp.setErrorMessage(sb.toString());
			}
			resp.setIrnStatus(bills.getIrnFlag().equalsIgnoreCase("E") ? "Failed" : "Success");
			resp.setLocation(bills.getBillToLocation());
			resp.setPincode(bills.getBillToPincode());
			resp.setParentBillNumber(null);
			resp.setStateCode(stateCode);

			resp.setBuyerDetails(buyerDtls);
			resp.setSellerDetails(sellerDtls);

			resp.setBaseAmt(bills.getBaseAmt());

			response.add(resp);
		}
		return response;
	}

	/**
	 * @Description Get Retail Bills for Einvoice
	 * @return
	 * @throws CustomException
	 */
	public List<EInvoiceSearchResponseDTO> getEInvoiceBills(List<EInvoiceBulkSearchDTO> bulkSearch)
			throws CustomException {
		// fetch by document number
		logger.info("=== RetailServiceImpl:: getEInvoiceBills ===");
		List<EInvoiceSearchResponseDTO> response = new ArrayList<>();
		for (EInvoiceBulkSearchDTO invoice : bulkSearch) {
			List<RetailBills> data = retailBillsRepository.findByBillNum(invoice.getDocumentNumber());
			if (data.isEmpty()) {
				EInvoiceSearchResponseDTO resp = new EInvoiceSearchResponseDTO();
				resp.setDocumentNumber(invoice.getDocumentNumber());
				resp.setErrorMessage("Bill Not found in database");
				response.add(resp);
			} else {
				for (RetailBills bills : data) {
					String stateCode = "";
					// seller details for Update page
					SellerDtls sellerDtls = new SellerDtls();
					sellerDtls.setGstin(this.sellerGstin);
					sellerDtls.setLglNm(this.sellerLegalName);
					sellerDtls.setTrdNm(this.sellerTradeName);
					sellerDtls.setAddr1(this.sellerAddr1);
					sellerDtls.setAddr2(this.sellerAddr2);
					sellerDtls.setLoc(this.sellerLocation);
					sellerDtls.setPin(this.sellerPincode);
					sellerDtls.setStcd(this.sellerStateCode);

					// buyer details for Update page
					BuyerDtls buyerDtls = new BuyerDtls();
					if (bills.getGstNum().isEmpty()) {
						buyerDtls.setGstin("");
						buyerDtls.setStcd("");
					} else {
						buyerDtls.setStcd(bills.getGstNum().substring(0, 2));
						stateCode = bills.getGstNum().substring(0, 2);
						buyerDtls.setGstin(bills.getGstNum());
					}
					// Used the Customer Name as Buyer Legal and Trade Name
					buyerDtls.setLglNm(bills.getBillToCustName());
					buyerDtls.setTrdNm(bills.getBillToCustName());
					buyerDtls.setAddr1(bills.getBillToAddrLine1());
					buyerDtls.setAddr2(
							bills.getBillToAddrLine2() != null && !"".equals(bills.getBillToAddrLine2().trim())
									? bills.getBillToAddrLine2()
									: null);
					buyerDtls.setAddr3(bills.getBillToAddrLine3());
					buyerDtls.setLoc(bills.getBillToLocation());
					buyerDtls.setPin(bills.getBillToPincode() != null && !"".equals(bills.getBillToPincode())
							? Integer.valueOf(bills.getBillToPincode().replace(" ", ""))
							: 0);

					buyerDtls.setPos(bills.getPlaceOfSupply());
					buyerDtls.setPh("");

					// table response details
					EInvoiceSearchResponseDTO resp = new EInvoiceSearchResponseDTO();
					// these 2 to be used in both search and update page
					resp.setDocumentDate(bills.getBillDt());
					resp.setDocumentNumber(bills.getBillNum());
					resp.setAddress1(bills.getBillToAddrLine1());
					resp.setAddress2(bills.getBillToAddrLine2());
					resp.setAddress3(bills.getBillToAddrLine3());
					resp.setCgst(bills.getCgstAmt());
					resp.setIgst(bills.getIgstAmt());
					resp.setSgst(bills.getSgstAmt());
					resp.setCustomerName(bills.getBillToCustName());
					resp.setDocumentId(bills.getBillId());

					String message = bills.getMessage();
					StringBuffer sb = new StringBuffer();

					// Setting ErrorMessage only for 'E' IRN-flag
					if ("E".equalsIgnoreCase(bills.getIrnFlag())) {
						List<ErrorResponse> errors = retailBillingUtil.convertStringToJson(message);
						for (ErrorResponse err : errors) {
							if (sb.length() > 0)
								sb.append(", " + err.getErrorMessage());
							sb.append(err.getErrorMessage());
						}
						resp.setErrorMessage(sb.toString());
					}
					resp.setIrnStatus(bills.getIrnFlag() != null && bills.getIrnFlag().equalsIgnoreCase("E") ? "Failed"
							: (bills.getIrnFlag() == null ? "Pending for IRN Generation" : "Success"));
					resp.setLocation(bills.getBillToLocation());
					resp.setPincode(bills.getBillToPincode());
					resp.setParentBillNumber(null);
					resp.setStateCode(stateCode);
					resp.setBuyerDetails(buyerDtls);
					resp.setSellerDetails(sellerDtls);
					resp.setBaseAmt(bills.getBaseAmt());
					response.add(resp);
				}
			}
		}
		return response;
	}

	@Override
	public String updateEinvBulkBills(List<EInvoiceUpdateRequestDTO> updateDetails) throws CustomException {
		logger.info("=== RetailServiceImpl:: updateEinvBulkBills ===");
		for (EInvoiceUpdateRequestDTO invDetails : updateDetails) {
			/**
			 * Below code is commented because of could not initialize proxy error
			 **/
//			RetailBills retailBill = retailBillsRepository.getOne(invDetails.getDocumentId());
			RetailBills retailBill = retailBillsRepository.getNewBillsById(invDetails.getDocumentId());
			if (invDetails.getB2C()) {
				retailBill.setGstNum(null);
				retailBill.setMessage("Invoice has been made to b2C, therefore Gst-Number "
						+ invDetails.getBuyerDetails().getGstin() + " has been set to Null");
				retailBillsRepository.save(retailBill);
			} else {
				if (retailBill.getIrn() == null || retailBill.getIrn().equals("")) {
					retailBill.setGstNum(invDetails.getBuyerDetails().getGstin());
					retailBill.setBillToAddrLine1(invDetails.getBuyerDetails().getAddr1());
					retailBill.setBillToAddrLine2(invDetails.getBuyerDetails().getAddr2());
					retailBill.setBillToAddrLine3(invDetails.getBuyerDetails().getAddr3());
					retailBill.setBillToLocation(invDetails.getBuyerDetails().getLoc());
					retailBill.setBillToPincode(String.valueOf(invDetails.getBuyerDetails().getPin()));
					retailBill.setBillToState(invDetails.getBuyerDetails().getStcd());

					retailBill.setBillToCustName(invDetails.getBuyerDetails().lglNm);
					retailBill.setIrnFlag(null);
					// retailBill.setBillDt(invDetails.getDocumentDate());
					retailBill.setPlaceOfSupply(invDetails.getBuyerDetails().getPos());
					// check if whether tax to be applied is igst or sgst/cgst.
					if (retailBill.getBillToState() != null
							&& retailBill.getBillToState().equalsIgnoreCase(this.sellerStateCode)) {
						// CGST and iGST is applicable.
						if (null != retailBill.getIgstAmt() && retailBill.getIgstAmt() > 0) {
							Double cgst = roundToDecimals((retailBill.getIgstAmt() / 2), 2);
							Double sgst = roundToDecimals((retailBill.getIgstAmt() / 2), 2);
							retailBill.setCgstAmt(cgst);
							retailBill.setSgstAmt(sgst);
							retailBill.setIgstAmt(Double.valueOf(0));
							retailBill.setTtlTaxAmt(cgst + sgst);
							retailBill.setOracleTaxRate("9");
							retailBill.setOracleTaxRateCode("CGST STD_9");
						}
					}
					if (retailBill.getBillToState() != null
							&& !retailBill.getBillToState().equalsIgnoreCase(this.sellerStateCode)) {
						if (null != retailBill.getCgstAmt() && retailBill.getCgstAmt() > 0) {
							retailBill.setIgstAmt(retailBill.getSgstAmt() + retailBill.getCgstAmt());
							retailBill.setCgstAmt(Double.valueOf(0));
							retailBill.setSgstAmt(Double.valueOf(0));
							retailBill.setOracleTaxRate("18");
							retailBill.setOracleTaxRateCode("IGST STD_18");
						}
					}
					retailBillsRepository.save(retailBill);
				}
			}
		}
		return "Successfully Updated";
	}

	public static Double roundToDecimals(Double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	@Override
	public CompletableFuture<Void> asyncUpdateToOracleGL() {
		List<String> status = new ArrayList<>();
		status.add("INSERTED");
		status.add("ERROR");
		iReatilOracleFusionService.fusionRetailBillGlIntegration(status);
		return CompletableFuture.completedFuture(null);
	}

	@Override
	public void sendNotificationForFailedGL() {
		logger.info("=== RetailServiceImpl:: sendNotificationForFailedGL ===");
		List<RetailBillIntegrations> retailBillsIntegrationsList = iRetailBillIntegrationsRepository
				.getBillsIntegrationsByStatus(Constants.ERROR_STATUS);

		if (!retailBillsIntegrationsList.isEmpty()) {
			String emailHeader = "Retail Bills are not update to Oracle GL. Below are the Retail bills list details.";
			String buf = retailBillingUtil.retailBillsIntegrationListToString(retailBillsIntegrationsList, emailHeader);
			notificationUtility.sendNotification("Retail Billing: Error report for failed transaction to Oracle GL",
					buf);
		}
	}

	/**
	 * method to re-process send mail for Retail Bills
	 * 
	 * @return Nothing
	 * @param Nothing
	 * @throws URISyntaxException
	 * @throws CustomException
	 */

	@Async
	@Override
	public CompletableFuture<Void> resendRetailMails() {
		logger.info("=== ResendRetailMails:: RetailServiceImpl:: resendRetailMails ===");
		String respStatus = Constants.FAILURE;
		// Case 1 if S3documentKey is not null, just to send email

		// List<RetailBills> retailBillsList =
		// retailBillsRepository.getEligibleRetailBills(); // old query here for
		// reference
		// List<RetailBills> retailBillsList = new ArrayList<>();

		List<RetailBills> retailBillsList = retailBillsRepository.getB2BEligibleRetailBills();

		/**
		 * For Testing //List<RetailBills> retailB2BBillsList =
		 * retailBillsRepository.getB2BEligibleRetailBillsTest();
		 **/

		/**
		 * Below code can be use if business want to send mail to B2C Customer
		 * logger.info("ResendRetailMails:: RetailServiceImpl:: retailB2BBillsList Size:
		 * {} ", retailB2BBillsList.size()); List<RetailBills> retailB2CBillsList =
		 * retailBillsRepository.getB2CEligibleRetailBills(); List<RetailBills>
		 * retailB2CBillsList = retailBillsRepository.getB2CEligibleRetailBillsTest();
		 * logger.info("ResendRetailMails:: RetailServiceImpl:: retailB2CBillsList Size:
		 * {} ", retailB2CBillsList.size());
		 */

//		retailBillsList.addAll(retailB2BBillsList);
//		retailBillsList.addAll(retailB2CBillsList);

		logger.info("ResendRetailMails:: RetailServiceImpl:: retailBillsList Size: {} ", retailBillsList.size());

		List<RetailBillsDTO> retailBillsDTOList = new ArrayList<>();
		retailBillsList.forEach(retailBills -> {
			RetailBillsDTO retailBillsDTO = new RetailBillsDTO();
			BeanUtils.copyProperties(retailBills, retailBillsDTO);
			retailBillsDTOList.add(retailBillsDTO);
		});

		logger.info("ResendRetailMails:: RetailServiceImpl:: retailBillsDTOList Size: {} ", retailBillsDTOList.size());

		try {
			if (!retailBillsDTOList.isEmpty()) {

				HttpEntity<List<RetailBillsDTO>> entity = new HttpEntity<>(retailBillsDTOList,
						apiUtil.createBillingServiceHeader());
				// call e-bill API
				String url = eBillServiceUrl + "/reports/v1/retail/email";
				restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				logger.info("ResendRetailMails:: RetailServiceImpl:: Ebill API called successfully.");
				respStatus = Constants.SUCCESS;
			} else {
				logger.info("=== ResendRetailMails:: RetailServiceImpl:: No Data Found for Email.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("=== ResendRetailMails:: RetailServiceImpl:: Error: {}", e.getMessage());
		}
		logger.info("=== ResendRetailMails:: RetailServiceImpl:: respStatus: {} ", respStatus);
		return CompletableFuture.completedFuture(null);
	}

	@Override
	public String updateRetailBillsEmailDetails(List<BillAdditionalInfoDTO> additionalInfo) {
		logger.info("===== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails ==========  ");
		String status = Constants.FAILURE;
		try {

			for (BillAdditionalInfoDTO billInfo : additionalInfo) {
				// fetch the retail bill
				logger.info("===== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails:: BillId: {}",
						billInfo.getBillId());
				logger.info("===== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails:: Source: {}",
						billInfo.getSource());
				/**
				 * Below code is commented because of could not initialize proxy error
				 **/
//				RetailBills retailBill = retailBillsRepository.getOne(billInfo.getBillId());
				RetailBills retailBill = retailBillsRepository.getNewBillsById(billInfo.getBillId());
				if (retailBill != null) {

//						if (!RetailBillingUtil.isNullOrEmpty(billInfo.getS3DocumentKey())) {
//							retailBill.setS3DocumentKey(billInfo.getS3DocumentKey());
//							retailBill.setAttr1(billInfo.getS3BucketName());
//							logger.info("== RetailServiceImpl:: saveAdditionalDetails:: else - inside if: billInfo.getS3BucketName(): {} ", billInfo.getS3BucketName());
//							logger.info("== RetailServiceImpl:: saveAdditionalDetails:: else - inside if: {} ", billInfo.getS3DocumentKey());
//						}

					logger.info("== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails:: - status: {} ",
							billInfo.getStatus());

					if (retailBill.getSendingFailedCount() != null && retailBill.getSendingFailedCount() > 3) {
						Integer emailSentCount = -9;
						retailBill.setEmailSentCount(emailSentCount);

						Integer sendingFailedCount = retailBill.getSendingFailedCount() != null
								? retailBill.getSendingFailedCount()
								: 0;
						retailBill.setSendingFailedCount(sendingFailedCount);

					} else {

						Integer emailSentCount = retailBill.getEmailSentCount() != null ? retailBill.getEmailSentCount()
								: 0;
						retailBill.setEmailSentCount(billInfo.isEmailSent() ? emailSentCount + 1 : emailSentCount);

						Integer sendingFailedCount = retailBill.getSendingFailedCount() != null
								? retailBill.getSendingFailedCount()
								: 0;
						retailBill.setSendingFailedCount(
								billInfo.isSendingFailed() ? sendingFailedCount + 1 : sendingFailedCount);

					}
					if (!RetailBillingUtil.isNullOrEmpty(billInfo.getErrorDetails())) {
						retailBill.setMessage(
								(retailBill.getMessage() != null ? retailBill.getMessage() + "|" : "").trim()
										+ billInfo.getErrorDetails());
						logger.info("== ResendRetailMails:: RetailServiceImpl:: inside else: Retail Bill:: {} ",
								retailBill.getMessage());
					}
					logger.info("== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails::EmailSentCount: {} ",
							retailBill.getEmailSentCount());
					logger.info(
							"== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails::AcknowledgeCount: {} ",
							retailBill.getAcknowledgeCount());
					logger.info(
							"== ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails::SendingFailedCount: {} ",
							retailBill.getSendingFailedCount());
				}
				// save the details
				retailBill.setUpdBy(billingAdminUser);
				retailBill.setUpdDt(LocalDateTime.now());
				retailBillsRepository.save(retailBill);
			}
			status = Constants.SUCCESS;
		} catch (Exception ex) {
			logger.info("ResendRetailMails:: RetailServiceImpl:: saveAdditionalDetails:: Exception:  {}",
					ex.getMessage());
			status = Constants.FAILURE;
		}
		logger.info("RetailServiceImpl:: saveAdditionalDetails:: {} ", status);

		return status;
	}

	/// Reprocess EReport Generation
	/**
	 * method to re-process EReportGeneration for Retail Bills
	 * 
	 * @return Nothing
	 * @param Nothing
	 * @throws URISyntaxException
	 * @throws CustomException
	 */

	@Async
	@Override
	public CompletableFuture<Void> reprocessEReportGeneration() {
		logger.info("=== Reprocess EReportGeneration:: RetailServiceImpl:: reprocessEReportGeneration ===");
		String respStatus = Constants.FAILURE;
		// Case 2 if S3documentKey is null, then generate pdf and upload in s3 and
		// update s3 key and bucket name in db

		// List<RetailBills> retailBillsList =
		// retailBillsRepository.getEligibleIRNRetailBills();

		List<RetailBills> retailBillsList = new ArrayList<>();
		List<RetailBills> retailB2BBillsList = retailBillsRepository.getB2BEligibleIRNRetailBills();

//		List<RetailBills> retailB2BBillsList = retailBillsRepository.getB2BEligibleIRNRetailBillsTest();

		logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: retailB2BBillsList Size: {} ",
				retailB2BBillsList.size());

		List<RetailBills> retailB2CBillsList = retailBillsRepository.getB2CEligibleWithoutIRNRetailBills();

//		List<RetailBills> retailB2CBillsList = retailBillsRepository.getB2CEligibleWithoutIRNRetailBillsTest();

		logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: retailB2CBillsList Size: {} ",
				retailB2CBillsList.size());

		retailBillsList.addAll(retailB2BBillsList);
		if (!retailB2CBillsList.isEmpty()) {
			retailBillsList.addAll(retailB2CBillsList);
		}

		logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: retailBillsList Size: {} ",
				retailBillsList.size());

		List<RetailBillsDTO> retailBillsDTOList = new ArrayList<>();
		retailBillsList.forEach(retailBills -> {
			RetailBillsDTO retailBillsDTO = new RetailBillsDTO();
			BeanUtils.copyProperties(retailBills, retailBillsDTO);
			retailBillsDTOList.add(retailBillsDTO);
		});

		logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: retailBillsDTOList Size: {} ",
				retailBillsDTOList.size());

		try {
			if (!retailBillsDTOList.isEmpty()) {

				HttpEntity<List<RetailBillsDTO>> entity = new HttpEntity<>(retailBillsDTOList,
						apiUtil.createBillingServiceHeader());
				// call e-bill API
				String url = eBillServiceUrl + "/reports/v1/reprocess/retailbills";
				restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: Ebill API called successfully.");
				respStatus = Constants.SUCCESS;
			} else {
				logger.info(
						"=== Reprocess EReportGeneration:: RetailServiceImpl:: No Data Found for Retail Bill Reports.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("=== Reprocess EReportGeneration:: RetailServiceImpl:: Error: {}", e.getMessage());
		}
		logger.info("=== Reprocess EReportGeneration:: RetailServiceImpl:: respStatus: {} ", respStatus);
		return CompletableFuture.completedFuture(null);
	}

	@Override
	public String updateRetailBillsReportGen(List<BillAdditionalInfoDTO> additionalInfo) {
		logger.info("===== Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen ==========  ");
		String status = Constants.FAILURE;
		try {

			for (BillAdditionalInfoDTO billInfo : additionalInfo) {
				// fetch the retail bill
				if (billInfo.getBillId() != null) {
					logger.info(
							"===== Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen:: BillId: {}",
							billInfo.getBillId());
					logger.info(
							"===== Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen:: Source: {}",
							billInfo.getSource());

					/**
					 * Below code is commented because of could not initialize proxy error
					 **/
//					 RetailBills retailBill = retailBillsRepository.getOne(billInfo.getBillId());
					RetailBills retailBill = retailBillsRepository.getNewBillsById(billInfo.getBillId());

					logger.info(
							"== Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen:: else - status: {} ",
							billInfo.getStatus());

					retailBill.setS3DocumentKey(billInfo.getS3DocumentKey());
					retailBill.setAttr1(billInfo.getS3BucketName());

					Integer emailSentCount = 0;
					retailBill.setEmailSentCount(emailSentCount);

					Integer sendingFailedCount = 0;
					retailBill.setSendingFailedCount(sendingFailedCount);

					if (!RetailBillingUtil.isNullOrEmpty(billInfo.getErrorDetails())) {
						retailBill.setMessage(retailBill.getMessage() + "|" + billInfo.getErrorDetails());
						logger.info(
								"== Reprocess EReportGeneration:: RetailServiceImpl:: inside else: Retail Bill:: {} ",
								retailBill.getMessage());
					}
					logger.info("== Reprocess EReportGeneration:: RetailServiceImpl:: S3DocumentKey: {} ",
							billInfo.getS3DocumentKey());
					logger.info("== Reprocess EReportGeneration:: RetailServiceImpl:: S3BucketName: {} ",
							billInfo.getS3BucketName());
					// save the details
					retailBill.setUpdBy(billingAdminUser);
					retailBill.setUpdDt(LocalDateTime.now());
					retailBillsRepository.save(retailBill);
				} else {
					logger.info(
							"===== Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen:: Retail BillId is coming Null.");
				}

			}
			status = Constants.SUCCESS;
		} catch (Exception ex) {
			logger.info("Reprocess EReportGeneration:: RetailServiceImpl:: updateRetailBillsReportGen:: Exception:  {}",
					ex.getMessage());
			status = Constants.FAILURE;
		}
		logger.info("Reprocess EReportGeneration:: updateRetailBillsReportGen:: {} ", status);
		return status;
	}

	/**
	 * Method to Create Retail Bills to Save in DB
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wayBillList
	 * @param billCtgy
	 * @throws CustomException
	 */
	@Transactional
	private RetailBills saveRetailBill(RetailBillBatches retailBillBatches, Long batchDetailId,
			RetailBillBatchDetails batchDetail, List<RetailWaybillDTO> wayBillList, String billCtgy) {

		logger.info("=== RetailBatch:: RetailServiceImpl:: createRetailBill === waybill count: {} ",
				(wayBillList != null ? wayBillList.size() : 0));
		logger.info("RetailBatch:: RetailServiceImpl:: Start Create Bill: batchDetailId: {} ", batchDetailId);
		RetailBills bills = new RetailBills();
		try {
			double sumOutStanding = 0;
			double sumBaseAmt = 0;
			double sumTtlTaxAmt = 0;
			double sumIgstAmt = 0;
			double sumCgstAmt = 0;
			double sumSgstAmt = 0;
			Long blngBrId;
			for (RetailWaybillDTO waybill : wayBillList) {
				sumOutStanding = sumOutStanding + waybill.getOutstandingAmount();
				sumBaseAmt = sumBaseAmt + waybill.getBaseAmount();
				sumTtlTaxAmt = sumTtlTaxAmt + waybill.getTtlTaxAmount();
				sumIgstAmt = sumIgstAmt + waybill.getIgstAmount();
				sumCgstAmt = sumCgstAmt + waybill.getCgstAmount();
				sumSgstAmt = sumSgstAmt + waybill.getSgstAmount();
				logger.info(
						"RetailBatch:: RetailServiceImpl:: Start Create Bill: batchDetailId: {} -- Waybill Number: {} ",
						batchDetailId, waybill.getWaybillNumber());
			}
			// Rounded Double Values
			Double doubleSumOutStanding = Double.valueOf(Math.round(sumOutStanding * 100) / 100.0);
			Double doubleSumBaseAmt = Double.valueOf(Math.round(sumBaseAmt * 100) / 100.0);
			Double doubleSumTtlTaxAmt = Double.valueOf(Math.round(sumTtlTaxAmt * 100) / 100.0);
			Double doubleSumIgstAmt = Double.valueOf(Math.round(sumIgstAmt * 100) / 100.0);
			Double doubleSumCgstAmt = Double.valueOf(Math.round(sumCgstAmt * 100) / 100.0);
			Double doubleSumSgstAmt = Double.valueOf(Math.round(sumCgstAmt * 100) / 100.0);

			if ("Y".equals(batchDetail.getPaidFlag())) {
				blngBrId = wayBillList.get(0).getBkgBrId();
				bills.setBlngBrId(wayBillList.get(0).getBkgBrId());
				bills.setBlngBr(wayBillList.get(0).getBkgBr());
				bills.setCollBr(wayBillList.get(0).getBkgBr());
				bills.setCollBrId(wayBillList.get(0).getBkgBrId());
				bills.setSubmsnBr(wayBillList.get(0).getBkgBr());
				bills.setSubmsnBrId(wayBillList.get(0).getBkgBrId());
				bills.setBillType(Constants.PAID_VALUE);
			} else {
				blngBrId = wayBillList.get(0).getDeliveryBrId();
				bills.setBlngBrId(wayBillList.get(0).getDeliveryBrId());
				bills.setBlngBr(wayBillList.get(0).getDeliveryBr());
				bills.setCollBr(wayBillList.get(0).getDeliveryBr());
				bills.setCollBrId(wayBillList.get(0).getDeliveryBrId());
				bills.setSubmsnBr(wayBillList.get(0).getDeliveryBr());
				bills.setSubmsnBrId(wayBillList.get(0).getDeliveryBrId());
				bills.setBillType(Constants.TOPAY_VALUE);
			}

			if ("Y".equals(batchDetail.getGstFlag())) {
				String taxRateCode = this.getTaxRateCode(wayBillList.get(0).getGstNum(), blngBrId);
				bills.setOracleTaxRate(this.getTaxRatebyCode(taxRateCode));
				bills.setOracleTaxRateCode(taxRateCode);
				if (oracleIgst.equals(taxRateCode)) {
					bills.setIgstAmt(doubleSumIgstAmt);
					if (doubleSumIgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
						doubleSumOutStanding = doubleSumIgstAmt + doubleSumBaseAmt;
					}
				} else if (oracleCgst.equals(taxRateCode)) {
					bills.setCgstAmt(doubleSumCgstAmt);
					bills.setSgstAmt(doubleSumSgstAmt);
					if (doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
						doubleSumOutStanding = doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt;
					}
				}
			}

			/**
			 * For B2C Changes
			 ***********************************************************************************/
			else {

				String taxRateCode = this.getTaxRateCodeB2C(blngBrId);
				bills.setOracleTaxRate(this.getTaxRatebyCode(taxRateCode));
				bills.setOracleTaxRateCode(taxRateCode);
				if (oracleIgst.equals(taxRateCode)) {
					bills.setIgstAmt(doubleSumIgstAmt);
					if (doubleSumIgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
						doubleSumOutStanding = doubleSumIgstAmt + doubleSumBaseAmt;
					}
				} else if (oracleCgst.equals(taxRateCode)) {
					bills.setCgstAmt(doubleSumCgstAmt);
					bills.setSgstAmt(doubleSumSgstAmt);
					if (doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt != doubleSumOutStanding) {
						doubleSumOutStanding = doubleSumCgstAmt + doubleSumSgstAmt + doubleSumBaseAmt;
					}
				}
			}

			/******************************************************************************************************/

			bills.setBillToEmail(wayBillList.get(0).getBillToEmail());
			bills.setBillToCustName(wayBillList.get(0).getBillToCustomer());
			bills.setBillToLocation(wayBillList.get(0).getBillToLocation());
			bills.setBillToPincode(wayBillList.get(0).getBillToPincode());
			bills.setBillToAddr(wayBillList.get(0).getBillToAddr());
			bills.setBillToAddrLine1(wayBillList.get(0).getBillToAddr());
			bills.setBillBatchDetailId(batchDetailId);
			bills.setRetailBillBatches(retailBillBatches);
			bills.setPrcId(wayBillList.get(0).getPrcId());
			bills.setPrcCode(wayBillList.get(0).getPrcCode());
			bills.setBillCtgy(billCtgy);
			bills.setGstNum(wayBillList.get(0).getGstNum());
			bills.setConsigneeId(wayBillList.get(0).getConsigneeId());
			bills.setConsigneeName(wayBillList.get(0).getConsigneeName());
			bills.setConsignerId(wayBillList.get(0).getConsignerId());
			bills.setConsignerName(wayBillList.get(0).getConsignerName());
			bills.setStatus("FINALIZED");

//          Old Code
//			bills.setBillDt(new Date());

			if (billCtgy.equalsIgnoreCase(Constants.getRetailBillB2BCtgy())) {
//				/** New Code */
//				Calendar calender = Calendar.getInstance();
//				calender.add(Calendar.DATE, Long.valueOf(-retailb2bDays).intValue());
//				bills.setBillDt(calender.getTime());
//
//				logger.info(
//						"RetailBatch:: RetailServiceImpl:: Create Bill: batchDetailId: {} - CrDt: {} - BillDate: {} - BillCtgy: {}",
//						batchDetailId, new Date(), calender.getTime(), billCtgy);
//
//				bills.setBillNum(this.getNextBillNumRetail(calender));
//
//				/************************************************/
				
               /** Changes https://safexpress.atlassian.net/browse/PAD-501 */
				
				if ("Y".equals(batchDetail.getPrcFlag())) {
					
					/** New Code */
					Calendar calender = Calendar.getInstance();
					calender.add(Calendar.DATE, Long.valueOf(-retailb2bDays).intValue());
					bills.setBillDt(calender.getTime());
	
					logger.info(
							"RetailBatch:: RetailServiceImpl:: PRC -- Create Bill: batchDetailId: {} - CrDt: {} - BillDate: {} - BillCtgy: {}",
							batchDetailId, new Date(), calender.getTime(), billCtgy);
	
					bills.setBillNum(this.getNextBillNumRetail(calender));
					
				} else {

					if ("Y".equals(batchDetail.getPaidFlag())) {
						/** New Code */
	
						bills.setBillDt(wayBillList.get(0).getPickupDate());
	
						logger.info(
								"RetailBatch:: RetailServiceImpl:: Paid - Non PRC - Create Bill: batchDetailId: {} - CrDt: {} - BillDate: {} - BillCtgy: {}",
								batchDetailId, new Date(), bills.getBillDt(), billCtgy);
	
						bills.setBillNum(this.getNextSSPBillNum(bills.getBillDt()));
	
					} else {
						
						bills.setBillDt(wayBillList.get(0).getDelieveryDate());
	
						logger.info(
								"RetailBatch:: RetailServiceImpl:: Topay - Non PRC - Create Bill: batchDetailId: {} - CrDt: {} - BillDate: {} - BillCtgy: {}",
								batchDetailId, new Date(), bills.getBillDt(), billCtgy);
	
						bills.setBillNum(this.getNextSSPBillNum(bills.getBillDt()));
						
					}
					
				}
				
				/***********************************************************/

				/** For B2C Bill Date - last date of month */
			} else if (billCtgy.equalsIgnoreCase(Constants.getRetailBillB2CCtgy())) {

				Calendar calender2 = Calendar.getInstance();
				calender2.add(Calendar.MONTH, -1);
				calender2.set(Calendar.DAY_OF_MONTH, calender2.getActualMaximum(Calendar.DAY_OF_MONTH));

				bills.setBillDt(calender2.getTime());

				logger.info(
						"RetailBatch:: RetailServiceImpl:: Create Bill: batchDetailId: {} - CrDt: {} - BillDate: {} - BillCtgy: {}",
						batchDetailId, new Date(), retailBillingUtil.getB2CBillDate(), billCtgy);

				bills.setBillNum(this.getNextBillNumRetail(calender2));

			}

			bills.setBaseAmt(doubleSumBaseAmt);
			bills.setTtlTaxAmt(doubleSumTtlTaxAmt);
			bills.setOutstandingAmt(doubleSumOutStanding);
			bills.setActualOutstandingAmt(doubleSumOutStanding);
			logger.info("RetailBatch:: RetailServiceImpl:: Create Bill: BillNum: {} -- batchDetailId: {} ",
					bills.getBillNum(), batchDetailId);

//			Gson g = new Gson();
//			logger.info("RetailBatch:: RetailBillingUtil - before save bills - Get Waybill Payload -- {}", g.toJson(bills));

			try {
				bills = retailBillsRepository.save(bills);

			} catch (Exception e) {
				e.printStackTrace();
				TimeUnit.SECONDS.sleep(1);
				logger.info(
						"initateBatchCreation:: Retry generating Bill when getting Constraint or other Exception: {} ",
						e.getMessage());
				bills = retailBillsRepository.save(bills);
			}

//			logger.info("RetailBatch:: RetailBillingUtil - after save bills - Get Waybill Payload -- {}", g.toJson(bills));

			Long billid = bills.getBillId();
			String newBillNumber = bills.getBillNum();

			newBillNumber = getUpdRetailBillNumber(billid, newBillNumber);
			logger.info("RetailBatch:: RetailServiceImpl:: New Create Bill: BillNum: {} -- batchDetailId: {} ",
					newBillNumber, batchDetailId);

			bills.setBillNum(newBillNumber);
//			logger.info("RetailBatch:: RetailBillingUtil - updated bills - Get Waybill Payload -- {}", g.toJson(bills));
			logger.info("RetailBatch:: RetailServiceImpl:: New Create Bill: BillNum1: {} -- batchDetailId: {} ",
					bills.getBillNum(), batchDetailId);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("RetailBatch:: RetailServiceImpl:: saveRetailBill: batchDetailId: {}: Exception {} ",
					batchDetailId, e.getMessage());
			return bills;
		}
		return bills;
	}

	/**
	 * Method to Mark Cancel Retail Bills in DB When got any exception
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wayBillList
	 * @param billCtgy
	 * @throws CustomException
	 */
	@Transactional
	private RetailBills cancelRetailBill(RetailBills newRetailBills) {
		logger.info("RetailBatch:: RetailServiceImpl:: cancelRetailBill: BillNum: {} ", newRetailBills.getBillNum());
		newRetailBills.setStatus("CANCELLED");
		newRetailBills.setIrnFlag("C");
		newRetailBills.setUpdBy(Constants.getBillingAdminUser());

		Date today = new Date();
		LocalDateTime ldt = LocalDateTime.ofInstant(today.toInstant(), ZoneId.systemDefault());
		newRetailBills.setUpdDt(ldt);
		retailBillsRepository.save(newRetailBills);
		return newRetailBills;

	}

	/**
	 * Method to get New Retail Bills Number in DB
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wayBillList
	 * @param billCtgy
	 * @throws CustomException
	 */
	private String getUpdRetailBillNumber(Long billid, String newBillNumber) {

		logger.info("RetailBatch:: RetailBillingUtil - to get new BillNumber - billid-- {}", billid);
		String customisedQuery = "SELECT rb.bill_num from bil_retail.retail_bills rb where rb.bill_id  = " + billid;

		Query query = entityManager.createNativeQuery(customisedQuery);
		List<Object> list = query.getResultList();
		logger.info("RetailBatch:: RetailBillingUtil - BillNumber to be update - newBillNumber-- {}", newBillNumber);

		for (Object result : list) {

			if (result != null) {
				newBillNumber = String.valueOf(result);
				logger.info("RetailBatch:: RetailServiceImpl::result:newBillNumber: {} ", newBillNumber);
			}

		}
		return newBillNumber;

	}

	/**
	 * Method to get New SSP Retail Bills Number in DB
	 * 
	 * @param batchId
	 * @param batchDetailId
	 * @param wayBillList
	 * @param billCtgy
	 * @throws CustomException
	 */
	private String getUpdRetailBillNumberSSP(Long billid, String newBillNumber) {

		logger.info(
				"RetailServiceImpl -- createRetailBillforSSP -- getUpdRetailBillNumber -- to get new BillNumber - billid-- {}",
				billid);
		String customisedQuery = "SELECT rb.bill_num from bil_retail.retail_bills rb where rb.bill_id  = " + billid;

		Query query = entityManager.createNativeQuery(customisedQuery);
		List<Object> list = query.getResultList();
		logger.info(
				"RetailServiceImpl -- createRetailBillforSSP -- getUpdRetailBillNumber -- BillNumber to be update - newBillNumber-- {}",
				newBillNumber);

		for (Object result : list) {
			if (result != null) {
				newBillNumber = String.valueOf(result);
				logger.info(
						"RetailServiceImpl -- createRetailBillforSSP -- getUpdRetailBillNumber -- result:newBillNumber: {} ",
						newBillNumber);
			}
		}
		return newBillNumber;

	}

	@Override
	public List<BillResponseDTO> getBillSourceDetails(BillInformationDTO billInfoDTO) throws CustomException {

		List<Object[]> data = retailBillsRepository.getSourceByBillNum(billInfoDTO.getBillNum());
		List<BillSourceDTO> billSourceList = new ArrayList<>();

		List<BillResponseDTO> billResList= new ArrayList<>();
//		BillResponseDTO billResponse = new BillResponseDTO();

		List<String> resList= new ArrayList<>();
		
			for (Object[] obj : data) {	
					try {
						
						BillSourceDTO billSource = new BillSourceDTO();
						billSource.setBillCtgy((String) obj[0] != null ? (String) obj[0] : "");
						billSource.setBillNum((String) obj[1] != null ? (String) obj[1] : "");
						
						String billNum = billSource.getBillNum();
						resList.add(billNum);
						logger.info("billNum{}" , billNum);
						
						billSource.setIrnFlag((String) obj[2] != null ? (String) obj[2] : "");
						billSource.setMessage((String) obj[3] != null ? (String) obj[3] : "");
						billSource.setIrn((String) obj[4] != null ? (String) obj[4] : "");
						billSource.setBilldt((Date) obj[5]);
						billSource.setSource((String) obj[6] != null ? (String) obj[6] : "");
						billSource.setBillType((String) obj[7] != null ? (String) obj[7] : "");
						billSource.setBaseAmt((Double) obj[8] != null ? (Double) obj[8] : 0);
						billSource.setCsgtAmt((Double) obj[9] != null ? (Double) obj[9] : 0);
						billSource.setSgstAmt((Double) obj[10] != null ? (Double) obj[10] : 0);
						billSource.setIgstAmt((Double) obj[11] != null ? (Double) obj[11] : 0);
						billSource.setActualOutstandingAmt((Double) obj[12] != null ? (Double) obj[12] : 0);
						billSource.setGstNum((String) obj[13] != null ? (String) obj[13] : "");
						billSource.setS3DocumentKey((String) obj[14] != null ? (String) obj[14] : "");
						billSource.setStatus((String) obj[15] !=null ? (String) obj[15] : "");

						
						logger.info("RetailServiceImpl --- Source -- getSourceDetails -- {}", (String) obj[1]);
						
						List<WaybillDetailsDTO> waybilDTO=retailBillingUtil.getBillSourceDetails((String) obj[1]);
	
						if(!waybilDTO.isEmpty()) {
							
							List<WaybillDetailsDTO> waybliList=new ArrayList<>();
							
							for(WaybillDetailsDTO obj1: waybilDTO) {
								WaybillDetailsDTO waybillDTO = new WaybillDetailsDTO();
								waybillDTO.setMopId(obj1.getMopId()) ;
								waybillDTO.setWayBillNum(obj1.getWayBillNum());
								waybillDTO.setPickupDate(obj1.getPickupDate());
								waybillDTO.setDlvrtDate(obj1.getDlvrtDate());
								
								logger.info("waybillDTO ---- obj1 ");
								waybliList.add(waybillDTO);
							}
							
							billSource.setWaybillDetailsDTO(waybliList);
						}
						
						billSourceList.add(billSource);
						
					}
					catch (Exception e) {
						e.printStackTrace();
						logger.info("RetailServiceImpl--- getSourceDetails --- Exception {}", e.getMessage());
		}		
	}
			
			/****/
			BillResponseDTO billResponse1 = new BillResponseDTO();
			List<String> billNotValid= new ArrayList<>();

			billResponse1.setStatus("FAILURE");
			//billResponse1.setMessage("DATA NOT FOUND");
			for(String wbInvalid : billInfoDTO.getBillNum()) {
				if(!resList.contains(wbInvalid)) {
				//BillSourceDTO billSource1 = new BillSourceDTO();
				//billSource1.setBillNum(wbInvalid);
				//billResList1.add(billSource1);
				String billn = wbInvalid;
				billNotValid.add(billn);
				}
			}
			 /**/
			
			for(String wbInvalid : billInfoDTO.getBillNum()) {
				
				if(resList.contains(wbInvalid)) {
				BillResponseDTO billResponse = new BillResponseDTO();
					
				logger.info("wbInvalid1 {}" , wbInvalid);
				billResponse.setStatus("SUCCESS");
				billResponse.setMessage("DATA FOUND");
				billResponse.setBillRes(billSourceList);
				billResponse.setInvalidBillNum(billNotValid);
				billResList.add(billResponse);
				break;
		} 
//				else {
//					logger.info("wbInvalid2 {}" ,  wbInvalid);
//					BillResponseDTO billResponse = new BillResponseDTO();
//
//						billResponse.setStatus("FAILURE");
//						billResponse.setMessage("DATA NOT FOUND");
//						billResponse.setBillRes(Collections.emptyList());
//						billResList.add(billResponse);
//						break;
//				}
			}
			
			return billResList;	
		}
 }
