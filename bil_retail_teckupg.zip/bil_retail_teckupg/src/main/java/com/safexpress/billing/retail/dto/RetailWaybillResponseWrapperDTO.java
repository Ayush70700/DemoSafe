package com.safexpress.billing.retail.dto;

import java.util.List;

public class RetailWaybillResponseWrapperDTO {
	private String message;
	private String status;
	private RespData data;
	private List<ErrorResponseDTO> errors;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public RespData getData() {
		return data;
	}
	public void setData(RespData data) {
		this.data = data;
	}
	public List<ErrorResponseDTO> getErrors() {
		return errors;
	}
	public void setErrors(List<ErrorResponseDTO> errors) {
		this.errors = errors;
	}
    
    
}
