package com.safexpress.billing.retail.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.safexpress.billing.retail.config.NotificationConfig;
import com.safexpress.billing.retail.dto.CustomEmailPayloadDTO;
import com.safexpress.billing.retail.dto.ErrorDetailsDTO;
import com.safexpress.billing.retail.dto.SendEmailPayloadDTO;
import com.safexpress.billing.retail.model.RetailBillIntegrations;
import com.safexpress.billing.retail.model.RetailDocDeviationHistory;
import com.safexpress.billing.retail.repository.IRetailBillIntegrationsRepository;
import com.safexpress.billing.retail.repository.IRetailDocDeviationHistoryRepository;

@Component
public class NotificationUtility {

	@Autowired
	NotificationConfig notificationConfig;
	
	@Autowired
	ApiUtil apiUtil;

	@Autowired
	IRetailBillIntegrationsRepository iRetailBillIntegrationsRepository;

	@Autowired
	IRetailDocDeviationHistoryRepository iRetailDocDeviationHistoryRepository;

	private static final Logger log = LoggerFactory.getLogger(NotificationUtility.class);

	public ResponseEntity<String> sendNotification(SendEmailPayloadDTO payloadDTO) {

		HttpEntity<SendEmailPayloadDTO> entity = new HttpEntity<>(payloadDTO);
		return notificationConfig.getRestTemplate().exchange(notificationConfig.getNotificationUrl(), HttpMethod.POST,
				entity, String.class);
	}

	/**
	 * @Description to send notifications
	 * @return String
	 */
	public ResponseEntity<String> sendNotification(String subject, String body) {
		log.info("=== NotificationUtility:: sendNotification === subject {} ",subject);
		SendEmailPayloadDTO payloadDTO = getDefaultPayload();
		payloadDTO.setSubject(subject);
		payloadDTO.setBody(body);
		
		if(Constants.getJwtToken() == null) {
			String token= apiUtil.getBillingToken();
			Constants.setJwtToken(token);
		}
		
		HttpEntity<SendEmailPayloadDTO> entity = new HttpEntity<>(payloadDTO, apiUtil.createBillingServiceHeader());
		return notificationConfig.getRestTemplate().exchange(notificationConfig.getNotificationUrl(), HttpMethod.POST,
				entity, String.class);
	}

	private SendEmailPayloadDTO getDefaultPayload() {
		SendEmailPayloadDTO payloadDTO = new SendEmailPayloadDTO();
		payloadDTO.setToRecipients(notificationConfig.getToRecipients());
		payloadDTO.setCcRecipients(notificationConfig.getCcRecipients());
		payloadDTO.setBccRecipients(notificationConfig.getBccRecipients());
		return payloadDTO;
	}

	/**
	 * @Description to create mail body for waybill Write off
	 * @return CustomEmailPayloadDTO Email Payload
	 */
	public CustomEmailPayloadDTO sendWaybillWriteOffFailureNtfy() {
		log.info("=== NotificationUtility:: sendWaybillWriteOffFailureNtfy ===");
		List<ErrorDetailsDTO> errorList = new ArrayList<ErrorDetailsDTO>();
		CustomEmailPayloadDTO customEmailPayloadDTO = new CustomEmailPayloadDTO();
		customEmailPayloadDTO.setSubject("Oracle WayBill WriteOff Failure Notification");
		customEmailPayloadDTO.setEmailType(Constants.RETAIL_BILL_EMAIL_TYPE);
		List<RetailBillIntegrations> integrationRecords = iRetailBillIntegrationsRepository
				.findErrorRecords(Constants.RETAIL_WRITEOFF_STATUS);
		for (RetailBillIntegrations intgErr : integrationRecords) {
			List<RetailDocDeviationHistory> retailWayBillDocDeviation = iRetailDocDeviationHistoryRepository
					.findBySourceRefId(intgErr.getSourceRefId());
			for (RetailDocDeviationHistory historyRecord : retailWayBillDocDeviation) {
				ErrorDetailsDTO error = new ErrorDetailsDTO();
				error.setBillNum(historyRecord.getDocNum());
				error.setAdditionalInfo("Way Bill WriteOff Amount: " + historyRecord.getAmount());
				error.setMessage(intgErr.getMessage());
				errorList.add(error);
			}
		}
		Map<String, Object> customTemplateData = new HashMap<>();
		customTemplateData.put("errorList", errorList);
		customEmailPayloadDTO.setCustomTemplateData(customTemplateData);
		customEmailPayloadDTO.setErrCount(errorList.size());
		return customEmailPayloadDTO;
	}

	/**
	 * @Description to send notifications
	 * @return String
	 */
	public ResponseEntity<String> sendMailNotification(CustomEmailPayloadDTO payloadDTO) {
		log.info("=== NotificationUtility:: sendMailNotification ===");
		if (null == payloadDTO.getToRecipients()) {
			SendEmailPayloadDTO defaultPayload = getDefaultPayload();
			payloadDTO.setToRecipients(defaultPayload.getToRecipients());
			payloadDTO.setCcRecipients(defaultPayload.getCcRecipients());
			payloadDTO.setBccRecipients(defaultPayload.getBccRecipients());
		}

		if(Constants.getJwtToken() == null) {
			String token= apiUtil.getBillingToken();
			Constants.setJwtToken(token);
		}
		
		HttpEntity<SendEmailPayloadDTO> entity = new HttpEntity<>(payloadDTO, apiUtil.createBillingServiceHeader());
		try {
			return notificationConfig.getRestTemplate().exchange(notificationConfig.getNotificationUrl(),
					HttpMethod.POST, entity, String.class);

		} catch (Exception ex) {
			ex.printStackTrace();
			log.error("NotificationUtility:: sendMailNotification : {}", ex.getMessage());
		}
		return null;
	}

}
