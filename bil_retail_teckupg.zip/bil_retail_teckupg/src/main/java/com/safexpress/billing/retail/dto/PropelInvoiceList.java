package com.safexpress.billing.retail.dto;

import java.util.Date;

public class PropelInvoiceList {
	private int bookingReqId;
    private int consignmentWeight;
    private Date createdDate;
    private EwaybillInvoiceDetail ewaybillInvoiceDetail;
    private int grossAmountWithoutTax;
    private int gstAmount;
    private String instruction;
    private int invoiceAmount;
    private Date invoiceDate;
    private int invoiceId;
    private String invoiceNumber;
    private int netAmountWithTax;
    private int packageCount;
    private int totInvoiceWithGST;
    private int totInvoiceWithoutGST;
    private String userId;
    private String userType;
}
