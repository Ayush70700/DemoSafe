package com.safexpress.billing.retail.controller;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.safexpress.billing.retail.dto.BillAdditionalInfoDTO;
import com.safexpress.billing.retail.dto.BillInformationDTO;
import com.safexpress.billing.retail.dto.BillResponseDTO;
import com.safexpress.billing.retail.dto.ErrorDTO;
import com.safexpress.billing.retail.dto.ErrorResponseDTO;
import com.safexpress.billing.retail.dto.BillSourceDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateDTO;
import com.safexpress.billing.retail.dto.CMDMInvoiceUpdateResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceBulkSearchDTO;
import com.safexpress.billing.retail.dto.EInvoiceSearchResponseDTO;
import com.safexpress.billing.retail.dto.EInvoiceUpdateRequestDTO;
import com.safexpress.billing.retail.dto.RetailBillDetailsDTO;
import com.safexpress.billing.retail.dto.RetailBillOsDTO;
import com.safexpress.billing.retail.dto.RetailBillsDetailsforReceiptDTO;
import com.safexpress.billing.retail.dto.RetailWayBillWriteOffDTO;
import com.safexpress.billing.retail.dto.SelfServiceRequestDTO;
import com.safexpress.billing.retail.dto.SelfServiceResponseDTO;
import com.safexpress.billing.retail.exception.CustomException;
import com.safexpress.billing.retail.irn.dto.IrnHeaderDTO;
import com.safexpress.billing.retail.model.RetailBillBatchDetails;
import com.safexpress.billing.retail.service.IReatilOracleFusionService;
import com.safexpress.billing.retail.service.IRetailService;
import com.safexpress.billing.s3utility.utility.S3Utility;

import io.swagger.v3.oas.annotations.Operation;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/")
public class RetailBillingController {

	private static final Logger logger = LoggerFactory.getLogger(RetailBillingController.class);

	@Autowired
	IRetailService retailService;


	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	IReatilOracleFusionService iReatilOracleFusionService;

	/** The s 3 utility. */
	@Autowired
	S3Utility s3Utility;

	/**
	 * Method to generate SSP Retail BIll
	 * 
	 * @param sspRequest
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Create Retail Bill Based On Self Service Portal Input Authorization will be added later on same")
	@PostMapping(path = "/ssp", produces = "application/json")
	public ResponseEntity<SelfServiceResponseDTO> saveSSPBills(@RequestBody SelfServiceRequestDTO sspRequest)
			throws CustomException, URISyntaxException {

		SelfServiceResponseDTO ssResp = retailService.initateSSPBillCreation(sspRequest);
		return new ResponseEntity<>(ssResp, HttpStatus.OK);
	}

	/**
	 * Method to get Retail Bill Detail
	 * 
	 * @param documentNumber
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Get Retail Bill detail by Bill Number (Multiple Bill number should be comma saparated )")
	@GetMapping(path = "/billsByNumber", produces = "application/json")
	public List<RetailBillDetailsDTO> getBillDetailsByDocNum(
			@RequestHeader(name = "documentnumber", defaultValue = "") String documentNumber,
			@RequestHeader(name = "documentwise", defaultValue = "", required = false) String documentWise,
			@RequestHeader(name = "samebillinglevel", defaultValue = "", required = false) String sameBilingLevel)
			throws CustomException {
		return retailService.getBillDetailsByDocNum(documentNumber, documentWise, sameBilingLevel);
	}

	/**
	 * REST API: GET : Method to get the B2B bills not integrated for IRN
	 * 
	 */
	@Operation(summary = "Method to get applied Credit Bills")
	@GetMapping(path = "/irn/{errorFlag}")
	public List<IrnHeaderDTO> getB2BBills(@PathVariable String errorFlag) {
		return retailService.getB2bBills(errorFlag);
	}

	/**
	 * REST API: GET : Method to save additional bill details
	 * 
	 */
	@Operation(summary = "Method save additonal bill information")
	@PostMapping(path = "/additionalInfo")
	public String saveAdditionalDetails(@RequestBody List<BillAdditionalInfoDTO> additionalInfo) {
		return retailService.saveAdditionalDetails(additionalInfo);
	}

	/**
	 * Get Bill Detail for search criteria
	 * 
	 * @param documentType
	 * @param documentNumber
	 * @param custId
	 * @param fromDate
	 * @param toDate
	 * @param branchId
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Get Retail Bill Details by serach Criteria as header params")
	@GetMapping(path = "/getBillDetails", produces = "application/json")
	public List<RetailBillsDetailsforReceiptDTO> getRetailBillDetails(
			@RequestHeader(name = "documenttype", defaultValue = "", required = false) String documentType,
			@RequestHeader(name = "documentnumber", defaultValue = "", required = false) String documentNumber,
			@RequestHeader(name = "custid", defaultValue = "", required = false) Long custId,
			@RequestHeader(name = "fromdate", defaultValue = "", required = false) String fromDate,
			@RequestHeader(name = "todate", defaultValue = "", required = false) String toDate,
			@RequestHeader(name = "branchid", defaultValue = "", required = false) String branchId)
			throws CustomException {
		return retailService.getRetailBillDetails(documentType, documentNumber, custId, fromDate, toDate, branchId);
	}

	/**
	 * Get all Applied Bills
	 * 
	 * @param documentIds
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Method to get applied retail Bills")
	@GetMapping(path = "/appliedBills")
	public List<RetailBillsDetailsforReceiptDTO> getDocDetails(@RequestParam(required = false) String documentIds) {
		return retailService.getAppliedBills(documentIds);
	}

	/**
	 * Method to update bill Outstanding
	 * 
	 * @param reqData
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Method to update retail Bill OutStanding amount")
	@PostMapping(path = "/update/outstanding")
	public ResponseEntity<Long> updateOutstandingBill(@RequestBody List<RetailBillOsDTO> reqData) {
		retailService.updateBillOutstanding(reqData);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * Method to initiate b2b invoice creation
	 * 
	 * @param documentIds
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Method to get applied retail Bills")
	@PostMapping(path = "/b2b")
	public String initateB2B() throws CustomException, URISyntaxException {
		String b2bResp = "FAILURE";
		logger.info("=== RetailBatch:: initateB2B: Started ====");
		List<RetailBillBatchDetails> rbDetailList = retailService.initateB2BBatchCreation();
		if (!rbDetailList.isEmpty()) {
			retailService.processBatchDetail(rbDetailList);
			b2bResp = "SUCCESS";
		}
		logger.info("RetailBatch:: initateB2B: {} ", b2bResp);
		logger.info("=== RetailBatch:: initateB2B: Ended ====");
		return b2bResp;
	}

	/**
	 * Method to initiate b2c invoice creation
	 * 
	 * @param documentIds
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Method to get applied retail Bills")
	@PostMapping(path = "/b2c")
	public String initateB2C() throws CustomException, URISyntaxException {
		List<RetailBillBatchDetails> rbDetailList = retailService.initateB2CBatchCreation();
		retailService.processBatchDetail(rbDetailList);
//		iReatilOracleFusionService.fusionRetailBillGlIntg();
		return "Done";
	}

	@Operation(summary = "To download cmdm bulk upload template")
	@GetMapping(path = "/invoice/download")
//	public ResponseEntity<String> getInvoiceDownloadLing(@RequestParam(required = true) String invNum,
//			@RequestParam(required = true) String gstIn) throws CustomException {
	public ResponseEntity<String> getInvoiceDownloadLing(@RequestParam(required = true) String invNum,
			@RequestParam(required = false) String gstIn) throws CustomException {

		Map<String, String> invoiceFileNameMap = retailService.validateInvoice(invNum, gstIn);

		if (invoiceFileNameMap != null) {
			logger.info("InvoiceDownlaod -- invNum : {} -- invoiceFileNameMap Size : {}", invNum,
					invoiceFileNameMap.size());
			String invoiceFileName = invoiceFileNameMap.keySet().iterator().next();
			String s3BucketName = invoiceFileNameMap.get(invoiceFileName);
			return ResponseEntity.ok().body(s3Utility.getSignedUrl(invoiceFileName, s3BucketName));
		} else {
			logger.info("InvoiceDownlaod -- Exception -- invNum : {} -- Invoice with Given GSTING Does Not Exist or Try after Some time",
					invNum);
			throw new CustomException("Invoice with Given GSTING Does Not Exist or Try after Some time");
		}
	}

	/**
	 * @Description To save write-off information
	 * @RequestBody creditBill
	 * @return String WriteOff status
	 * @throws CustomException
	 */
	@Operation(summary = "Method to apply writeoff on Way Bills and Integration with oracle")
	@PostMapping(path = "/wayBill/writeOff", produces = "application/json")
	public ResponseEntity<String> retailBillWriteOff(@RequestBody List<RetailWayBillWriteOffDTO> retailBill)
			throws CustomException {
		String msg = retailService.retailBillWriteOff(retailBill);
//		iReatilOracleFusionService.fusionRetailWriteOffGlIntg();
		List<String> status = new ArrayList<>();
		status.add("INSERTED");
		iReatilOracleFusionService.fusionRetailWriteOffGlIntegration(status);
		return new ResponseEntity<>(msg, HttpStatus.OK);
	}

	/**
	 * @Description update bill outstanding based on CMDM
	 * @param CMDMInvoiceUpdateDTO requestData
	 * @return String success message
	 * @throws CustomException
	 */
	@Operation(summary = "Update bill based on CMDM")
	@PutMapping(path = "/cmdm", produces = "application/json")
	public ResponseEntity<List<CMDMInvoiceUpdateResponseDTO>> updateCMDMInvoiceDetails(
			@RequestBody List<CMDMInvoiceUpdateDTO> requestDataList) {
		List<CMDMInvoiceUpdateResponseDTO> result = retailService.updateCMDMInvoiceDetails(requestDataList);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/**
	 * @Description Get Retail Bills for Einvoice
	 * @param documentNumber
	 * @param billFromDt
	 * @param billToDt
	 * @param gstNumber
	 * @param irnFlag
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Get Retail Bills for Einvoice")
	@GetMapping(path = "/einvoice", produces = "application/json")
	public ResponseEntity<List<EInvoiceSearchResponseDTO>> getEInvoiceBills(
			@RequestHeader(name = "documentnumber", defaultValue = "", required = false) String documentNumber,
			@RequestHeader(name = "fromdate") String billFromDt, @RequestHeader(name = "todate") String billToDt,
			@RequestHeader(name = "buyergstin", defaultValue = "", required = false) String gstNumber,
			@RequestHeader(name = "status", defaultValue = "") String irnFlag) throws CustomException {

		List<EInvoiceSearchResponseDTO> response = retailService.getEInvoiceBills(documentNumber, billFromDt, billToDt,
				gstNumber, irnFlag);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	/**
	 * @Description Get Retail Bills for Einvoice
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Validate Retail Bills for Einvoice-Excel Upload")
	@PostMapping(path = "/einvoice/bulk", produces = "application/json")
	public ResponseEntity<List<EInvoiceSearchResponseDTO>> getEInvoiceBulkBills(
			@RequestBody List<EInvoiceBulkSearchDTO> bulkSearch) throws CustomException {
		List<EInvoiceSearchResponseDTO> response = retailService.getEInvoiceBills(bulkSearch);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	/**
	 * @Description Update Retail Bills for Einvoice
	 * @param updateDetails
	 * @return
	 * @throws CustomException
	 */
	@Operation(summary = "Update Retail Bills for Einvoice")
	@PostMapping(path = "/einvoice", produces = "application/json")
	public ResponseEntity<String> updateEInvoiceBills(@RequestBody List<EInvoiceUpdateRequestDTO> updateDetails)
			throws CustomException {
		String newDetails = retailService.updateEinvBulkBills(updateDetails);
		return new ResponseEntity<>(newDetails, HttpStatus.OK);
	}

	/**
	 * Updates data of Retail bills to Oracle GL Async
	 * 
	 * @return void
	 * @throws CustomException
	 */
	@Operation(summary = "Updates data of Retail bills to Oracle GL Async")
	@PostMapping("/updateToOracleAsyncGl")
	public ResponseEntity<CompletableFuture<Void>> asyncUpdateToOracleGL() {
		// picks up only "INSERTED" and "ERROR" status records
		CompletableFuture<Void> asyncCustomerRes = retailService.asyncUpdateToOracleGL();
		asyncCustomerRes.thenRun(() -> retailService.sendNotificationForFailedGL());

		return ResponseEntity.status(HttpStatus.OK).build();

	}

	/**
	 * Updates data of Waybills WriteOff to Oracle GL Async
	 * 
	 * @return void
	 * @throws CustomException
	 */
	@Operation(summary = "Updates data of Waybills WriteOff to Oracle GL Async")
	@PostMapping("/updateToOracleAsyncWriteOffGl")
	public ResponseEntity<CompletableFuture<Void>> asyncWriteOffUpdateToOracleGL() {

		List<String> status = new ArrayList<>();
		status.add("INSERTED");
		status.add("ERROR");
		iReatilOracleFusionService.fusionRetailWriteOffGlIntegration(status);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	/**
	 * Method to re-process send mail for Retail Bills
	 * 
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Method to reprocess emails for Retail Bills")
	@PostMapping(path = "/reprocess/emails")
	public ResponseEntity<String> reprocessEmail() {
		retailService.resendRetailMails();
		String respmsg = "Method to reprocess emails for Retail Bills has been executed successfully.";
		return ResponseEntity.status(HttpStatus.OK).body(respmsg);
	}

	/**
	 * REST API: GET : Method to save additional bill details
	 * 
	 */
	@Operation(summary = "Method save additonal bill information")
	@PostMapping(path = "/updemailstatus")
	public ResponseEntity<String> updEmailStatus(@RequestBody List<BillAdditionalInfoDTO> additionalInfo) {
		String response = retailService.updateRetailBillsEmailDetails(additionalInfo);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	/**
	 * Method to re-process EReportGeneration for Retail Bills
	 * 
	 * @return
	 * @throws CustomException
	 * @throws URISyntaxException
	 */
	@Operation(summary = "Method to reprocess EReportGeneration for Retail Bills")
	@PostMapping(path = "/reprocess/ebillreportgen")
	public ResponseEntity<String> reprocessEReportGeneration() {
		retailService.reprocessEReportGeneration();
		String respmsg = "Method to reprocess EReportGeneration for Retail Bills has been executed successfully.";
		return ResponseEntity.status(HttpStatus.OK).body(respmsg);
	}

	/**
	 * REST API: GET : Method to save additional bill details
	 * 
	 */
	@Operation(summary = "Method save additonal bill information")
	@PostMapping(path = "/updereportgen")
	public ResponseEntity<String> updEReportGen(@RequestBody List<BillAdditionalInfoDTO> additionalInfo) {
		String response = retailService.updateRetailBillsReportGen(additionalInfo);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	/**
	 * source api
	 * 
	 * @throws CustomException
	 */
	@Operation(summary = "Method to get source")
	@PostMapping(path = "/source")
	public ResponseEntity<List<BillResponseDTO>> getBillSourceInfo(@RequestBody BillInformationDTO billInfoDTO)
			throws CustomException {
		List<BillResponseDTO> response = retailService.getBillSourceDetails(billInfoDTO);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}
