package com.safexpress.billing.retail.model;
/**
 * <h1>IRetailService</h1>
 * <P>
 * The IRetailService contains all the service methods required for Retail Billing.
 * <p>
 * <b>Note:</b>
 *
 * @author KPMG
 * @version 1.0
 * @since 2020-06-23
 */
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@MappedSuperclass
public class BaseModel {
	private LocalDateTime crDt;
	private String crBy;
	private LocalDateTime updDt;
	private String updBy;
	private String attr1;
	private String attr2;
	private String attr3;
	private String attr4;
	private String attr5;
	

    @CreationTimestamp
    @Column(name = "cr_dt")
    public LocalDateTime getCrDt() {
        return crDt;
    }

 
    public void setCrDt(LocalDateTime crDt) {
        this.crDt = crDt;
    }
 
    @UpdateTimestamp
    @Column(name = "upd_dt")
    public LocalDateTime getUpdDt() {
        return updDt;
    }

    public void setUpdDt(LocalDateTime updDt) {
        this.updDt = updDt;
    }

    @Column(name = "cr_by")
    public String getCrBy() {
        return crBy;
    }


    public void setCrBy(String crBy) {
        this.crBy = crBy;
    }

 
    @Column(name = "upd_by")
    public String getUpdBy() {
        return updBy;
    }

 
    public void setUpdBy(String updBy) {
        this.updBy = updBy;
    }

 
    @Column(name = "attr1")
    public String getAttr1() {
        return attr1;
    }
    
    public void setAttr1(String attr1) {
        this.attr1 = attr1;
    }

    @Column(name = "attr2")
    public String getAttr2() {
        return attr2;
    }

    public void setAttr2(String attr2) {
        this.attr2 = attr2;
    }


    @Column(name = "attr3")
    public String getAttr3() {
        return attr3;
    }


    public void setAttr3(String attr3) {
        this.attr3 = attr3;
    }

    @Column(name = "attr4")
    public String getAttr4() {
        return attr4;
    }


    public void setAttr4(String attr4) {
        this.attr4 = attr4;
    }

    @Column(name = "attr5")
    public String getAttr5() {
        return attr5;
    }

    public void setAttr5(String attr5) {
        this.attr5 = attr5;
    }

}
