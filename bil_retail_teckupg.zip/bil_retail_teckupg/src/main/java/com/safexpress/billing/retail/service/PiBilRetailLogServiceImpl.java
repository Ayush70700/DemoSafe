package com.safexpress.billing.retail.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.safexpress.billing.retail.model.LogUpdateRetryCountRequest;
import com.safexpress.billing.retail.model.LogUpdateRetryCountResponse;
import com.safexpress.billing.retail.model.PiBilRetailLogRequest;
import com.safexpress.billing.retail.model.PiBilRetailLogResponse;
import com.safexpress.billing.retail.model.RetailBillIntegrations;
import com.safexpress.billing.retail.repository.IPiBilRetailLogRepository;

@Service
public class PiBilRetailLogServiceImpl implements PiBilRetailLogService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IPiBilRetailLogRepository retailRepo;
	
	@Value("${log.max.retryCount}")
	private Integer maxRetryCount;
	
	@Override
	public List<PiBilRetailLogResponse> getRetailApiLogsInfo(PiBilRetailLogRequest rlr) throws ParseException {
		
		logger.info("PiBilRetailLogServiceImpl ---- getRetailApiLogsInfo");
		
		String retryCount = rlr.getRetryCount();
		logger.info("Retry Count --------- {}", retryCount);
		
		String searchBy = rlr.getSearchBy();
		logger.info("Search By ----- {}", searchBy);
		
		List<RetailBillIntegrations> retailLogList = new ArrayList<>();
		List<PiBilRetailLogResponse> retailLogResponse = new ArrayList<>();
		
		try {
			
			if (searchBy.equalsIgnoreCase("DAYS")) {
				
				logger.info("-- CASE 1 : SEARCH BY -- DAYS --");
				
				String numOfDays = rlr.getNumberOfDays();
				logger.info("Number of days ----- {}", numOfDays);
			
				if (numOfDays.equalsIgnoreCase("more_than_30")) {
					
					if (retryCount.equalsIgnoreCase("ALL")) {
						
						logger.info("Case 1.1 : MoreThan30 and ALL");
						retailLogList = retailRepo.getRetailLogInfo30All();
					
					} else {
						
						logger.info("Case 1.2 : MoreThan30 and retryCount value");
						retailLogList = retailRepo.getRetailLogInfo30(Integer.valueOf(retryCount));
					}
					
				} else {
					
					if (retryCount.equalsIgnoreCase("ALL")) {
						
						logger.info("Case 1.3 : NumOfDays value and ALL");
						retailLogList = retailRepo.getRetailLogInfoAll(Integer.valueOf(numOfDays));
					
					} else {
						
						logger.info("Case 1.4 : NumOfDays Value and retryCount value");
						retailLogList = retailRepo.getRetailLogInfo(Integer.valueOf(numOfDays), Integer.valueOf(retryCount));
					}
				}
				
			} else if (searchBy.equalsIgnoreCase("DATE")) {
				
				logger.info("-- CASE 2 : SEARCH BY -- DATE --");
				
				logger.info("Request -- From Date ---- {}", rlr.getFromDate());
				logger.info("Request -- To Date ---- {}", rlr.getToDate());
				
				String fDate = getFromAndToDate(rlr.getFromDate());
				String tDate = getFromAndToDate(rlr.getToDate());
				
				java.time.LocalDateTime fromDate = java.time.LocalDateTime.parse(fDate);
				java.time.LocalDateTime toDate = java.time.LocalDateTime.parse(tDate);

				logger.info("From Date ---- {}", fromDate);
				logger.info("To Date ---- {}", toDate);
				
				if (retryCount.equalsIgnoreCase("ALL")) {
					
					logger.info("Case 2.1 : ALL");
					
					retailLogList = retailRepo.getDateRetailLogInfoAll(fromDate, toDate);
				
				} else {
					
					logger.info("Case 2.2 : RetryCount value");
					retailLogList = retailRepo.getDateRetailLogInfo(fromDate, toDate, Integer.valueOf(retryCount));
				}
					
			}
				
			/** response */
			retailLogResponse = setRetailLogResponse(retailLogList);

		} catch(Exception e) {
			
			logger.info("Exception------- {}", e.getMessage());
				
		}
		
		return retailLogResponse;

	}
	
	private List<PiBilRetailLogResponse> setRetailLogResponse(List<RetailBillIntegrations> retailBillIntg) throws ParseException{
		
		List<PiBilRetailLogResponse> retailLogRespList = new ArrayList<>();
		
		for(RetailBillIntegrations rIntg : retailBillIntg) {
			
			PiBilRetailLogResponse retailLogResp = new PiBilRetailLogResponse();
			
			retailLogResp.setAttr1(rIntg.getAttr1());
			retailLogResp.setAttr2(rIntg.getAttr2());
			retailLogResp.setAttr3(rIntg.getAttr3());
			retailLogResp.setAttr4(rIntg.getAttr4());
			retailLogResp.setAttr5(rIntg.getAttr5());
			retailLogResp.setBillType(rIntg.getBillType());
			retailLogResp.setCrBy(rIntg.getCrBy());
			retailLogResp.setCrDt(getCrUpdDt(rIntg.getCrDt().toString()));
			retailLogResp.setDest(rIntg.getDest());
			retailLogResp.setDestRefId(rIntg.getDestRefId());
			retailLogResp.setEvent(rIntg.getEvent());
			retailLogResp.setIntegrationId(rIntg.getIntegrationId());
			retailLogResp.setMessage(rIntg.getMessage());
			retailLogResp.setRetryCount(rIntg.getRetryCount());
			retailLogResp.setSource(rIntg.getSource());
			retailLogResp.setSourceDocAmt(rIntg.getSourceDocAmt());
			retailLogResp.setSourceRefId(rIntg.getSourceRefId().toString());
			retailLogResp.setStatus(rIntg.getStatus());
			retailLogResp.setUpdBy(rIntg.getUpdBy());
			retailLogResp.setUpdDt(getCrUpdDt(rIntg.getUpdDt().toString()));
			retailLogResp.setVer(rIntg.getVer());
			
			retailLogRespList.add(retailLogResp);
		}
		
		return retailLogRespList;
	}
	
	private Date getCrUpdDt(String dt) throws ParseException {
	
		SimpleDateFormat formatter1 = new SimpleDateFormat();
		
		if(dt.length()>=20) {
			 formatter1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

			
		} else {
			
			 formatter1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		}
		
		Date changeDt = formatter1.parse(dt);
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss");
		String finalDate = formatter.format(changeDt);
		
		return formatter.parse(finalDate);
	}
	
	@Override
	public LogUpdateRetryCountResponse updateLogRetryCount(LogUpdateRetryCountRequest req) {
		
		logger.info("PiBilRetailLogServiceImpl ------ updateLogRetryCount");
		
		String projectName = req.getProjectName();
		Long integrationId = req.getIntegrationId();
		String retryCount = req.getRetryCount();
		
		LogUpdateRetryCountResponse resp = new LogUpdateRetryCountResponse();
		int result = 0;
		
		logger.info("ProjectName -- {}", projectName);
		logger.info("Integration id -- {}", integrationId);
		logger.info("Retry Count -- {}", retryCount);
		
		try {
		
			if (integrationId > 0 && Integer.valueOf(retryCount).equals(maxRetryCount)) {
				
				logger.info("Retry Count ----- {}", maxRetryCount);
				
				result = retailRepo.updateRetryCountLogValue(integrationId, maxRetryCount);
								
				if(result > 0) {
					
					logger.info("Retry Count Reset Successfully");
					resp.setProjectName(projectName);
					resp.setIntegrationId(integrationId);
					resp.setMessage("Retry Count Reset Successfully");
					resp.setStatus("SUCCESS");
					
				} else {
					
					logger.info("Retry Count reset failed");
					resp.setProjectName(projectName);
					resp.setIntegrationId(integrationId);
					resp.setMessage("Retry Count reset failed");
					resp.setStatus("FAILURE");
				}
				
			} else {
				 
				logger.info("Integration id not greater than 0 -- OR -- Retry Count Value other than {}", maxRetryCount);
				resp.setProjectName(projectName);
				resp.setIntegrationId(integrationId);
				resp.setMessage("Integration Id, Retry Count -- Values Required. Retry count values equals to "+maxRetryCount+" can only be reset to 0.");
				resp.setStatus("Success");
			}
		
		} catch(Exception e) {
			
			logger.info("Exception------- {}", e.getMessage());
		}
		
		logger.info("---- response -----");
		
		return resp;
				
	}
		
	private String getFromAndToDate(Date a) throws ParseException {
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss");
		String dt = formatter.format(a);
		Date d = formatter.parse(dt);
		SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return formatter2.format(d);
	}

}





