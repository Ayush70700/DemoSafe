package com.safexpress.billing.retail.dto;

public class PropelJwtTokenRespDTO {

	String message;
	PropelTokenDTO data;
	String status;

	public String getMessage() {
		return message;
	}

	public PropelTokenDTO getData() {
		return data;
	}

	public String getStatus() {
		return status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setData(PropelTokenDTO data) {
		this.data = data;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
